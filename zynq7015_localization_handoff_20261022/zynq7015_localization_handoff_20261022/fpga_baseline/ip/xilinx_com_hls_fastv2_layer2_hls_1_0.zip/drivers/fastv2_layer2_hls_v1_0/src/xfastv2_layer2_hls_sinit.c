// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xfastv2_layer2_hls.h"

extern XFastv2_layer2_hls_Config XFastv2_layer2_hls_ConfigTable[];

#ifdef SDT
XFastv2_layer2_hls_Config *XFastv2_layer2_hls_LookupConfig(UINTPTR BaseAddress) {
	XFastv2_layer2_hls_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XFastv2_layer2_hls_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XFastv2_layer2_hls_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XFastv2_layer2_hls_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFastv2_layer2_hls_Initialize(XFastv2_layer2_hls *InstancePtr, UINTPTR BaseAddress) {
	XFastv2_layer2_hls_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFastv2_layer2_hls_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFastv2_layer2_hls_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XFastv2_layer2_hls_Config *XFastv2_layer2_hls_LookupConfig(u16 DeviceId) {
	XFastv2_layer2_hls_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFASTV2_LAYER2_HLS_NUM_INSTANCES; Index++) {
		if (XFastv2_layer2_hls_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFastv2_layer2_hls_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFastv2_layer2_hls_Initialize(XFastv2_layer2_hls *InstancePtr, u16 DeviceId) {
	XFastv2_layer2_hls_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFastv2_layer2_hls_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFastv2_layer2_hls_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

