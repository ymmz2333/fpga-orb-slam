
    wire dl_reset;
    wire dl_clock;
    assign dl_reset = ap_rst_n;
    assign dl_clock = ap_clk;
    wire [8:0] proc_0_data_FIFO_blk;
    wire [8:0] proc_0_data_PIPO_blk;
    wire [8:0] proc_0_start_FIFO_blk;
    wire [8:0] proc_0_TLF_FIFO_blk;
    wire [8:0] proc_0_input_sync_blk;
    wire [8:0] proc_0_output_sync_blk;
    wire [8:0] proc_dep_vld_vec_0;
    reg [8:0] proc_dep_vld_vec_0_reg;
    wire [8:0] in_chan_dep_vld_vec_0;
    wire [314:0] in_chan_dep_data_vec_0;
    wire [8:0] token_in_vec_0;
    wire [8:0] out_chan_dep_vld_vec_0;
    wire [34:0] out_chan_dep_data_0;
    wire [8:0] token_out_vec_0;
    wire dl_detect_out_0;
    wire dep_chan_vld_1_0;
    wire [34:0] dep_chan_data_1_0;
    wire token_1_0;
    wire dep_chan_vld_2_0;
    wire [34:0] dep_chan_data_2_0;
    wire token_2_0;
    wire dep_chan_vld_8_0;
    wire [34:0] dep_chan_data_8_0;
    wire token_8_0;
    wire dep_chan_vld_10_0;
    wire [34:0] dep_chan_data_10_0;
    wire token_10_0;
    wire dep_chan_vld_24_0;
    wire [34:0] dep_chan_data_24_0;
    wire token_24_0;
    wire dep_chan_vld_25_0;
    wire [34:0] dep_chan_data_25_0;
    wire token_25_0;
    wire dep_chan_vld_28_0;
    wire [34:0] dep_chan_data_28_0;
    wire token_28_0;
    wire dep_chan_vld_30_0;
    wire [34:0] dep_chan_data_30_0;
    wire token_30_0;
    wire dep_chan_vld_31_0;
    wire [34:0] dep_chan_data_31_0;
    wire token_31_0;
    wire [4:0] proc_1_data_FIFO_blk;
    wire [4:0] proc_1_data_PIPO_blk;
    wire [4:0] proc_1_start_FIFO_blk;
    wire [4:0] proc_1_TLF_FIFO_blk;
    wire [4:0] proc_1_input_sync_blk;
    wire [4:0] proc_1_output_sync_blk;
    wire [4:0] proc_dep_vld_vec_1;
    reg [4:0] proc_dep_vld_vec_1_reg;
    wire [7:0] in_chan_dep_vld_vec_1;
    wire [279:0] in_chan_dep_data_vec_1;
    wire [7:0] token_in_vec_1;
    wire [4:0] out_chan_dep_vld_vec_1;
    wire [34:0] out_chan_dep_data_1;
    wire [4:0] token_out_vec_1;
    wire dl_detect_out_1;
    wire dep_chan_vld_0_1;
    wire [34:0] dep_chan_data_0_1;
    wire token_0_1;
    wire dep_chan_vld_2_1;
    wire [34:0] dep_chan_data_2_1;
    wire token_2_1;
    wire dep_chan_vld_3_1;
    wire [34:0] dep_chan_data_3_1;
    wire token_3_1;
    wire dep_chan_vld_6_1;
    wire [34:0] dep_chan_data_6_1;
    wire token_6_1;
    wire dep_chan_vld_28_1;
    wire [34:0] dep_chan_data_28_1;
    wire token_28_1;
    wire dep_chan_vld_29_1;
    wire [34:0] dep_chan_data_29_1;
    wire token_29_1;
    wire dep_chan_vld_30_1;
    wire [34:0] dep_chan_data_30_1;
    wire token_30_1;
    wire dep_chan_vld_32_1;
    wire [34:0] dep_chan_data_32_1;
    wire token_32_1;
    wire [4:0] proc_2_data_FIFO_blk;
    wire [4:0] proc_2_data_PIPO_blk;
    wire [4:0] proc_2_start_FIFO_blk;
    wire [4:0] proc_2_TLF_FIFO_blk;
    wire [4:0] proc_2_input_sync_blk;
    wire [4:0] proc_2_output_sync_blk;
    wire [4:0] proc_dep_vld_vec_2;
    reg [4:0] proc_dep_vld_vec_2_reg;
    wire [4:0] in_chan_dep_vld_vec_2;
    wire [174:0] in_chan_dep_data_vec_2;
    wire [4:0] token_in_vec_2;
    wire [4:0] out_chan_dep_vld_vec_2;
    wire [34:0] out_chan_dep_data_2;
    wire [4:0] token_out_vec_2;
    wire dl_detect_out_2;
    wire dep_chan_vld_0_2;
    wire [34:0] dep_chan_data_0_2;
    wire token_0_2;
    wire dep_chan_vld_1_2;
    wire [34:0] dep_chan_data_1_2;
    wire token_1_2;
    wire dep_chan_vld_6_2;
    wire [34:0] dep_chan_data_6_2;
    wire token_6_2;
    wire dep_chan_vld_24_2;
    wire [34:0] dep_chan_data_24_2;
    wire token_24_2;
    wire dep_chan_vld_26_2;
    wire [34:0] dep_chan_data_26_2;
    wire token_26_2;
    wire [3:0] proc_3_data_FIFO_blk;
    wire [3:0] proc_3_data_PIPO_blk;
    wire [3:0] proc_3_start_FIFO_blk;
    wire [3:0] proc_3_TLF_FIFO_blk;
    wire [3:0] proc_3_input_sync_blk;
    wire [3:0] proc_3_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_3;
    reg [3:0] proc_dep_vld_vec_3_reg;
    wire [2:0] in_chan_dep_vld_vec_3;
    wire [104:0] in_chan_dep_data_vec_3;
    wire [2:0] token_in_vec_3;
    wire [3:0] out_chan_dep_vld_vec_3;
    wire [34:0] out_chan_dep_data_3;
    wire [3:0] token_out_vec_3;
    wire dl_detect_out_3;
    wire dep_chan_vld_4_3;
    wire [34:0] dep_chan_data_4_3;
    wire token_4_3;
    wire dep_chan_vld_24_3;
    wire [34:0] dep_chan_data_24_3;
    wire token_24_3;
    wire dep_chan_vld_26_3;
    wire [34:0] dep_chan_data_26_3;
    wire token_26_3;
    wire [1:0] proc_4_data_FIFO_blk;
    wire [1:0] proc_4_data_PIPO_blk;
    wire [1:0] proc_4_start_FIFO_blk;
    wire [1:0] proc_4_TLF_FIFO_blk;
    wire [1:0] proc_4_input_sync_blk;
    wire [1:0] proc_4_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_4;
    reg [1:0] proc_dep_vld_vec_4_reg;
    wire [1:0] in_chan_dep_vld_vec_4;
    wire [69:0] in_chan_dep_data_vec_4;
    wire [1:0] token_in_vec_4;
    wire [1:0] out_chan_dep_vld_vec_4;
    wire [34:0] out_chan_dep_data_4;
    wire [1:0] token_out_vec_4;
    wire dl_detect_out_4;
    wire dep_chan_vld_3_4;
    wire [34:0] dep_chan_data_3_4;
    wire token_3_4;
    wire dep_chan_vld_5_4;
    wire [34:0] dep_chan_data_5_4;
    wire token_5_4;
    wire [1:0] proc_5_data_FIFO_blk;
    wire [1:0] proc_5_data_PIPO_blk;
    wire [1:0] proc_5_start_FIFO_blk;
    wire [1:0] proc_5_TLF_FIFO_blk;
    wire [1:0] proc_5_input_sync_blk;
    wire [1:0] proc_5_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_5;
    reg [1:0] proc_dep_vld_vec_5_reg;
    wire [1:0] in_chan_dep_vld_vec_5;
    wire [69:0] in_chan_dep_data_vec_5;
    wire [1:0] token_in_vec_5;
    wire [1:0] out_chan_dep_vld_vec_5;
    wire [34:0] out_chan_dep_data_5;
    wire [1:0] token_out_vec_5;
    wire dl_detect_out_5;
    wire dep_chan_vld_4_5;
    wire [34:0] dep_chan_data_4_5;
    wire token_4_5;
    wire dep_chan_vld_6_5;
    wire [34:0] dep_chan_data_6_5;
    wire token_6_5;
    wire [3:0] proc_6_data_FIFO_blk;
    wire [3:0] proc_6_data_PIPO_blk;
    wire [3:0] proc_6_start_FIFO_blk;
    wire [3:0] proc_6_TLF_FIFO_blk;
    wire [3:0] proc_6_input_sync_blk;
    wire [3:0] proc_6_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_6;
    reg [3:0] proc_dep_vld_vec_6_reg;
    wire [3:0] in_chan_dep_vld_vec_6;
    wire [139:0] in_chan_dep_data_vec_6;
    wire [3:0] token_in_vec_6;
    wire [3:0] out_chan_dep_vld_vec_6;
    wire [34:0] out_chan_dep_data_6;
    wire [3:0] token_out_vec_6;
    wire dl_detect_out_6;
    wire dep_chan_vld_1_6;
    wire [34:0] dep_chan_data_1_6;
    wire token_1_6;
    wire dep_chan_vld_2_6;
    wire [34:0] dep_chan_data_2_6;
    wire token_2_6;
    wire dep_chan_vld_5_6;
    wire [34:0] dep_chan_data_5_6;
    wire token_5_6;
    wire dep_chan_vld_7_6;
    wire [34:0] dep_chan_data_7_6;
    wire token_7_6;
    wire [3:0] proc_7_data_FIFO_blk;
    wire [3:0] proc_7_data_PIPO_blk;
    wire [3:0] proc_7_start_FIFO_blk;
    wire [3:0] proc_7_TLF_FIFO_blk;
    wire [3:0] proc_7_input_sync_blk;
    wire [3:0] proc_7_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_7;
    reg [3:0] proc_dep_vld_vec_7_reg;
    wire [3:0] in_chan_dep_vld_vec_7;
    wire [139:0] in_chan_dep_data_vec_7;
    wire [3:0] token_in_vec_7;
    wire [3:0] out_chan_dep_vld_vec_7;
    wire [34:0] out_chan_dep_data_7;
    wire [3:0] token_out_vec_7;
    wire dl_detect_out_7;
    wire dep_chan_vld_6_7;
    wire [34:0] dep_chan_data_6_7;
    wire token_6_7;
    wire dep_chan_vld_8_7;
    wire [34:0] dep_chan_data_8_7;
    wire token_8_7;
    wire dep_chan_vld_21_7;
    wire [34:0] dep_chan_data_21_7;
    wire token_21_7;
    wire dep_chan_vld_28_7;
    wire [34:0] dep_chan_data_28_7;
    wire token_28_7;
    wire [3:0] proc_8_data_FIFO_blk;
    wire [3:0] proc_8_data_PIPO_blk;
    wire [3:0] proc_8_start_FIFO_blk;
    wire [3:0] proc_8_TLF_FIFO_blk;
    wire [3:0] proc_8_input_sync_blk;
    wire [3:0] proc_8_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_8;
    reg [3:0] proc_dep_vld_vec_8_reg;
    wire [3:0] in_chan_dep_vld_vec_8;
    wire [139:0] in_chan_dep_data_vec_8;
    wire [3:0] token_in_vec_8;
    wire [3:0] out_chan_dep_vld_vec_8;
    wire [34:0] out_chan_dep_data_8;
    wire [3:0] token_out_vec_8;
    wire dl_detect_out_8;
    wire dep_chan_vld_0_8;
    wire [34:0] dep_chan_data_0_8;
    wire token_0_8;
    wire dep_chan_vld_7_8;
    wire [34:0] dep_chan_data_7_8;
    wire token_7_8;
    wire dep_chan_vld_9_8;
    wire [34:0] dep_chan_data_9_8;
    wire token_9_8;
    wire dep_chan_vld_10_8;
    wire [34:0] dep_chan_data_10_8;
    wire token_10_8;
    wire [1:0] proc_9_data_FIFO_blk;
    wire [1:0] proc_9_data_PIPO_blk;
    wire [1:0] proc_9_start_FIFO_blk;
    wire [1:0] proc_9_TLF_FIFO_blk;
    wire [1:0] proc_9_input_sync_blk;
    wire [1:0] proc_9_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_9;
    reg [1:0] proc_dep_vld_vec_9_reg;
    wire [1:0] in_chan_dep_vld_vec_9;
    wire [69:0] in_chan_dep_data_vec_9;
    wire [1:0] token_in_vec_9;
    wire [1:0] out_chan_dep_vld_vec_9;
    wire [34:0] out_chan_dep_data_9;
    wire [1:0] token_out_vec_9;
    wire dl_detect_out_9;
    wire dep_chan_vld_8_9;
    wire [34:0] dep_chan_data_8_9;
    wire token_8_9;
    wire dep_chan_vld_10_9;
    wire [34:0] dep_chan_data_10_9;
    wire token_10_9;
    wire [5:0] proc_10_data_FIFO_blk;
    wire [5:0] proc_10_data_PIPO_blk;
    wire [5:0] proc_10_start_FIFO_blk;
    wire [5:0] proc_10_TLF_FIFO_blk;
    wire [5:0] proc_10_input_sync_blk;
    wire [5:0] proc_10_output_sync_blk;
    wire [5:0] proc_dep_vld_vec_10;
    reg [5:0] proc_dep_vld_vec_10_reg;
    wire [5:0] in_chan_dep_vld_vec_10;
    wire [209:0] in_chan_dep_data_vec_10;
    wire [5:0] token_in_vec_10;
    wire [5:0] out_chan_dep_vld_vec_10;
    wire [34:0] out_chan_dep_data_10;
    wire [5:0] token_out_vec_10;
    wire dl_detect_out_10;
    wire dep_chan_vld_0_10;
    wire [34:0] dep_chan_data_0_10;
    wire token_0_10;
    wire dep_chan_vld_8_10;
    wire [34:0] dep_chan_data_8_10;
    wire token_8_10;
    wire dep_chan_vld_9_10;
    wire [34:0] dep_chan_data_9_10;
    wire token_9_10;
    wire dep_chan_vld_24_10;
    wire [34:0] dep_chan_data_24_10;
    wire token_24_10;
    wire dep_chan_vld_30_10;
    wire [34:0] dep_chan_data_30_10;
    wire token_30_10;
    wire dep_chan_vld_34_10;
    wire [34:0] dep_chan_data_34_10;
    wire token_34_10;
    wire [8:0] proc_11_data_FIFO_blk;
    wire [8:0] proc_11_data_PIPO_blk;
    wire [8:0] proc_11_start_FIFO_blk;
    wire [8:0] proc_11_TLF_FIFO_blk;
    wire [8:0] proc_11_input_sync_blk;
    wire [8:0] proc_11_output_sync_blk;
    wire [8:0] proc_dep_vld_vec_11;
    reg [8:0] proc_dep_vld_vec_11_reg;
    wire [8:0] in_chan_dep_vld_vec_11;
    wire [314:0] in_chan_dep_data_vec_11;
    wire [8:0] token_in_vec_11;
    wire [8:0] out_chan_dep_vld_vec_11;
    wire [34:0] out_chan_dep_data_11;
    wire [8:0] token_out_vec_11;
    wire dl_detect_out_11;
    wire dep_chan_vld_12_11;
    wire [34:0] dep_chan_data_12_11;
    wire token_12_11;
    wire dep_chan_vld_13_11;
    wire [34:0] dep_chan_data_13_11;
    wire token_13_11;
    wire dep_chan_vld_14_11;
    wire [34:0] dep_chan_data_14_11;
    wire token_14_11;
    wire dep_chan_vld_15_11;
    wire [34:0] dep_chan_data_15_11;
    wire token_15_11;
    wire dep_chan_vld_16_11;
    wire [34:0] dep_chan_data_16_11;
    wire token_16_11;
    wire dep_chan_vld_17_11;
    wire [34:0] dep_chan_data_17_11;
    wire token_17_11;
    wire dep_chan_vld_18_11;
    wire [34:0] dep_chan_data_18_11;
    wire token_18_11;
    wire dep_chan_vld_19_11;
    wire [34:0] dep_chan_data_19_11;
    wire token_19_11;
    wire dep_chan_vld_20_11;
    wire [34:0] dep_chan_data_20_11;
    wire token_20_11;
    wire [1:0] proc_12_data_FIFO_blk;
    wire [1:0] proc_12_data_PIPO_blk;
    wire [1:0] proc_12_start_FIFO_blk;
    wire [1:0] proc_12_TLF_FIFO_blk;
    wire [1:0] proc_12_input_sync_blk;
    wire [1:0] proc_12_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_12;
    reg [1:0] proc_dep_vld_vec_12_reg;
    wire [1:0] in_chan_dep_vld_vec_12;
    wire [69:0] in_chan_dep_data_vec_12;
    wire [1:0] token_in_vec_12;
    wire [1:0] out_chan_dep_vld_vec_12;
    wire [34:0] out_chan_dep_data_12;
    wire [1:0] token_out_vec_12;
    wire dl_detect_out_12;
    wire dep_chan_vld_11_12;
    wire [34:0] dep_chan_data_11_12;
    wire token_11_12;
    wire dep_chan_vld_20_12;
    wire [34:0] dep_chan_data_20_12;
    wire token_20_12;
    wire [1:0] proc_13_data_FIFO_blk;
    wire [1:0] proc_13_data_PIPO_blk;
    wire [1:0] proc_13_start_FIFO_blk;
    wire [1:0] proc_13_TLF_FIFO_blk;
    wire [1:0] proc_13_input_sync_blk;
    wire [1:0] proc_13_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_13;
    reg [1:0] proc_dep_vld_vec_13_reg;
    wire [1:0] in_chan_dep_vld_vec_13;
    wire [69:0] in_chan_dep_data_vec_13;
    wire [1:0] token_in_vec_13;
    wire [1:0] out_chan_dep_vld_vec_13;
    wire [34:0] out_chan_dep_data_13;
    wire [1:0] token_out_vec_13;
    wire dl_detect_out_13;
    wire dep_chan_vld_11_13;
    wire [34:0] dep_chan_data_11_13;
    wire token_11_13;
    wire dep_chan_vld_20_13;
    wire [34:0] dep_chan_data_20_13;
    wire token_20_13;
    wire [1:0] proc_14_data_FIFO_blk;
    wire [1:0] proc_14_data_PIPO_blk;
    wire [1:0] proc_14_start_FIFO_blk;
    wire [1:0] proc_14_TLF_FIFO_blk;
    wire [1:0] proc_14_input_sync_blk;
    wire [1:0] proc_14_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_14;
    reg [1:0] proc_dep_vld_vec_14_reg;
    wire [1:0] in_chan_dep_vld_vec_14;
    wire [69:0] in_chan_dep_data_vec_14;
    wire [1:0] token_in_vec_14;
    wire [1:0] out_chan_dep_vld_vec_14;
    wire [34:0] out_chan_dep_data_14;
    wire [1:0] token_out_vec_14;
    wire dl_detect_out_14;
    wire dep_chan_vld_11_14;
    wire [34:0] dep_chan_data_11_14;
    wire token_11_14;
    wire dep_chan_vld_20_14;
    wire [34:0] dep_chan_data_20_14;
    wire token_20_14;
    wire [1:0] proc_15_data_FIFO_blk;
    wire [1:0] proc_15_data_PIPO_blk;
    wire [1:0] proc_15_start_FIFO_blk;
    wire [1:0] proc_15_TLF_FIFO_blk;
    wire [1:0] proc_15_input_sync_blk;
    wire [1:0] proc_15_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_15;
    reg [1:0] proc_dep_vld_vec_15_reg;
    wire [1:0] in_chan_dep_vld_vec_15;
    wire [69:0] in_chan_dep_data_vec_15;
    wire [1:0] token_in_vec_15;
    wire [1:0] out_chan_dep_vld_vec_15;
    wire [34:0] out_chan_dep_data_15;
    wire [1:0] token_out_vec_15;
    wire dl_detect_out_15;
    wire dep_chan_vld_11_15;
    wire [34:0] dep_chan_data_11_15;
    wire token_11_15;
    wire dep_chan_vld_20_15;
    wire [34:0] dep_chan_data_20_15;
    wire token_20_15;
    wire [1:0] proc_16_data_FIFO_blk;
    wire [1:0] proc_16_data_PIPO_blk;
    wire [1:0] proc_16_start_FIFO_blk;
    wire [1:0] proc_16_TLF_FIFO_blk;
    wire [1:0] proc_16_input_sync_blk;
    wire [1:0] proc_16_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_16;
    reg [1:0] proc_dep_vld_vec_16_reg;
    wire [1:0] in_chan_dep_vld_vec_16;
    wire [69:0] in_chan_dep_data_vec_16;
    wire [1:0] token_in_vec_16;
    wire [1:0] out_chan_dep_vld_vec_16;
    wire [34:0] out_chan_dep_data_16;
    wire [1:0] token_out_vec_16;
    wire dl_detect_out_16;
    wire dep_chan_vld_11_16;
    wire [34:0] dep_chan_data_11_16;
    wire token_11_16;
    wire dep_chan_vld_20_16;
    wire [34:0] dep_chan_data_20_16;
    wire token_20_16;
    wire [1:0] proc_17_data_FIFO_blk;
    wire [1:0] proc_17_data_PIPO_blk;
    wire [1:0] proc_17_start_FIFO_blk;
    wire [1:0] proc_17_TLF_FIFO_blk;
    wire [1:0] proc_17_input_sync_blk;
    wire [1:0] proc_17_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_17;
    reg [1:0] proc_dep_vld_vec_17_reg;
    wire [1:0] in_chan_dep_vld_vec_17;
    wire [69:0] in_chan_dep_data_vec_17;
    wire [1:0] token_in_vec_17;
    wire [1:0] out_chan_dep_vld_vec_17;
    wire [34:0] out_chan_dep_data_17;
    wire [1:0] token_out_vec_17;
    wire dl_detect_out_17;
    wire dep_chan_vld_11_17;
    wire [34:0] dep_chan_data_11_17;
    wire token_11_17;
    wire dep_chan_vld_20_17;
    wire [34:0] dep_chan_data_20_17;
    wire token_20_17;
    wire [1:0] proc_18_data_FIFO_blk;
    wire [1:0] proc_18_data_PIPO_blk;
    wire [1:0] proc_18_start_FIFO_blk;
    wire [1:0] proc_18_TLF_FIFO_blk;
    wire [1:0] proc_18_input_sync_blk;
    wire [1:0] proc_18_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_18;
    reg [1:0] proc_dep_vld_vec_18_reg;
    wire [1:0] in_chan_dep_vld_vec_18;
    wire [69:0] in_chan_dep_data_vec_18;
    wire [1:0] token_in_vec_18;
    wire [1:0] out_chan_dep_vld_vec_18;
    wire [34:0] out_chan_dep_data_18;
    wire [1:0] token_out_vec_18;
    wire dl_detect_out_18;
    wire dep_chan_vld_11_18;
    wire [34:0] dep_chan_data_11_18;
    wire token_11_18;
    wire dep_chan_vld_20_18;
    wire [34:0] dep_chan_data_20_18;
    wire token_20_18;
    wire [1:0] proc_19_data_FIFO_blk;
    wire [1:0] proc_19_data_PIPO_blk;
    wire [1:0] proc_19_start_FIFO_blk;
    wire [1:0] proc_19_TLF_FIFO_blk;
    wire [1:0] proc_19_input_sync_blk;
    wire [1:0] proc_19_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_19;
    reg [1:0] proc_dep_vld_vec_19_reg;
    wire [1:0] in_chan_dep_vld_vec_19;
    wire [69:0] in_chan_dep_data_vec_19;
    wire [1:0] token_in_vec_19;
    wire [1:0] out_chan_dep_vld_vec_19;
    wire [34:0] out_chan_dep_data_19;
    wire [1:0] token_out_vec_19;
    wire dl_detect_out_19;
    wire dep_chan_vld_11_19;
    wire [34:0] dep_chan_data_11_19;
    wire token_11_19;
    wire dep_chan_vld_20_19;
    wire [34:0] dep_chan_data_20_19;
    wire token_20_19;
    wire [8:0] proc_20_data_FIFO_blk;
    wire [8:0] proc_20_data_PIPO_blk;
    wire [8:0] proc_20_start_FIFO_blk;
    wire [8:0] proc_20_TLF_FIFO_blk;
    wire [8:0] proc_20_input_sync_blk;
    wire [8:0] proc_20_output_sync_blk;
    wire [8:0] proc_dep_vld_vec_20;
    reg [8:0] proc_dep_vld_vec_20_reg;
    wire [8:0] in_chan_dep_vld_vec_20;
    wire [314:0] in_chan_dep_data_vec_20;
    wire [8:0] token_in_vec_20;
    wire [8:0] out_chan_dep_vld_vec_20;
    wire [34:0] out_chan_dep_data_20;
    wire [8:0] token_out_vec_20;
    wire dl_detect_out_20;
    wire dep_chan_vld_11_20;
    wire [34:0] dep_chan_data_11_20;
    wire token_11_20;
    wire dep_chan_vld_12_20;
    wire [34:0] dep_chan_data_12_20;
    wire token_12_20;
    wire dep_chan_vld_13_20;
    wire [34:0] dep_chan_data_13_20;
    wire token_13_20;
    wire dep_chan_vld_14_20;
    wire [34:0] dep_chan_data_14_20;
    wire token_14_20;
    wire dep_chan_vld_15_20;
    wire [34:0] dep_chan_data_15_20;
    wire token_15_20;
    wire dep_chan_vld_16_20;
    wire [34:0] dep_chan_data_16_20;
    wire token_16_20;
    wire dep_chan_vld_17_20;
    wire [34:0] dep_chan_data_17_20;
    wire token_17_20;
    wire dep_chan_vld_18_20;
    wire [34:0] dep_chan_data_18_20;
    wire token_18_20;
    wire dep_chan_vld_19_20;
    wire [34:0] dep_chan_data_19_20;
    wire token_19_20;
    wire [1:0] proc_21_data_FIFO_blk;
    wire [1:0] proc_21_data_PIPO_blk;
    wire [1:0] proc_21_start_FIFO_blk;
    wire [1:0] proc_21_TLF_FIFO_blk;
    wire [1:0] proc_21_input_sync_blk;
    wire [1:0] proc_21_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_21;
    reg [1:0] proc_dep_vld_vec_21_reg;
    wire [1:0] in_chan_dep_vld_vec_21;
    wire [69:0] in_chan_dep_data_vec_21;
    wire [1:0] token_in_vec_21;
    wire [1:0] out_chan_dep_vld_vec_21;
    wire [34:0] out_chan_dep_data_21;
    wire [1:0] token_out_vec_21;
    wire dl_detect_out_21;
    wire dep_chan_vld_7_21;
    wire [34:0] dep_chan_data_7_21;
    wire token_7_21;
    wire dep_chan_vld_22_21;
    wire [34:0] dep_chan_data_22_21;
    wire token_22_21;
    wire [1:0] proc_22_data_FIFO_blk;
    wire [1:0] proc_22_data_PIPO_blk;
    wire [1:0] proc_22_start_FIFO_blk;
    wire [1:0] proc_22_TLF_FIFO_blk;
    wire [1:0] proc_22_input_sync_blk;
    wire [1:0] proc_22_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_22;
    reg [1:0] proc_dep_vld_vec_22_reg;
    wire [1:0] in_chan_dep_vld_vec_22;
    wire [69:0] in_chan_dep_data_vec_22;
    wire [1:0] token_in_vec_22;
    wire [1:0] out_chan_dep_vld_vec_22;
    wire [34:0] out_chan_dep_data_22;
    wire [1:0] token_out_vec_22;
    wire dl_detect_out_22;
    wire dep_chan_vld_21_22;
    wire [34:0] dep_chan_data_21_22;
    wire token_21_22;
    wire dep_chan_vld_23_22;
    wire [34:0] dep_chan_data_23_22;
    wire token_23_22;
    wire [2:0] proc_23_data_FIFO_blk;
    wire [2:0] proc_23_data_PIPO_blk;
    wire [2:0] proc_23_start_FIFO_blk;
    wire [2:0] proc_23_TLF_FIFO_blk;
    wire [2:0] proc_23_input_sync_blk;
    wire [2:0] proc_23_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_23;
    reg [2:0] proc_dep_vld_vec_23_reg;
    wire [2:0] in_chan_dep_vld_vec_23;
    wire [104:0] in_chan_dep_data_vec_23;
    wire [2:0] token_in_vec_23;
    wire [2:0] out_chan_dep_vld_vec_23;
    wire [34:0] out_chan_dep_data_23;
    wire [2:0] token_out_vec_23;
    wire dl_detect_out_23;
    wire dep_chan_vld_22_23;
    wire [34:0] dep_chan_data_22_23;
    wire token_22_23;
    wire dep_chan_vld_24_23;
    wire [34:0] dep_chan_data_24_23;
    wire token_24_23;
    wire dep_chan_vld_26_23;
    wire [34:0] dep_chan_data_26_23;
    wire token_26_23;
    wire [6:0] proc_24_data_FIFO_blk;
    wire [6:0] proc_24_data_PIPO_blk;
    wire [6:0] proc_24_start_FIFO_blk;
    wire [6:0] proc_24_TLF_FIFO_blk;
    wire [6:0] proc_24_input_sync_blk;
    wire [6:0] proc_24_output_sync_blk;
    wire [6:0] proc_dep_vld_vec_24;
    reg [6:0] proc_dep_vld_vec_24_reg;
    wire [6:0] in_chan_dep_vld_vec_24;
    wire [244:0] in_chan_dep_data_vec_24;
    wire [6:0] token_in_vec_24;
    wire [6:0] out_chan_dep_vld_vec_24;
    wire [34:0] out_chan_dep_data_24;
    wire [6:0] token_out_vec_24;
    wire dl_detect_out_24;
    wire dep_chan_vld_0_24;
    wire [34:0] dep_chan_data_0_24;
    wire token_0_24;
    wire dep_chan_vld_2_24;
    wire [34:0] dep_chan_data_2_24;
    wire token_2_24;
    wire dep_chan_vld_3_24;
    wire [34:0] dep_chan_data_3_24;
    wire token_3_24;
    wire dep_chan_vld_10_24;
    wire [34:0] dep_chan_data_10_24;
    wire token_10_24;
    wire dep_chan_vld_23_24;
    wire [34:0] dep_chan_data_23_24;
    wire token_23_24;
    wire dep_chan_vld_30_24;
    wire [34:0] dep_chan_data_30_24;
    wire token_30_24;
    wire dep_chan_vld_34_24;
    wire [34:0] dep_chan_data_34_24;
    wire token_34_24;
    wire [2:0] proc_25_data_FIFO_blk;
    wire [2:0] proc_25_data_PIPO_blk;
    wire [2:0] proc_25_start_FIFO_blk;
    wire [2:0] proc_25_TLF_FIFO_blk;
    wire [2:0] proc_25_input_sync_blk;
    wire [2:0] proc_25_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_25;
    reg [2:0] proc_dep_vld_vec_25_reg;
    wire [2:0] in_chan_dep_vld_vec_25;
    wire [104:0] in_chan_dep_data_vec_25;
    wire [2:0] token_in_vec_25;
    wire [2:0] out_chan_dep_vld_vec_25;
    wire [34:0] out_chan_dep_data_25;
    wire [2:0] token_out_vec_25;
    wire dl_detect_out_25;
    wire dep_chan_vld_0_25;
    wire [34:0] dep_chan_data_0_25;
    wire token_0_25;
    wire dep_chan_vld_26_25;
    wire [34:0] dep_chan_data_26_25;
    wire token_26_25;
    wire dep_chan_vld_27_25;
    wire [34:0] dep_chan_data_27_25;
    wire token_27_25;
    wire [4:0] proc_26_data_FIFO_blk;
    wire [4:0] proc_26_data_PIPO_blk;
    wire [4:0] proc_26_start_FIFO_blk;
    wire [4:0] proc_26_TLF_FIFO_blk;
    wire [4:0] proc_26_input_sync_blk;
    wire [4:0] proc_26_output_sync_blk;
    wire [4:0] proc_dep_vld_vec_26;
    reg [4:0] proc_dep_vld_vec_26_reg;
    wire [4:0] in_chan_dep_vld_vec_26;
    wire [174:0] in_chan_dep_data_vec_26;
    wire [4:0] token_in_vec_26;
    wire [4:0] out_chan_dep_vld_vec_26;
    wire [34:0] out_chan_dep_data_26;
    wire [4:0] token_out_vec_26;
    wire dl_detect_out_26;
    wire dep_chan_vld_2_26;
    wire [34:0] dep_chan_data_2_26;
    wire token_2_26;
    wire dep_chan_vld_3_26;
    wire [34:0] dep_chan_data_3_26;
    wire token_3_26;
    wire dep_chan_vld_23_26;
    wire [34:0] dep_chan_data_23_26;
    wire token_23_26;
    wire dep_chan_vld_25_26;
    wire [34:0] dep_chan_data_25_26;
    wire token_25_26;
    wire dep_chan_vld_27_26;
    wire [34:0] dep_chan_data_27_26;
    wire token_27_26;
    wire [2:0] proc_27_data_FIFO_blk;
    wire [2:0] proc_27_data_PIPO_blk;
    wire [2:0] proc_27_start_FIFO_blk;
    wire [2:0] proc_27_TLF_FIFO_blk;
    wire [2:0] proc_27_input_sync_blk;
    wire [2:0] proc_27_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_27;
    reg [2:0] proc_dep_vld_vec_27_reg;
    wire [1:0] in_chan_dep_vld_vec_27;
    wire [69:0] in_chan_dep_data_vec_27;
    wire [1:0] token_in_vec_27;
    wire [2:0] out_chan_dep_vld_vec_27;
    wire [34:0] out_chan_dep_data_27;
    wire [2:0] token_out_vec_27;
    wire dl_detect_out_27;
    wire dep_chan_vld_25_27;
    wire [34:0] dep_chan_data_25_27;
    wire token_25_27;
    wire dep_chan_vld_26_27;
    wire [34:0] dep_chan_data_26_27;
    wire token_26_27;
    wire [3:0] proc_28_data_FIFO_blk;
    wire [3:0] proc_28_data_PIPO_blk;
    wire [3:0] proc_28_start_FIFO_blk;
    wire [3:0] proc_28_TLF_FIFO_blk;
    wire [3:0] proc_28_input_sync_blk;
    wire [3:0] proc_28_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_28;
    reg [3:0] proc_dep_vld_vec_28_reg;
    wire [3:0] in_chan_dep_vld_vec_28;
    wire [139:0] in_chan_dep_data_vec_28;
    wire [3:0] token_in_vec_28;
    wire [3:0] out_chan_dep_vld_vec_28;
    wire [34:0] out_chan_dep_data_28;
    wire [3:0] token_out_vec_28;
    wire dl_detect_out_28;
    wire dep_chan_vld_0_28;
    wire [34:0] dep_chan_data_0_28;
    wire token_0_28;
    wire dep_chan_vld_1_28;
    wire [34:0] dep_chan_data_1_28;
    wire token_1_28;
    wire dep_chan_vld_7_28;
    wire [34:0] dep_chan_data_7_28;
    wire token_7_28;
    wire dep_chan_vld_29_28;
    wire [34:0] dep_chan_data_29_28;
    wire token_29_28;
    wire [3:0] proc_29_data_FIFO_blk;
    wire [3:0] proc_29_data_PIPO_blk;
    wire [3:0] proc_29_start_FIFO_blk;
    wire [3:0] proc_29_TLF_FIFO_blk;
    wire [3:0] proc_29_input_sync_blk;
    wire [3:0] proc_29_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_29;
    reg [3:0] proc_dep_vld_vec_29_reg;
    wire [3:0] in_chan_dep_vld_vec_29;
    wire [139:0] in_chan_dep_data_vec_29;
    wire [3:0] token_in_vec_29;
    wire [3:0] out_chan_dep_vld_vec_29;
    wire [34:0] out_chan_dep_data_29;
    wire [3:0] token_out_vec_29;
    wire dl_detect_out_29;
    wire dep_chan_vld_1_29;
    wire [34:0] dep_chan_data_1_29;
    wire token_1_29;
    wire dep_chan_vld_28_29;
    wire [34:0] dep_chan_data_28_29;
    wire token_28_29;
    wire dep_chan_vld_30_29;
    wire [34:0] dep_chan_data_30_29;
    wire token_30_29;
    wire dep_chan_vld_32_29;
    wire [34:0] dep_chan_data_32_29;
    wire token_32_29;
    wire [5:0] proc_30_data_FIFO_blk;
    wire [5:0] proc_30_data_PIPO_blk;
    wire [5:0] proc_30_start_FIFO_blk;
    wire [5:0] proc_30_TLF_FIFO_blk;
    wire [5:0] proc_30_input_sync_blk;
    wire [5:0] proc_30_output_sync_blk;
    wire [5:0] proc_dep_vld_vec_30;
    reg [5:0] proc_dep_vld_vec_30_reg;
    wire [4:0] in_chan_dep_vld_vec_30;
    wire [174:0] in_chan_dep_data_vec_30;
    wire [4:0] token_in_vec_30;
    wire [5:0] out_chan_dep_vld_vec_30;
    wire [34:0] out_chan_dep_data_30;
    wire [5:0] token_out_vec_30;
    wire dl_detect_out_30;
    wire dep_chan_vld_0_30;
    wire [34:0] dep_chan_data_0_30;
    wire token_0_30;
    wire dep_chan_vld_10_30;
    wire [34:0] dep_chan_data_10_30;
    wire token_10_30;
    wire dep_chan_vld_24_30;
    wire [34:0] dep_chan_data_24_30;
    wire token_24_30;
    wire dep_chan_vld_29_30;
    wire [34:0] dep_chan_data_29_30;
    wire token_29_30;
    wire dep_chan_vld_34_30;
    wire [34:0] dep_chan_data_34_30;
    wire token_34_30;
    wire [2:0] proc_31_data_FIFO_blk;
    wire [2:0] proc_31_data_PIPO_blk;
    wire [2:0] proc_31_start_FIFO_blk;
    wire [2:0] proc_31_TLF_FIFO_blk;
    wire [2:0] proc_31_input_sync_blk;
    wire [2:0] proc_31_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_31;
    reg [2:0] proc_dep_vld_vec_31_reg;
    wire [2:0] in_chan_dep_vld_vec_31;
    wire [104:0] in_chan_dep_data_vec_31;
    wire [2:0] token_in_vec_31;
    wire [2:0] out_chan_dep_vld_vec_31;
    wire [34:0] out_chan_dep_data_31;
    wire [2:0] token_out_vec_31;
    wire dl_detect_out_31;
    wire dep_chan_vld_0_31;
    wire [34:0] dep_chan_data_0_31;
    wire token_0_31;
    wire dep_chan_vld_32_31;
    wire [34:0] dep_chan_data_32_31;
    wire token_32_31;
    wire dep_chan_vld_33_31;
    wire [34:0] dep_chan_data_33_31;
    wire token_33_31;
    wire [3:0] proc_32_data_FIFO_blk;
    wire [3:0] proc_32_data_PIPO_blk;
    wire [3:0] proc_32_start_FIFO_blk;
    wire [3:0] proc_32_TLF_FIFO_blk;
    wire [3:0] proc_32_input_sync_blk;
    wire [3:0] proc_32_output_sync_blk;
    wire [3:0] proc_dep_vld_vec_32;
    reg [3:0] proc_dep_vld_vec_32_reg;
    wire [2:0] in_chan_dep_vld_vec_32;
    wire [104:0] in_chan_dep_data_vec_32;
    wire [2:0] token_in_vec_32;
    wire [3:0] out_chan_dep_vld_vec_32;
    wire [34:0] out_chan_dep_data_32;
    wire [3:0] token_out_vec_32;
    wire dl_detect_out_32;
    wire dep_chan_vld_29_32;
    wire [34:0] dep_chan_data_29_32;
    wire token_29_32;
    wire dep_chan_vld_31_32;
    wire [34:0] dep_chan_data_31_32;
    wire token_31_32;
    wire dep_chan_vld_33_32;
    wire [34:0] dep_chan_data_33_32;
    wire token_33_32;
    wire [2:0] proc_33_data_FIFO_blk;
    wire [2:0] proc_33_data_PIPO_blk;
    wire [2:0] proc_33_start_FIFO_blk;
    wire [2:0] proc_33_TLF_FIFO_blk;
    wire [2:0] proc_33_input_sync_blk;
    wire [2:0] proc_33_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_33;
    reg [2:0] proc_dep_vld_vec_33_reg;
    wire [1:0] in_chan_dep_vld_vec_33;
    wire [69:0] in_chan_dep_data_vec_33;
    wire [1:0] token_in_vec_33;
    wire [2:0] out_chan_dep_vld_vec_33;
    wire [34:0] out_chan_dep_data_33;
    wire [2:0] token_out_vec_33;
    wire dl_detect_out_33;
    wire dep_chan_vld_31_33;
    wire [34:0] dep_chan_data_31_33;
    wire token_31_33;
    wire dep_chan_vld_32_33;
    wire [34:0] dep_chan_data_32_33;
    wire token_32_33;
    wire [2:0] proc_34_data_FIFO_blk;
    wire [2:0] proc_34_data_PIPO_blk;
    wire [2:0] proc_34_start_FIFO_blk;
    wire [2:0] proc_34_TLF_FIFO_blk;
    wire [2:0] proc_34_input_sync_blk;
    wire [2:0] proc_34_output_sync_blk;
    wire [2:0] proc_dep_vld_vec_34;
    reg [2:0] proc_dep_vld_vec_34_reg;
    wire [4:0] in_chan_dep_vld_vec_34;
    wire [174:0] in_chan_dep_data_vec_34;
    wire [4:0] token_in_vec_34;
    wire [2:0] out_chan_dep_vld_vec_34;
    wire [34:0] out_chan_dep_data_34;
    wire [2:0] token_out_vec_34;
    wire dl_detect_out_34;
    wire dep_chan_vld_10_34;
    wire [34:0] dep_chan_data_10_34;
    wire token_10_34;
    wire dep_chan_vld_24_34;
    wire [34:0] dep_chan_data_24_34;
    wire token_24_34;
    wire dep_chan_vld_27_34;
    wire [34:0] dep_chan_data_27_34;
    wire token_27_34;
    wire dep_chan_vld_30_34;
    wire [34:0] dep_chan_data_30_34;
    wire token_30_34;
    wire dep_chan_vld_33_34;
    wire [34:0] dep_chan_data_33_34;
    wire token_33_34;
    wire [34:0] dl_in_vec;
    wire dl_detect_out;
    wire token_clear;
    reg [34:0] origin;

    reg ap_done_reg_0;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_0 <= 'b0;
        end
        else begin
            ap_done_reg_0 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_continue;
        end
    end

    reg ap_done_reg_1;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_1 <= 'b0;
        end
        else begin
            ap_done_reg_1 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.ap_continue;
        end
    end

    reg ap_done_reg_2;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_2 <= 'b0;
        end
        else begin
            ap_done_reg_2 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.ap_continue;
        end
    end

    reg ap_done_reg_3;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_3 <= 'b0;
        end
        else begin
            ap_done_reg_3 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_continue;
        end
    end

    reg ap_done_reg_4;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_4 <= 'b0;
        end
        else begin
            ap_done_reg_4 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.ap_continue;
        end
    end

    reg ap_done_reg_5;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_5 <= 'b0;
        end
        else begin
            ap_done_reg_5 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_continue;
        end
    end

    reg ap_done_reg_6;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_6 <= 'b0;
        end
        else begin
            ap_done_reg_6 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_continue;
        end
    end

    reg ap_done_reg_7;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_7 <= 'b0;
        end
        else begin
            ap_done_reg_7 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_continue;
        end
    end

    reg ap_done_reg_8;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_8 <= 'b0;
        end
        else begin
            ap_done_reg_8 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_continue;
        end
    end

    reg ap_done_reg_9;// for module grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_9 <= 'b0;
        end
        else begin
            ap_done_reg_9 <= grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.ap_continue;
        end
    end

reg [15:0] trans_in_cnt_0;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_0 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.start_write == 1'b1) begin
        trans_in_cnt_0 <= trans_in_cnt_0 + 16'h1;
    end
    else begin
        trans_in_cnt_0 <= trans_in_cnt_0;
    end
end

reg [15:0] trans_out_cnt_0;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_0 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.ap_continue == 1'b1) begin
        trans_out_cnt_0 <= trans_out_cnt_0 + 16'h1;
    end
    else begin
        trans_out_cnt_0 <= trans_out_cnt_0;
    end
end

reg [15:0] trans_in_cnt_1;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_1 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.start_write == 1'b1) begin
        trans_in_cnt_1 <= trans_in_cnt_1 + 16'h1;
    end
    else begin
        trans_in_cnt_1 <= trans_in_cnt_1;
    end
end

reg [15:0] trans_out_cnt_1;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_1 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.ap_continue == 1'b1) begin
        trans_out_cnt_1 <= trans_out_cnt_1 + 16'h1;
    end
    else begin
        trans_out_cnt_1 <= trans_out_cnt_1;
    end
end

reg [15:0] trans_in_cnt_2;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_2 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.start_write == 1'b1) begin
        trans_in_cnt_2 <= trans_in_cnt_2 + 16'h1;
    end
    else begin
        trans_in_cnt_2 <= trans_in_cnt_2;
    end
end

reg [15:0] trans_out_cnt_2;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_2 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.ap_continue == 1'b1) begin
        trans_out_cnt_2 <= trans_out_cnt_2 + 16'h1;
    end
    else begin
        trans_out_cnt_2 <= trans_out_cnt_2;
    end
end

reg [15:0] trans_in_cnt_3;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_3 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.start_write == 1'b1) begin
        trans_in_cnt_3 <= trans_in_cnt_3 + 16'h1;
    end
    else begin
        trans_in_cnt_3 <= trans_in_cnt_3;
    end
end

reg [15:0] trans_out_cnt_3;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_3 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_continue == 1'b1) begin
        trans_out_cnt_3 <= trans_out_cnt_3 + 16'h1;
    end
    else begin
        trans_out_cnt_3 <= trans_out_cnt_3;
    end
end

reg [15:0] trans_in_cnt_4;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_4 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.start_write == 1'b1) begin
        trans_in_cnt_4 <= trans_in_cnt_4 + 16'h1;
    end
    else begin
        trans_in_cnt_4 <= trans_in_cnt_4;
    end
end

reg [15:0] trans_out_cnt_4;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_4 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.ap_continue == 1'b1) begin
        trans_out_cnt_4 <= trans_out_cnt_4 + 16'h1;
    end
    else begin
        trans_out_cnt_4 <= trans_out_cnt_4;
    end
end

reg [15:0] trans_in_cnt_5;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_5 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.start_write == 1'b1) begin
        trans_in_cnt_5 <= trans_in_cnt_5 + 16'h1;
    end
    else begin
        trans_in_cnt_5 <= trans_in_cnt_5;
    end
end

reg [15:0] trans_out_cnt_5;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_5 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_continue == 1'b1) begin
        trans_out_cnt_5 <= trans_out_cnt_5 + 16'h1;
    end
    else begin
        trans_out_cnt_5 <= trans_out_cnt_5;
    end
end

reg [15:0] trans_in_cnt_6;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_6 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.start_write == 1'b1) begin
        trans_in_cnt_6 <= trans_in_cnt_6 + 16'h1;
    end
    else begin
        trans_in_cnt_6 <= trans_in_cnt_6;
    end
end

reg [15:0] trans_out_cnt_6;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_6 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.ap_continue == 1'b1) begin
        trans_out_cnt_6 <= trans_out_cnt_6 + 16'h1;
    end
    else begin
        trans_out_cnt_6 <= trans_out_cnt_6;
    end
end

reg [15:0] trans_in_cnt_7;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_7 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.start_write == 1'b1) begin
        trans_in_cnt_7 <= trans_in_cnt_7 + 16'h1;
    end
    else begin
        trans_in_cnt_7 <= trans_in_cnt_7;
    end
end

reg [15:0] trans_out_cnt_7;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_7 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.ap_continue == 1'b1) begin
        trans_out_cnt_7 <= trans_out_cnt_7 + 16'h1;
    end
    else begin
        trans_out_cnt_7 <= trans_out_cnt_7;
    end
end

reg [15:0] trans_in_cnt_8;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_8 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.start_write == 1'b1) begin
        trans_in_cnt_8 <= trans_in_cnt_8 + 16'h1;
    end
    else begin
        trans_in_cnt_8 <= trans_in_cnt_8;
    end
end

reg [15:0] trans_out_cnt_8;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_8 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.ap_continue == 1'b1) begin
        trans_out_cnt_8 <= trans_out_cnt_8 + 16'h1;
    end
    else begin
        trans_out_cnt_8 <= trans_out_cnt_8;
    end
end

reg [15:0] trans_in_cnt_9;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_9 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.start_write == 1'b1) begin
        trans_in_cnt_9 <= trans_in_cnt_9 + 16'h1;
    end
    else begin
        trans_in_cnt_9 <= trans_in_cnt_9;
    end
end

reg [15:0] trans_out_cnt_9;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_9 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.ap_continue == 1'b1) begin
        trans_out_cnt_9 <= trans_out_cnt_9 + 16'h1;
    end
    else begin
        trans_out_cnt_9 <= trans_out_cnt_9;
    end
end

reg [15:0] trans_in_cnt_10;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_10 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.start_write == 1'b1) begin
        trans_in_cnt_10 <= trans_in_cnt_10 + 16'h1;
    end
    else begin
        trans_in_cnt_10 <= trans_in_cnt_10;
    end
end

reg [15:0] trans_out_cnt_10;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_10 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.ap_continue == 1'b1) begin
        trans_out_cnt_10 <= trans_out_cnt_10 + 16'h1;
    end
    else begin
        trans_out_cnt_10 <= trans_out_cnt_10;
    end
end

reg [15:0] trans_in_cnt_11;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_11 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.start_write == 1'b1) begin
        trans_in_cnt_11 <= trans_in_cnt_11 + 16'h1;
    end
    else begin
        trans_in_cnt_11 <= trans_in_cnt_11;
    end
end

reg [15:0] trans_out_cnt_11;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_11 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.ap_continue == 1'b1) begin
        trans_out_cnt_11 <= trans_out_cnt_11 + 16'h1;
    end
    else begin
        trans_out_cnt_11 <= trans_out_cnt_11;
    end
end

reg [15:0] trans_in_cnt_12;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_in_cnt_12 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.start_write == 1'b1) begin
        trans_in_cnt_12 <= trans_in_cnt_12 + 16'h1;
    end
    else begin
        trans_in_cnt_12 <= trans_in_cnt_12;
    end
end

reg [15:0] trans_out_cnt_12;// for process grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0
always @(negedge dl_reset or posedge dl_clock) begin
    if (~dl_reset) begin
         trans_out_cnt_12 <= 16'h0;
    end
    else if (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done == 1'b1 && grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_continue == 1'b1) begin
        trans_out_cnt_12 <= trans_out_cnt_12 + 16'h1;
    end
    else begin
        trans_out_cnt_12 <= trans_out_cnt_12;
    end
end

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 0, 9, 9) fastv2_layer2_hls_hls_deadlock_detect_unit_0 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_0),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_0),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_0),
        .token_in_vec(token_in_vec_0),
        .dl_detect_in(dl_detect_out),
        .origin(origin[0]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_0),
        .out_chan_dep_data(out_chan_dep_data_0),
        .token_out_vec(token_out_vec_0),
        .dl_detect_out(dl_in_vec[0]));

    assign proc_0_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.blurred_c_blk_n);
    assign proc_0_data_PIPO_blk[0] = 1'b0;
    assign proc_0_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer4_write_dataflow_0_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.real_start & (trans_in_cnt_3 == trans_out_cnt_3) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer4_write_dataflow_0_U0_U.if_read);
    assign proc_0_TLF_FIFO_blk[0] = 1'b0;
    assign proc_0_input_sync_blk[0] = 1'b0;
    assign proc_0_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_0[0] = dl_detect_out ? proc_dep_vld_vec_0_reg[0] : (proc_0_data_FIFO_blk[0] | proc_0_data_PIPO_blk[0] | proc_0_start_FIFO_blk[0] | proc_0_TLF_FIFO_blk[0] | proc_0_input_sync_blk[0] | proc_0_output_sync_blk[0]);
    assign proc_0_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.blurred_c_blk_n);
    assign proc_0_data_PIPO_blk[1] = 1'b0;
    assign proc_0_start_FIFO_blk[1] = 1'b0;
    assign proc_0_TLF_FIFO_blk[1] = 1'b0;
    assign proc_0_input_sync_blk[1] = 1'b0;
    assign proc_0_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_0[1] = dl_detect_out ? proc_dep_vld_vec_0_reg[1] : (proc_0_data_FIFO_blk[1] | proc_0_data_PIPO_blk[1] | proc_0_start_FIFO_blk[1] | proc_0_TLF_FIFO_blk[1] | proc_0_input_sync_blk[1] | proc_0_output_sync_blk[1]);
    assign proc_0_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.resized_c_blk_n);
    assign proc_0_data_PIPO_blk[2] = 1'b0;
    assign proc_0_start_FIFO_blk[2] = 1'b0;
    assign proc_0_TLF_FIFO_blk[2] = 1'b0;
    assign proc_0_input_sync_blk[2] = 1'b0;
    assign proc_0_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_0[2] = dl_detect_out ? proc_dep_vld_vec_0_reg[2] : (proc_0_data_FIFO_blk[2] | proc_0_data_PIPO_blk[2] | proc_0_start_FIFO_blk[2] | proc_0_TLF_FIFO_blk[2] | proc_0_input_sync_blk[2] | proc_0_output_sync_blk[2]);
    assign proc_0_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.resized_c_blk_n);
    assign proc_0_data_PIPO_blk[3] = 1'b0;
    assign proc_0_start_FIFO_blk[3] = 1'b0;
    assign proc_0_TLF_FIFO_blk[3] = 1'b0;
    assign proc_0_input_sync_blk[3] = 1'b0;
    assign proc_0_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_0[3] = dl_detect_out ? proc_dep_vld_vec_0_reg[3] : (proc_0_data_FIFO_blk[3] | proc_0_data_PIPO_blk[3] | proc_0_start_FIFO_blk[3] | proc_0_TLF_FIFO_blk[3] | proc_0_input_sync_blk[3] | proc_0_output_sync_blk[3]);
    assign proc_0_data_FIFO_blk[4] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.selected_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.result_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_tile_rows_val9_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_tile_width_val10_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_tile_height_val11_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_cell_side_val12_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_cell_rows_val15_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.capacity_c_blk_n);
    assign proc_0_data_PIPO_blk[4] = 1'b0;
    assign proc_0_start_FIFO_blk[4] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_consume_and_select_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.real_start & (trans_in_cnt_3 == trans_out_cnt_3) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_consume_and_select_U0_U.if_read);
    assign proc_0_TLF_FIFO_blk[4] = 1'b0;
    assign proc_0_input_sync_blk[4] = 1'b0;
    assign proc_0_output_sync_blk[4] = 1'b0;
    assign proc_dep_vld_vec_0[4] = dl_detect_out ? proc_dep_vld_vec_0_reg[4] : (proc_0_data_FIFO_blk[4] | proc_0_data_PIPO_blk[4] | proc_0_start_FIFO_blk[4] | proc_0_TLF_FIFO_blk[4] | proc_0_input_sync_blk[4] | proc_0_output_sync_blk[4]);
    assign proc_0_data_FIFO_blk[5] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_budget_val4_c18_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_effective_width_val5_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_effective_height_val6_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_tile_cols_val8_c19_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.p_cell_cols_val14_c20_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.high_c21_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.low_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.dual_c22_blk_n);
    assign proc_0_data_PIPO_blk[5] = 1'b0;
    assign proc_0_start_FIFO_blk[5] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_scan_front4_quads_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.real_start & (trans_in_cnt_3 == trans_out_cnt_3) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_scan_front4_quads_U0_U.if_read);
    assign proc_0_TLF_FIFO_blk[5] = 1'b0;
    assign proc_0_input_sync_blk[5] = 1'b0;
    assign proc_0_output_sync_blk[5] = 1'b0;
    assign proc_dep_vld_vec_0[5] = dl_detect_out ? proc_dep_vld_vec_0_reg[5] : (proc_0_data_FIFO_blk[5] | proc_0_data_PIPO_blk[5] | proc_0_start_FIFO_blk[5] | proc_0_TLF_FIFO_blk[5] | proc_0_input_sync_blk[5] | proc_0_output_sync_blk[5]);
    assign proc_0_data_FIFO_blk[6] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.level_c_blk_n);
    assign proc_0_data_PIPO_blk[6] = 1'b0;
    assign proc_0_start_FIFO_blk[6] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_resize4_quads_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.real_start & (trans_in_cnt_3 == trans_out_cnt_3) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_resize4_quads_U0_U.if_read);
    assign proc_0_TLF_FIFO_blk[6] = 1'b0;
    assign proc_0_input_sync_blk[6] = 1'b0;
    assign proc_0_output_sync_blk[6] = 1'b0;
    assign proc_dep_vld_vec_0[6] = dl_detect_out ? proc_dep_vld_vec_0_reg[6] : (proc_0_data_FIFO_blk[6] | proc_0_data_PIPO_blk[6] | proc_0_start_FIFO_blk[6] | proc_0_TLF_FIFO_blk[6] | proc_0_input_sync_blk[6] | proc_0_output_sync_blk[6]);
    assign proc_0_data_FIFO_blk[7] = 1'b0;
    assign proc_0_data_PIPO_blk[7] = 1'b0;
    assign proc_0_start_FIFO_blk[7] = 1'b0;
    assign proc_0_TLF_FIFO_blk[7] = 1'b0;
    assign proc_0_input_sync_blk[7] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_entry_proc28_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0_ap_ready);
    assign proc_0_output_sync_blk[7] = 1'b0;
    assign proc_dep_vld_vec_0[7] = dl_detect_out ? proc_dep_vld_vec_0_reg[7] : (proc_0_data_FIFO_blk[7] | proc_0_data_PIPO_blk[7] | proc_0_start_FIFO_blk[7] | proc_0_TLF_FIFO_blk[7] | proc_0_input_sync_blk[7] | proc_0_output_sync_blk[7]);
    assign proc_0_data_FIFO_blk[8] = 1'b0;
    assign proc_0_data_PIPO_blk[8] = 1'b0;
    assign proc_0_start_FIFO_blk[8] = 1'b0;
    assign proc_0_TLF_FIFO_blk[8] = 1'b0;
    assign proc_0_input_sync_blk[8] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_entry_proc28_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.entry_proc28_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_read_dataflow_U0_ap_ready);
    assign proc_0_output_sync_blk[8] = 1'b0;
    assign proc_dep_vld_vec_0[8] = dl_detect_out ? proc_dep_vld_vec_0_reg[8] : (proc_0_data_FIFO_blk[8] | proc_0_data_PIPO_blk[8] | proc_0_start_FIFO_blk[8] | proc_0_TLF_FIFO_blk[8] | proc_0_input_sync_blk[8] | proc_0_output_sync_blk[8]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_0_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_0_reg <= proc_dep_vld_vec_0;
        end
    end
    assign in_chan_dep_vld_vec_0[0] = dep_chan_vld_1_0;
    assign in_chan_dep_data_vec_0[34 : 0] = dep_chan_data_1_0;
    assign token_in_vec_0[0] = token_1_0;
    assign in_chan_dep_vld_vec_0[1] = dep_chan_vld_2_0;
    assign in_chan_dep_data_vec_0[69 : 35] = dep_chan_data_2_0;
    assign token_in_vec_0[1] = token_2_0;
    assign in_chan_dep_vld_vec_0[2] = dep_chan_vld_8_0;
    assign in_chan_dep_data_vec_0[104 : 70] = dep_chan_data_8_0;
    assign token_in_vec_0[2] = token_8_0;
    assign in_chan_dep_vld_vec_0[3] = dep_chan_vld_10_0;
    assign in_chan_dep_data_vec_0[139 : 105] = dep_chan_data_10_0;
    assign token_in_vec_0[3] = token_10_0;
    assign in_chan_dep_vld_vec_0[4] = dep_chan_vld_24_0;
    assign in_chan_dep_data_vec_0[174 : 140] = dep_chan_data_24_0;
    assign token_in_vec_0[4] = token_24_0;
    assign in_chan_dep_vld_vec_0[5] = dep_chan_vld_25_0;
    assign in_chan_dep_data_vec_0[209 : 175] = dep_chan_data_25_0;
    assign token_in_vec_0[5] = token_25_0;
    assign in_chan_dep_vld_vec_0[6] = dep_chan_vld_28_0;
    assign in_chan_dep_data_vec_0[244 : 210] = dep_chan_data_28_0;
    assign token_in_vec_0[6] = token_28_0;
    assign in_chan_dep_vld_vec_0[7] = dep_chan_vld_30_0;
    assign in_chan_dep_data_vec_0[279 : 245] = dep_chan_data_30_0;
    assign token_in_vec_0[7] = token_30_0;
    assign in_chan_dep_vld_vec_0[8] = dep_chan_vld_31_0;
    assign in_chan_dep_data_vec_0[314 : 280] = dep_chan_data_31_0;
    assign token_in_vec_0[8] = token_31_0;
    assign dep_chan_vld_0_24 = out_chan_dep_vld_vec_0[0];
    assign dep_chan_data_0_24 = out_chan_dep_data_0;
    assign token_0_24 = token_out_vec_0[0];
    assign dep_chan_vld_0_25 = out_chan_dep_vld_vec_0[1];
    assign dep_chan_data_0_25 = out_chan_dep_data_0;
    assign token_0_25 = token_out_vec_0[1];
    assign dep_chan_vld_0_30 = out_chan_dep_vld_vec_0[2];
    assign dep_chan_data_0_30 = out_chan_dep_data_0;
    assign token_0_30 = token_out_vec_0[2];
    assign dep_chan_vld_0_31 = out_chan_dep_vld_vec_0[3];
    assign dep_chan_data_0_31 = out_chan_dep_data_0;
    assign token_0_31 = token_out_vec_0[3];
    assign dep_chan_vld_0_10 = out_chan_dep_vld_vec_0[4];
    assign dep_chan_data_0_10 = out_chan_dep_data_0;
    assign token_0_10 = token_out_vec_0[4];
    assign dep_chan_vld_0_8 = out_chan_dep_vld_vec_0[5];
    assign dep_chan_data_0_8 = out_chan_dep_data_0;
    assign token_0_8 = token_out_vec_0[5];
    assign dep_chan_vld_0_28 = out_chan_dep_vld_vec_0[6];
    assign dep_chan_data_0_28 = out_chan_dep_data_0;
    assign token_0_28 = token_out_vec_0[6];
    assign dep_chan_vld_0_1 = out_chan_dep_vld_vec_0[7];
    assign dep_chan_data_0_1 = out_chan_dep_data_0;
    assign token_0_1 = token_out_vec_0[7];
    assign dep_chan_vld_0_2 = out_chan_dep_vld_vec_0[8];
    assign dep_chan_data_0_2 = out_chan_dep_data_0;
    assign token_0_2 = token_out_vec_0[8];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 1, 8, 5) fastv2_layer2_hls_hls_deadlock_detect_unit_1 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_1),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_1),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_1),
        .token_in_vec(token_in_vec_1),
        .dl_detect_in(dl_detect_out),
        .origin(origin[1]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_1),
        .out_chan_dep_data(out_chan_dep_data_1),
        .token_out_vec(token_out_vec_1),
        .dl_detect_out(dl_in_vec[1]));

    assign proc_1_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.p_width_val_c11_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.p_height_val_c17_blk_n);
    assign proc_1_data_PIPO_blk[0] = 1'b0;
    assign proc_1_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_unpack_front4_words_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.real_start & (trans_in_cnt_1 == trans_out_cnt_1) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_unpack_front4_words_U0_U.if_read);
    assign proc_1_TLF_FIFO_blk[0] = 1'b0;
    assign proc_1_input_sync_blk[0] = 1'b0;
    assign proc_1_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_1[0] = dl_detect_out ? proc_dep_vld_vec_1_reg[0] : (proc_1_data_FIFO_blk[0] | proc_1_data_PIPO_blk[0] | proc_1_start_FIFO_blk[0] | proc_1_TLF_FIFO_blk[0] | proc_1_input_sync_blk[0] | proc_1_output_sync_blk[0]);
    assign proc_1_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.dw_c_blk_n);
    assign proc_1_data_PIPO_blk[1] = 1'b0;
    assign proc_1_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_1_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.real_start & (trans_in_cnt_1 == trans_out_cnt_1) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_1_U0_U.if_read);
    assign proc_1_TLF_FIFO_blk[1] = 1'b0;
    assign proc_1_input_sync_blk[1] = 1'b0;
    assign proc_1_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_1[1] = dl_detect_out ? proc_dep_vld_vec_1_reg[1] : (proc_1_data_FIFO_blk[1] | proc_1_data_PIPO_blk[1] | proc_1_start_FIFO_blk[1] | proc_1_TLF_FIFO_blk[1] | proc_1_input_sync_blk[1] | proc_1_output_sync_blk[1]);
    assign proc_1_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.dh_c23_blk_n);
    assign proc_1_data_PIPO_blk[2] = 1'b0;
    assign proc_1_start_FIFO_blk[2] = 1'b0;
    assign proc_1_TLF_FIFO_blk[2] = 1'b0;
    assign proc_1_input_sync_blk[2] = 1'b0;
    assign proc_1_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_1[2] = dl_detect_out ? proc_dep_vld_vec_1_reg[2] : (proc_1_data_FIFO_blk[2] | proc_1_data_PIPO_blk[2] | proc_1_start_FIFO_blk[2] | proc_1_TLF_FIFO_blk[2] | proc_1_input_sync_blk[2] | proc_1_output_sync_blk[2]);
    assign proc_1_data_FIFO_blk[3] = 1'b0;
    assign proc_1_data_PIPO_blk[3] = 1'b0;
    assign proc_1_start_FIFO_blk[3] = 1'b0;
    assign proc_1_TLF_FIFO_blk[3] = 1'b0;
    assign proc_1_input_sync_blk[3] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_entry_proc28_U0_ap_ready);
    assign proc_1_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_1[3] = dl_detect_out ? proc_dep_vld_vec_1_reg[3] : (proc_1_data_FIFO_blk[3] | proc_1_data_PIPO_blk[3] | proc_1_start_FIFO_blk[3] | proc_1_TLF_FIFO_blk[3] | proc_1_input_sync_blk[3] | proc_1_output_sync_blk[3]);
    assign proc_1_data_FIFO_blk[4] = 1'b0;
    assign proc_1_data_PIPO_blk[4] = 1'b0;
    assign proc_1_start_FIFO_blk[4] = 1'b0;
    assign proc_1_TLF_FIFO_blk[4] = 1'b0;
    assign proc_1_input_sync_blk[4] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_read_dataflow_U0_ap_ready);
    assign proc_1_output_sync_blk[4] = 1'b0;
    assign proc_dep_vld_vec_1[4] = dl_detect_out ? proc_dep_vld_vec_1_reg[4] : (proc_1_data_FIFO_blk[4] | proc_1_data_PIPO_blk[4] | proc_1_start_FIFO_blk[4] | proc_1_TLF_FIFO_blk[4] | proc_1_input_sync_blk[4] | proc_1_output_sync_blk[4]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_1_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_1_reg <= proc_dep_vld_vec_1;
        end
    end
    assign in_chan_dep_vld_vec_1[0] = dep_chan_vld_0_1;
    assign in_chan_dep_data_vec_1[34 : 0] = dep_chan_data_0_1;
    assign token_in_vec_1[0] = token_0_1;
    assign in_chan_dep_vld_vec_1[1] = dep_chan_vld_2_1;
    assign in_chan_dep_data_vec_1[69 : 35] = dep_chan_data_2_1;
    assign token_in_vec_1[1] = token_2_1;
    assign in_chan_dep_vld_vec_1[2] = dep_chan_vld_3_1;
    assign in_chan_dep_data_vec_1[104 : 70] = dep_chan_data_3_1;
    assign token_in_vec_1[2] = token_3_1;
    assign in_chan_dep_vld_vec_1[3] = dep_chan_vld_6_1;
    assign in_chan_dep_data_vec_1[139 : 105] = dep_chan_data_6_1;
    assign token_in_vec_1[3] = token_6_1;
    assign in_chan_dep_vld_vec_1[4] = dep_chan_vld_28_1;
    assign in_chan_dep_data_vec_1[174 : 140] = dep_chan_data_28_1;
    assign token_in_vec_1[4] = token_28_1;
    assign in_chan_dep_vld_vec_1[5] = dep_chan_vld_29_1;
    assign in_chan_dep_data_vec_1[209 : 175] = dep_chan_data_29_1;
    assign token_in_vec_1[5] = token_29_1;
    assign in_chan_dep_vld_vec_1[6] = dep_chan_vld_30_1;
    assign in_chan_dep_data_vec_1[244 : 210] = dep_chan_data_30_1;
    assign token_in_vec_1[6] = token_30_1;
    assign in_chan_dep_vld_vec_1[7] = dep_chan_vld_32_1;
    assign in_chan_dep_data_vec_1[279 : 245] = dep_chan_data_32_1;
    assign token_in_vec_1[7] = token_32_1;
    assign dep_chan_vld_1_6 = out_chan_dep_vld_vec_1[0];
    assign dep_chan_data_1_6 = out_chan_dep_data_1;
    assign token_1_6 = token_out_vec_1[0];
    assign dep_chan_vld_1_29 = out_chan_dep_vld_vec_1[1];
    assign dep_chan_data_1_29 = out_chan_dep_data_1;
    assign token_1_29 = token_out_vec_1[1];
    assign dep_chan_vld_1_28 = out_chan_dep_vld_vec_1[2];
    assign dep_chan_data_1_28 = out_chan_dep_data_1;
    assign token_1_28 = token_out_vec_1[2];
    assign dep_chan_vld_1_0 = out_chan_dep_vld_vec_1[3];
    assign dep_chan_data_1_0 = out_chan_dep_data_1;
    assign token_1_0 = token_out_vec_1[3];
    assign dep_chan_vld_1_2 = out_chan_dep_vld_vec_1[4];
    assign dep_chan_data_1_2 = out_chan_dep_data_1;
    assign token_1_2 = token_out_vec_1[4];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 2, 5, 5) fastv2_layer2_hls_hls_deadlock_detect_unit_2 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_2),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_2),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_2),
        .token_in_vec(token_in_vec_2),
        .dl_detect_in(dl_detect_out),
        .origin(origin[2]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_2),
        .out_chan_dep_data(out_chan_dep_data_2),
        .token_out_vec(token_out_vec_2),
        .dl_detect_out(dl_in_vec[2]));

    assign proc_2_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_emit_layer_blocks_U0.grp_p_anonymous_namespace_emit_layer_blocks_Pipeline_EmitLayerReadWords_fu_106.words_blk_n);
    assign proc_2_data_PIPO_blk[0] = 1'b0;
    assign proc_2_start_FIFO_blk[0] = 1'b0;
    assign proc_2_TLF_FIFO_blk[0] = 1'b0;
    assign proc_2_input_sync_blk[0] = 1'b0;
    assign proc_2_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_2[0] = dl_detect_out ? proc_dep_vld_vec_2_reg[0] : (proc_2_data_FIFO_blk[0] | proc_2_data_PIPO_blk[0] | proc_2_start_FIFO_blk[0] | proc_2_TLF_FIFO_blk[0] | proc_2_input_sync_blk[0] | proc_2_output_sync_blk[0]);
    assign proc_2_data_FIFO_blk[1] = 1'b0;
    assign proc_2_data_PIPO_blk[1] = 1'b0;
    assign proc_2_start_FIFO_blk[1] = 1'b0;
    assign proc_2_TLF_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul_loc_c5_channel_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul_loc_c5_channel_U.if_write);
    assign proc_2_input_sync_blk[1] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_read_dataflow_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_dataflow_Block_entry_proc_U0_ap_ready);
    assign proc_2_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_2[1] = dl_detect_out ? proc_dep_vld_vec_2_reg[1] : (proc_2_data_FIFO_blk[1] | proc_2_data_PIPO_blk[1] | proc_2_start_FIFO_blk[1] | proc_2_TLF_FIFO_blk[1] | proc_2_input_sync_blk[1] | proc_2_output_sync_blk[1]);
    assign proc_2_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.mul_loc_c1_blk_n);
    assign proc_2_data_PIPO_blk[2] = 1'b0;
    assign proc_2_start_FIFO_blk[2] = 1'b0;
    assign proc_2_TLF_FIFO_blk[2] = 1'b0;
    assign proc_2_input_sync_blk[2] = 1'b0;
    assign proc_2_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_2[2] = dl_detect_out ? proc_dep_vld_vec_2_reg[2] : (proc_2_data_FIFO_blk[2] | proc_2_data_PIPO_blk[2] | proc_2_start_FIFO_blk[2] | proc_2_TLF_FIFO_blk[2] | proc_2_input_sync_blk[2] | proc_2_output_sync_blk[2]);
    assign proc_2_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.mul_loc_c1_blk_n);
    assign proc_2_data_PIPO_blk[3] = 1'b0;
    assign proc_2_start_FIFO_blk[3] = 1'b0;
    assign proc_2_TLF_FIFO_blk[3] = 1'b0;
    assign proc_2_input_sync_blk[3] = 1'b0;
    assign proc_2_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_2[3] = dl_detect_out ? proc_dep_vld_vec_2_reg[3] : (proc_2_data_FIFO_blk[3] | proc_2_data_PIPO_blk[3] | proc_2_start_FIFO_blk[3] | proc_2_TLF_FIFO_blk[3] | proc_2_input_sync_blk[3] | proc_2_output_sync_blk[3]);
    assign proc_2_data_FIFO_blk[4] = 1'b0;
    assign proc_2_data_PIPO_blk[4] = 1'b0;
    assign proc_2_start_FIFO_blk[4] = 1'b0;
    assign proc_2_TLF_FIFO_blk[4] = 1'b0;
    assign proc_2_input_sync_blk[4] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_p_anonymous_namespace_layer4_read_dataflow_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.ap_sync_entry_proc28_U0_ap_ready);
    assign proc_2_output_sync_blk[4] = 1'b0;
    assign proc_dep_vld_vec_2[4] = dl_detect_out ? proc_dep_vld_vec_2_reg[4] : (proc_2_data_FIFO_blk[4] | proc_2_data_PIPO_blk[4] | proc_2_start_FIFO_blk[4] | proc_2_TLF_FIFO_blk[4] | proc_2_input_sync_blk[4] | proc_2_output_sync_blk[4]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_2_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_2_reg <= proc_dep_vld_vec_2;
        end
    end
    assign in_chan_dep_vld_vec_2[0] = dep_chan_vld_0_2;
    assign in_chan_dep_data_vec_2[34 : 0] = dep_chan_data_0_2;
    assign token_in_vec_2[0] = token_0_2;
    assign in_chan_dep_vld_vec_2[1] = dep_chan_vld_1_2;
    assign in_chan_dep_data_vec_2[69 : 35] = dep_chan_data_1_2;
    assign token_in_vec_2[1] = token_1_2;
    assign in_chan_dep_vld_vec_2[2] = dep_chan_vld_6_2;
    assign in_chan_dep_data_vec_2[104 : 70] = dep_chan_data_6_2;
    assign token_in_vec_2[2] = token_6_2;
    assign in_chan_dep_vld_vec_2[3] = dep_chan_vld_24_2;
    assign in_chan_dep_data_vec_2[139 : 105] = dep_chan_data_24_2;
    assign token_in_vec_2[3] = token_24_2;
    assign in_chan_dep_vld_vec_2[4] = dep_chan_vld_26_2;
    assign in_chan_dep_data_vec_2[174 : 140] = dep_chan_data_26_2;
    assign token_in_vec_2[4] = token_26_2;
    assign dep_chan_vld_2_6 = out_chan_dep_vld_vec_2[0];
    assign dep_chan_data_2_6 = out_chan_dep_data_2;
    assign token_2_6 = token_out_vec_2[0];
    assign dep_chan_vld_2_1 = out_chan_dep_vld_vec_2[1];
    assign dep_chan_data_2_1 = out_chan_dep_data_2;
    assign token_2_1 = token_out_vec_2[1];
    assign dep_chan_vld_2_24 = out_chan_dep_vld_vec_2[2];
    assign dep_chan_data_2_24 = out_chan_dep_data_2;
    assign token_2_24 = token_out_vec_2[2];
    assign dep_chan_vld_2_26 = out_chan_dep_vld_vec_2[3];
    assign dep_chan_data_2_26 = out_chan_dep_data_2;
    assign token_2_26 = token_out_vec_2[3];
    assign dep_chan_vld_2_0 = out_chan_dep_vld_vec_2[4];
    assign dep_chan_data_2_0 = out_chan_dep_data_2;
    assign token_2_0 = token_out_vec_2[4];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 3, 3, 4) fastv2_layer2_hls_hls_deadlock_detect_unit_3 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_3),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_3),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_3),
        .token_in_vec(token_in_vec_3),
        .dl_detect_in(dl_detect_out),
        .origin(origin[3]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_3),
        .out_chan_dep_data(out_chan_dep_data_3),
        .token_out_vec(token_out_vec_3),
        .dl_detect_out(dl_in_vec[3]));

    assign proc_3_data_FIFO_blk[0] = 1'b0;
    assign proc_3_data_PIPO_blk[0] = 1'b0;
    assign proc_3_start_FIFO_blk[0] = 1'b0;
    assign proc_3_TLF_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul_loc_c5_channel_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul_loc_c5_channel_U.if_write);
    assign proc_3_input_sync_blk[0] = 1'b0;
    assign proc_3_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_3[0] = dl_detect_out ? proc_dep_vld_vec_3_reg[0] : (proc_3_data_FIFO_blk[0] | proc_3_data_PIPO_blk[0] | proc_3_start_FIFO_blk[0] | proc_3_TLF_FIFO_blk[0] | proc_3_input_sync_blk[0] | proc_3_output_sync_blk[0]);
    assign proc_3_data_FIFO_blk[1] = 1'b0;
    assign proc_3_data_PIPO_blk[1] = 1'b0;
    assign proc_3_start_FIFO_blk[1] = 1'b0;
    assign proc_3_TLF_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.mul_loc_tmp_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.ap_done & ap_done_reg_1 & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.mul_loc_tmp_U.if_read);
    assign proc_3_input_sync_blk[1] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_sync_entry_proc27_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_sync_p_anonymous_namespace_load_layer_blocks_U0_ap_ready);
    assign proc_3_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_3[1] = dl_detect_out ? proc_dep_vld_vec_3_reg[1] : (proc_3_data_FIFO_blk[1] | proc_3_data_PIPO_blk[1] | proc_3_start_FIFO_blk[1] | proc_3_TLF_FIFO_blk[1] | proc_3_input_sync_blk[1] | proc_3_output_sync_blk[1]);
    assign proc_3_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.mul_loc_c1_blk_n);
    assign proc_3_data_PIPO_blk[2] = 1'b0;
    assign proc_3_start_FIFO_blk[2] = 1'b0;
    assign proc_3_TLF_FIFO_blk[2] = 1'b0;
    assign proc_3_input_sync_blk[2] = 1'b0;
    assign proc_3_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_3[2] = dl_detect_out ? proc_dep_vld_vec_3_reg[2] : (proc_3_data_FIFO_blk[2] | proc_3_data_PIPO_blk[2] | proc_3_start_FIFO_blk[2] | proc_3_TLF_FIFO_blk[2] | proc_3_input_sync_blk[2] | proc_3_output_sync_blk[2]);
    assign proc_3_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.entry_proc27_U0.mul_loc_c1_blk_n);
    assign proc_3_data_PIPO_blk[3] = 1'b0;
    assign proc_3_start_FIFO_blk[3] = 1'b0;
    assign proc_3_TLF_FIFO_blk[3] = 1'b0;
    assign proc_3_input_sync_blk[3] = 1'b0;
    assign proc_3_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_3[3] = dl_detect_out ? proc_dep_vld_vec_3_reg[3] : (proc_3_data_FIFO_blk[3] | proc_3_data_PIPO_blk[3] | proc_3_start_FIFO_blk[3] | proc_3_TLF_FIFO_blk[3] | proc_3_input_sync_blk[3] | proc_3_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_3_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_3_reg <= proc_dep_vld_vec_3;
        end
    end
    assign in_chan_dep_vld_vec_3[0] = dep_chan_vld_4_3;
    assign in_chan_dep_data_vec_3[34 : 0] = dep_chan_data_4_3;
    assign token_in_vec_3[0] = token_4_3;
    assign in_chan_dep_vld_vec_3[1] = dep_chan_vld_24_3;
    assign in_chan_dep_data_vec_3[69 : 35] = dep_chan_data_24_3;
    assign token_in_vec_3[1] = token_24_3;
    assign in_chan_dep_vld_vec_3[2] = dep_chan_vld_26_3;
    assign in_chan_dep_data_vec_3[104 : 70] = dep_chan_data_26_3;
    assign token_in_vec_3[2] = token_26_3;
    assign dep_chan_vld_3_1 = out_chan_dep_vld_vec_3[0];
    assign dep_chan_data_3_1 = out_chan_dep_data_3;
    assign token_3_1 = token_out_vec_3[0];
    assign dep_chan_vld_3_4 = out_chan_dep_vld_vec_3[1];
    assign dep_chan_data_3_4 = out_chan_dep_data_3;
    assign token_3_4 = token_out_vec_3[1];
    assign dep_chan_vld_3_24 = out_chan_dep_vld_vec_3[2];
    assign dep_chan_data_3_24 = out_chan_dep_data_3;
    assign token_3_24 = token_out_vec_3[2];
    assign dep_chan_vld_3_26 = out_chan_dep_vld_vec_3[3];
    assign dep_chan_data_3_26 = out_chan_dep_data_3;
    assign token_3_26 = token_out_vec_3[3];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 4, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_4 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_4),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_4),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_4),
        .token_in_vec(token_in_vec_4),
        .dl_detect_in(dl_detect_out),
        .origin(origin[4]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_4),
        .out_chan_dep_data(out_chan_dep_data_4),
        .token_out_vec(token_out_vec_4),
        .dl_detect_out(dl_in_vec[4]));

    assign proc_4_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.blocks_i_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.mul_loc_c_blk_n);
    assign proc_4_data_PIPO_blk[0] = 1'b0;
    assign proc_4_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.start_for_p_anonymous_namespace_emit_layer_blocks_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.real_start & (trans_in_cnt_0 == trans_out_cnt_0) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.start_for_p_anonymous_namespace_emit_layer_blocks_U0_U.if_read);
    assign proc_4_TLF_FIFO_blk[0] = 1'b0;
    assign proc_4_input_sync_blk[0] = 1'b0;
    assign proc_4_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_4[0] = dl_detect_out ? proc_dep_vld_vec_4_reg[0] : (proc_4_data_FIFO_blk[0] | proc_4_data_PIPO_blk[0] | proc_4_start_FIFO_blk[0] | proc_4_TLF_FIFO_blk[0] | proc_4_input_sync_blk[0] | proc_4_output_sync_blk[0]);
    assign proc_4_data_FIFO_blk[1] = 1'b0;
    assign proc_4_data_PIPO_blk[1] = 1'b0;
    assign proc_4_start_FIFO_blk[1] = 1'b0;
    assign proc_4_TLF_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.mul_loc_tmp_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.mul_loc_tmp_U.if_write);
    assign proc_4_input_sync_blk[1] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_sync_p_anonymous_namespace_load_layer_blocks_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_load_layer_blocks_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.ap_sync_entry_proc27_U0_ap_ready);
    assign proc_4_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_4[1] = dl_detect_out ? proc_dep_vld_vec_4_reg[1] : (proc_4_data_FIFO_blk[1] | proc_4_data_PIPO_blk[1] | proc_4_start_FIFO_blk[1] | proc_4_TLF_FIFO_blk[1] | proc_4_input_sync_blk[1] | proc_4_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_4_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_4_reg <= proc_dep_vld_vec_4;
        end
    end
    assign in_chan_dep_vld_vec_4[0] = dep_chan_vld_3_4;
    assign in_chan_dep_data_vec_4[34 : 0] = dep_chan_data_3_4;
    assign token_in_vec_4[0] = token_3_4;
    assign in_chan_dep_vld_vec_4[1] = dep_chan_vld_5_4;
    assign in_chan_dep_data_vec_4[69 : 35] = dep_chan_data_5_4;
    assign token_in_vec_4[1] = token_5_4;
    assign dep_chan_vld_4_5 = out_chan_dep_vld_vec_4[0];
    assign dep_chan_data_4_5 = out_chan_dep_data_4;
    assign token_4_5 = token_out_vec_4[0];
    assign dep_chan_vld_4_3 = out_chan_dep_vld_vec_4[1];
    assign dep_chan_data_4_3 = out_chan_dep_data_4;
    assign token_4_3 = token_out_vec_4[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_emit_layer_blocks_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 5, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_5 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_5),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_5),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_5),
        .token_in_vec(token_in_vec_5),
        .dl_detect_in(dl_detect_out),
        .origin(origin[5]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_5),
        .out_chan_dep_data(out_chan_dep_data_5),
        .token_out_vec(token_out_vec_5),
        .dl_detect_out(dl_in_vec[5]));

    assign proc_5_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_emit_layer_blocks_U0.blocks_i_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_emit_layer_blocks_U0.mul_loc_blk_n);
    assign proc_5_data_PIPO_blk[0] = 1'b0;
    assign proc_5_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.start_for_p_anonymous_namespace_emit_layer_blocks_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_emit_layer_blocks_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.start_for_p_anonymous_namespace_emit_layer_blocks_U0_U.if_write);
    assign proc_5_TLF_FIFO_blk[0] = 1'b0;
    assign proc_5_input_sync_blk[0] = 1'b0;
    assign proc_5_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_5[0] = dl_detect_out ? proc_dep_vld_vec_5_reg[0] : (proc_5_data_FIFO_blk[0] | proc_5_data_PIPO_blk[0] | proc_5_start_FIFO_blk[0] | proc_5_TLF_FIFO_blk[0] | proc_5_input_sync_blk[0] | proc_5_output_sync_blk[0]);
    assign proc_5_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_read_dataflow_U0.p_anonymous_namespace_emit_layer_blocks_U0.grp_p_anonymous_namespace_emit_layer_blocks_Pipeline_EmitLayerReadWords_fu_106.words_blk_n);
    assign proc_5_data_PIPO_blk[1] = 1'b0;
    assign proc_5_start_FIFO_blk[1] = 1'b0;
    assign proc_5_TLF_FIFO_blk[1] = 1'b0;
    assign proc_5_input_sync_blk[1] = 1'b0;
    assign proc_5_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_5[1] = dl_detect_out ? proc_dep_vld_vec_5_reg[1] : (proc_5_data_FIFO_blk[1] | proc_5_data_PIPO_blk[1] | proc_5_start_FIFO_blk[1] | proc_5_TLF_FIFO_blk[1] | proc_5_input_sync_blk[1] | proc_5_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_5_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_5_reg <= proc_dep_vld_vec_5;
        end
    end
    assign in_chan_dep_vld_vec_5[0] = dep_chan_vld_4_5;
    assign in_chan_dep_data_vec_5[34 : 0] = dep_chan_data_4_5;
    assign token_in_vec_5[0] = token_4_5;
    assign in_chan_dep_vld_vec_5[1] = dep_chan_vld_6_5;
    assign in_chan_dep_data_vec_5[69 : 35] = dep_chan_data_6_5;
    assign token_in_vec_5[1] = token_6_5;
    assign dep_chan_vld_5_4 = out_chan_dep_vld_vec_5[0];
    assign dep_chan_data_5_4 = out_chan_dep_data_5;
    assign token_5_4 = token_out_vec_5[0];
    assign dep_chan_vld_5_6 = out_chan_dep_vld_vec_5[1];
    assign dep_chan_data_5_6 = out_chan_dep_data_5;
    assign token_5_6 = token_out_vec_5[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 6, 4, 4) fastv2_layer2_hls_hls_deadlock_detect_unit_6 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_6),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_6),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_6),
        .token_in_vec(token_in_vec_6),
        .dl_detect_in(dl_detect_out),
        .origin(origin[6]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_6),
        .out_chan_dep_data(out_chan_dep_data_6),
        .token_out_vec(token_out_vec_6),
        .dl_detect_out(dl_in_vec[6]));

    assign proc_6_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.grp_p_anonymous_namespace_unpack_front4_words_Pipeline_VITIS_LOOP_9_1_UnpackQuads_fu_82.words_blk_n);
    assign proc_6_data_PIPO_blk[0] = 1'b0;
    assign proc_6_start_FIFO_blk[0] = 1'b0;
    assign proc_6_TLF_FIFO_blk[0] = 1'b0;
    assign proc_6_input_sync_blk[0] = 1'b0;
    assign proc_6_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_6[0] = dl_detect_out ? proc_dep_vld_vec_6_reg[0] : (proc_6_data_FIFO_blk[0] | proc_6_data_PIPO_blk[0] | proc_6_start_FIFO_blk[0] | proc_6_TLF_FIFO_blk[0] | proc_6_input_sync_blk[0] | proc_6_output_sync_blk[0]);
    assign proc_6_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.grp_p_anonymous_namespace_unpack_front4_words_Pipeline_VITIS_LOOP_9_1_UnpackQuads_fu_82.words_blk_n);
    assign proc_6_data_PIPO_blk[1] = 1'b0;
    assign proc_6_start_FIFO_blk[1] = 1'b0;
    assign proc_6_TLF_FIFO_blk[1] = 1'b0;
    assign proc_6_input_sync_blk[1] = 1'b0;
    assign proc_6_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_6[1] = dl_detect_out ? proc_dep_vld_vec_6_reg[1] : (proc_6_data_FIFO_blk[1] | proc_6_data_PIPO_blk[1] | proc_6_start_FIFO_blk[1] | proc_6_TLF_FIFO_blk[1] | proc_6_input_sync_blk[1] | proc_6_output_sync_blk[1]);
    assign proc_6_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.grp_p_anonymous_namespace_unpack_front4_words_Pipeline_VITIS_LOOP_9_1_UnpackQuads_fu_82.quads_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.p_width_val_c10_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.p_height_val_c16_blk_n);
    assign proc_6_data_PIPO_blk[2] = 1'b0;
    assign proc_6_start_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_fork_layer4_quads_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.real_start & (trans_in_cnt_2 == trans_out_cnt_2) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_fork_layer4_quads_U0_U.if_read);
    assign proc_6_TLF_FIFO_blk[2] = 1'b0;
    assign proc_6_input_sync_blk[2] = 1'b0;
    assign proc_6_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_6[2] = dl_detect_out ? proc_dep_vld_vec_6_reg[2] : (proc_6_data_FIFO_blk[2] | proc_6_data_PIPO_blk[2] | proc_6_start_FIFO_blk[2] | proc_6_TLF_FIFO_blk[2] | proc_6_input_sync_blk[2] | proc_6_output_sync_blk[2]);
    assign proc_6_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.width_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.height_blk_n);
    assign proc_6_data_PIPO_blk[3] = 1'b0;
    assign proc_6_start_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_unpack_front4_words_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_unpack_front4_words_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_unpack_front4_words_U0_U.if_write);
    assign proc_6_TLF_FIFO_blk[3] = 1'b0;
    assign proc_6_input_sync_blk[3] = 1'b0;
    assign proc_6_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_6[3] = dl_detect_out ? proc_dep_vld_vec_6_reg[3] : (proc_6_data_FIFO_blk[3] | proc_6_data_PIPO_blk[3] | proc_6_start_FIFO_blk[3] | proc_6_TLF_FIFO_blk[3] | proc_6_input_sync_blk[3] | proc_6_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_6_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_6_reg <= proc_dep_vld_vec_6;
        end
    end
    assign in_chan_dep_vld_vec_6[0] = dep_chan_vld_1_6;
    assign in_chan_dep_data_vec_6[34 : 0] = dep_chan_data_1_6;
    assign token_in_vec_6[0] = token_1_6;
    assign in_chan_dep_vld_vec_6[1] = dep_chan_vld_2_6;
    assign in_chan_dep_data_vec_6[69 : 35] = dep_chan_data_2_6;
    assign token_in_vec_6[1] = token_2_6;
    assign in_chan_dep_vld_vec_6[2] = dep_chan_vld_5_6;
    assign in_chan_dep_data_vec_6[104 : 70] = dep_chan_data_5_6;
    assign token_in_vec_6[2] = token_5_6;
    assign in_chan_dep_vld_vec_6[3] = dep_chan_vld_7_6;
    assign in_chan_dep_data_vec_6[139 : 105] = dep_chan_data_7_6;
    assign token_in_vec_6[3] = token_7_6;
    assign dep_chan_vld_6_2 = out_chan_dep_vld_vec_6[0];
    assign dep_chan_data_6_2 = out_chan_dep_data_6;
    assign token_6_2 = token_out_vec_6[0];
    assign dep_chan_vld_6_5 = out_chan_dep_vld_vec_6[1];
    assign dep_chan_data_6_5 = out_chan_dep_data_6;
    assign token_6_5 = token_out_vec_6[1];
    assign dep_chan_vld_6_7 = out_chan_dep_vld_vec_6[2];
    assign dep_chan_data_6_7 = out_chan_dep_data_6;
    assign token_6_7 = token_out_vec_6[2];
    assign dep_chan_vld_6_1 = out_chan_dep_vld_vec_6[3];
    assign dep_chan_data_6_1 = out_chan_dep_data_6;
    assign token_6_1 = token_out_vec_6[3];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 7, 4, 4) fastv2_layer2_hls_hls_deadlock_detect_unit_7 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_7),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_7),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_7),
        .token_in_vec(token_in_vec_7),
        .dl_detect_in(dl_detect_out),
        .origin(origin[7]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_7),
        .out_chan_dep_data(out_chan_dep_data_7),
        .token_out_vec(token_out_vec_7),
        .dl_detect_out(dl_in_vec[7]));

    assign proc_7_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.grp_p_anonymous_namespace_fork_layer4_quads_Pipeline_VITIS_LOOP_11_1_ForkLayerQuads_fu_126.quads_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.width_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.height_blk_n);
    assign proc_7_data_PIPO_blk[0] = 1'b0;
    assign proc_7_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_fork_layer4_quads_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_fork_layer4_quads_U0_U.if_write);
    assign proc_7_TLF_FIFO_blk[0] = 1'b0;
    assign proc_7_input_sync_blk[0] = 1'b0;
    assign proc_7_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_7[0] = dl_detect_out ? proc_dep_vld_vec_7_reg[0] : (proc_7_data_FIFO_blk[0] | proc_7_data_PIPO_blk[0] | proc_7_start_FIFO_blk[0] | proc_7_TLF_FIFO_blk[0] | proc_7_input_sync_blk[0] | proc_7_output_sync_blk[0]);
    assign proc_7_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.grp_p_anonymous_namespace_fork_layer4_quads_Pipeline_VITIS_LOOP_11_1_ForkLayerQuads_fu_126.fast_raw_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.p_width_val_c9_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.p_height_val_c15_blk_n);
    assign proc_7_data_PIPO_blk[1] = 1'b0;
    assign proc_7_start_FIFO_blk[1] = 1'b0;
    assign proc_7_TLF_FIFO_blk[1] = 1'b0;
    assign proc_7_input_sync_blk[1] = 1'b0;
    assign proc_7_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_7[1] = dl_detect_out ? proc_dep_vld_vec_7_reg[1] : (proc_7_data_FIFO_blk[1] | proc_7_data_PIPO_blk[1] | proc_7_start_FIFO_blk[1] | proc_7_TLF_FIFO_blk[1] | proc_7_input_sync_blk[1] | proc_7_output_sync_blk[1]);
    assign proc_7_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.grp_p_anonymous_namespace_fork_layer4_quads_Pipeline_VITIS_LOOP_11_1_ForkLayerQuads_fu_126.gaussian_raw_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.p_width_val_c8_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.p_height_val_c14_blk_n);
    assign proc_7_data_PIPO_blk[2] = 1'b0;
    assign proc_7_start_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_horizontal_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.real_start & (trans_in_cnt_7 == trans_out_cnt_7) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_horizontal_U0_U.if_read);
    assign proc_7_TLF_FIFO_blk[2] = 1'b0;
    assign proc_7_input_sync_blk[2] = 1'b0;
    assign proc_7_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_7[2] = dl_detect_out ? proc_dep_vld_vec_7_reg[2] : (proc_7_data_FIFO_blk[2] | proc_7_data_PIPO_blk[2] | proc_7_start_FIFO_blk[2] | proc_7_TLF_FIFO_blk[2] | proc_7_input_sync_blk[2] | proc_7_output_sync_blk[2]);
    assign proc_7_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.grp_p_anonymous_namespace_fork_layer4_quads_Pipeline_VITIS_LOOP_11_1_ForkLayerQuads_fu_126.resize_raw_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.p_width_val_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_fork_layer4_quads_U0.p_height_val_c_blk_n);
    assign proc_7_data_PIPO_blk[3] = 1'b0;
    assign proc_7_start_FIFO_blk[3] = 1'b0;
    assign proc_7_TLF_FIFO_blk[3] = 1'b0;
    assign proc_7_input_sync_blk[3] = 1'b0;
    assign proc_7_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_7[3] = dl_detect_out ? proc_dep_vld_vec_7_reg[3] : (proc_7_data_FIFO_blk[3] | proc_7_data_PIPO_blk[3] | proc_7_start_FIFO_blk[3] | proc_7_TLF_FIFO_blk[3] | proc_7_input_sync_blk[3] | proc_7_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_7_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_7_reg <= proc_dep_vld_vec_7;
        end
    end
    assign in_chan_dep_vld_vec_7[0] = dep_chan_vld_6_7;
    assign in_chan_dep_data_vec_7[34 : 0] = dep_chan_data_6_7;
    assign token_in_vec_7[0] = token_6_7;
    assign in_chan_dep_vld_vec_7[1] = dep_chan_vld_8_7;
    assign in_chan_dep_data_vec_7[69 : 35] = dep_chan_data_8_7;
    assign token_in_vec_7[1] = token_8_7;
    assign in_chan_dep_vld_vec_7[2] = dep_chan_vld_21_7;
    assign in_chan_dep_data_vec_7[104 : 70] = dep_chan_data_21_7;
    assign token_in_vec_7[2] = token_21_7;
    assign in_chan_dep_vld_vec_7[3] = dep_chan_vld_28_7;
    assign in_chan_dep_data_vec_7[139 : 105] = dep_chan_data_28_7;
    assign token_in_vec_7[3] = token_28_7;
    assign dep_chan_vld_7_6 = out_chan_dep_vld_vec_7[0];
    assign dep_chan_data_7_6 = out_chan_dep_data_7;
    assign token_7_6 = token_out_vec_7[0];
    assign dep_chan_vld_7_8 = out_chan_dep_vld_vec_7[1];
    assign dep_chan_data_7_8 = out_chan_dep_data_7;
    assign token_7_8 = token_out_vec_7[1];
    assign dep_chan_vld_7_21 = out_chan_dep_vld_vec_7[2];
    assign dep_chan_data_7_21 = out_chan_dep_data_7;
    assign token_7_21 = token_out_vec_7[2];
    assign dep_chan_vld_7_28 = out_chan_dep_vld_vec_7[3];
    assign dep_chan_data_7_28 = out_chan_dep_data_7;
    assign token_7_28 = token_out_vec_7[3];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 8, 4, 4) fastv2_layer2_hls_hls_deadlock_detect_unit_8 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_8),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_8),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_8),
        .token_in_vec(token_in_vec_8),
        .dl_detect_in(dl_detect_out),
        .origin(origin[8]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_8),
        .out_chan_dep_data(out_chan_dep_data_8),
        .token_out_vec(token_out_vec_8),
        .dl_detect_out(dl_in_vec[8]));

    assign proc_8_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.grp_p_anonymous_namespace_scan_front4_quads_Pipeline_RasterQuads_fu_574.fast_raw_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_width_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_height_val_blk_n);
    assign proc_8_data_PIPO_blk[0] = 1'b0;
    assign proc_8_start_FIFO_blk[0] = 1'b0;
    assign proc_8_TLF_FIFO_blk[0] = 1'b0;
    assign proc_8_input_sync_blk[0] = 1'b0;
    assign proc_8_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_8[0] = dl_detect_out ? proc_dep_vld_vec_8_reg[0] : (proc_8_data_FIFO_blk[0] | proc_8_data_PIPO_blk[0] | proc_8_start_FIFO_blk[0] | proc_8_TLF_FIFO_blk[0] | proc_8_input_sync_blk[0] | proc_8_output_sync_blk[0]);
    assign proc_8_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.candidate_quads_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.grp_p_anonymous_namespace_scan_front4_quads_Pipeline_RasterQuads_fu_574.candidate_quads_blk_n);
    assign proc_8_data_PIPO_blk[1] = 1'b0;
    assign proc_8_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_serialize_front4_quads_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.real_start & (trans_in_cnt_4 == trans_out_cnt_4) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_serialize_front4_quads_U0_U.if_read);
    assign proc_8_TLF_FIFO_blk[1] = 1'b0;
    assign proc_8_input_sync_blk[1] = 1'b0;
    assign proc_8_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_8[1] = dl_detect_out ? proc_dep_vld_vec_8_reg[1] : (proc_8_data_FIFO_blk[1] | proc_8_data_PIPO_blk[1] | proc_8_start_FIFO_blk[1] | proc_8_TLF_FIFO_blk[1] | proc_8_input_sync_blk[1] | proc_8_output_sync_blk[1]);
    assign proc_8_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_budget_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_effective_width_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_effective_height_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_tile_cols_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_cell_cols_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.high_r_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.low_r_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.dual_blk_n);
    assign proc_8_data_PIPO_blk[2] = 1'b0;
    assign proc_8_start_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_scan_front4_quads_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_scan_front4_quads_U0_U.if_write);
    assign proc_8_TLF_FIFO_blk[2] = 1'b0;
    assign proc_8_input_sync_blk[2] = 1'b0;
    assign proc_8_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_8[2] = dl_detect_out ? proc_dep_vld_vec_8_reg[2] : (proc_8_data_FIFO_blk[2] | proc_8_data_PIPO_blk[2] | proc_8_start_FIFO_blk[2] | proc_8_TLF_FIFO_blk[2] | proc_8_input_sync_blk[2] | proc_8_output_sync_blk[2]);
    assign proc_8_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_budget_val4_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_tile_cols_val8_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.p_cell_cols_val14_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.high_c_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_scan_front4_quads_U0.dual_c_blk_n);
    assign proc_8_data_PIPO_blk[3] = 1'b0;
    assign proc_8_start_FIFO_blk[3] = 1'b0;
    assign proc_8_TLF_FIFO_blk[3] = 1'b0;
    assign proc_8_input_sync_blk[3] = 1'b0;
    assign proc_8_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_8[3] = dl_detect_out ? proc_dep_vld_vec_8_reg[3] : (proc_8_data_FIFO_blk[3] | proc_8_data_PIPO_blk[3] | proc_8_start_FIFO_blk[3] | proc_8_TLF_FIFO_blk[3] | proc_8_input_sync_blk[3] | proc_8_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_8_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_8_reg <= proc_dep_vld_vec_8;
        end
    end
    assign in_chan_dep_vld_vec_8[0] = dep_chan_vld_0_8;
    assign in_chan_dep_data_vec_8[34 : 0] = dep_chan_data_0_8;
    assign token_in_vec_8[0] = token_0_8;
    assign in_chan_dep_vld_vec_8[1] = dep_chan_vld_7_8;
    assign in_chan_dep_data_vec_8[69 : 35] = dep_chan_data_7_8;
    assign token_in_vec_8[1] = token_7_8;
    assign in_chan_dep_vld_vec_8[2] = dep_chan_vld_9_8;
    assign in_chan_dep_data_vec_8[104 : 70] = dep_chan_data_9_8;
    assign token_in_vec_8[2] = token_9_8;
    assign in_chan_dep_vld_vec_8[3] = dep_chan_vld_10_8;
    assign in_chan_dep_data_vec_8[139 : 105] = dep_chan_data_10_8;
    assign token_in_vec_8[3] = token_10_8;
    assign dep_chan_vld_8_7 = out_chan_dep_vld_vec_8[0];
    assign dep_chan_data_8_7 = out_chan_dep_data_8;
    assign token_8_7 = token_out_vec_8[0];
    assign dep_chan_vld_8_9 = out_chan_dep_vld_vec_8[1];
    assign dep_chan_data_8_9 = out_chan_dep_data_8;
    assign token_8_9 = token_out_vec_8[1];
    assign dep_chan_vld_8_0 = out_chan_dep_vld_vec_8[2];
    assign dep_chan_data_8_0 = out_chan_dep_data_8;
    assign token_8_0 = token_out_vec_8[2];
    assign dep_chan_vld_8_10 = out_chan_dep_vld_vec_8[3];
    assign dep_chan_data_8_10 = out_chan_dep_data_8;
    assign token_8_10 = token_out_vec_8[3];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_serialize_front4_quads_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 9, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_9 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_9),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_9),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_9),
        .token_in_vec(token_in_vec_9),
        .dl_detect_in(dl_detect_out),
        .origin(origin[9]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_9),
        .out_chan_dep_data(out_chan_dep_data_9),
        .token_out_vec(token_out_vec_9),
        .dl_detect_out(dl_in_vec[9]));

    assign proc_9_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_serialize_front4_quads_U0.grp_p_anonymous_namespace_serialize_front4_quads_Pipeline_MergeQuads_fu_41.candidate_quads_blk_n);
    assign proc_9_data_PIPO_blk[0] = 1'b0;
    assign proc_9_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_serialize_front4_quads_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_serialize_front4_quads_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_serialize_front4_quads_U0_U.if_write);
    assign proc_9_TLF_FIFO_blk[0] = 1'b0;
    assign proc_9_input_sync_blk[0] = 1'b0;
    assign proc_9_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_9[0] = dl_detect_out ? proc_dep_vld_vec_9_reg[0] : (proc_9_data_FIFO_blk[0] | proc_9_data_PIPO_blk[0] | proc_9_start_FIFO_blk[0] | proc_9_TLF_FIFO_blk[0] | proc_9_input_sync_blk[0] | proc_9_output_sync_blk[0]);
    assign proc_9_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_serialize_front4_quads_U0.candidates_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_serialize_front4_quads_U0.grp_p_anonymous_namespace_serialize_front4_quads_Pipeline_MergeQuads_fu_41.candidates_blk_n);
    assign proc_9_data_PIPO_blk[1] = 1'b0;
    assign proc_9_start_FIFO_blk[1] = 1'b0;
    assign proc_9_TLF_FIFO_blk[1] = 1'b0;
    assign proc_9_input_sync_blk[1] = 1'b0;
    assign proc_9_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_9[1] = dl_detect_out ? proc_dep_vld_vec_9_reg[1] : (proc_9_data_FIFO_blk[1] | proc_9_data_PIPO_blk[1] | proc_9_start_FIFO_blk[1] | proc_9_TLF_FIFO_blk[1] | proc_9_input_sync_blk[1] | proc_9_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_9_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_9_reg <= proc_dep_vld_vec_9;
        end
    end
    assign in_chan_dep_vld_vec_9[0] = dep_chan_vld_8_9;
    assign in_chan_dep_data_vec_9[34 : 0] = dep_chan_data_8_9;
    assign token_in_vec_9[0] = token_8_9;
    assign in_chan_dep_vld_vec_9[1] = dep_chan_vld_10_9;
    assign in_chan_dep_data_vec_9[69 : 35] = dep_chan_data_10_9;
    assign token_in_vec_9[1] = token_10_9;
    assign dep_chan_vld_9_8 = out_chan_dep_vld_vec_9[0];
    assign dep_chan_data_9_8 = out_chan_dep_data_9;
    assign token_9_8 = token_out_vec_9[0];
    assign dep_chan_vld_9_10 = out_chan_dep_vld_vec_9[1];
    assign dep_chan_data_9_10 = out_chan_dep_data_9;
    assign token_9_10 = token_out_vec_9[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 10, 6, 6) fastv2_layer2_hls_hls_deadlock_detect_unit_10 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_10),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_10),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_10),
        .token_in_vec(token_in_vec_10),
        .dl_detect_in(dl_detect_out),
        .origin(origin[10]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_10),
        .out_chan_dep_data(out_chan_dep_data_10),
        .token_out_vec(token_out_vec_10),
        .dl_detect_out(dl_in_vec[10]));

    assign proc_10_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.candidates_blk_n);
    assign proc_10_data_PIPO_blk[0] = 1'b0;
    assign proc_10_start_FIFO_blk[0] = 1'b0;
    assign proc_10_TLF_FIFO_blk[0] = 1'b0;
    assign proc_10_input_sync_blk[0] = 1'b0;
    assign proc_10_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_10[0] = dl_detect_out ? proc_dep_vld_vec_10_reg[0] : (proc_10_data_FIFO_blk[0] | proc_10_data_PIPO_blk[0] | proc_10_start_FIFO_blk[0] | proc_10_TLF_FIFO_blk[0] | proc_10_input_sync_blk[0] | proc_10_output_sync_blk[0]);
    assign proc_10_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.selected_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.result_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_tile_rows_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_tile_width_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_tile_height_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_cell_side_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_cell_rows_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.selected_capacity_blk_n);
    assign proc_10_data_PIPO_blk[1] = 1'b0;
    assign proc_10_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_consume_and_select_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_consume_and_select_U0_U.if_write);
    assign proc_10_TLF_FIFO_blk[1] = 1'b0;
    assign proc_10_input_sync_blk[1] = 1'b0;
    assign proc_10_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_10[1] = dl_detect_out ? proc_dep_vld_vec_10_reg[1] : (proc_10_data_FIFO_blk[1] | proc_10_data_PIPO_blk[1] | proc_10_start_FIFO_blk[1] | proc_10_TLF_FIFO_blk[1] | proc_10_input_sync_blk[1] | proc_10_output_sync_blk[1]);
    assign proc_10_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_budget_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_tile_cols_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.profile_cell_cols_val_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.high_threshold_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.dual_threshold_blk_n);
    assign proc_10_data_PIPO_blk[2] = 1'b0;
    assign proc_10_start_FIFO_blk[2] = 1'b0;
    assign proc_10_TLF_FIFO_blk[2] = 1'b0;
    assign proc_10_input_sync_blk[2] = 1'b0;
    assign proc_10_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_10[2] = dl_detect_out ? proc_dep_vld_vec_10_reg[2] : (proc_10_data_FIFO_blk[2] | proc_10_data_PIPO_blk[2] | proc_10_start_FIFO_blk[2] | proc_10_TLF_FIFO_blk[2] | proc_10_input_sync_blk[2] | proc_10_output_sync_blk[2]);
    assign proc_10_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.fast_done_blk_n);
    assign proc_10_data_PIPO_blk[3] = 1'b0;
    assign proc_10_start_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_count_layer2_cycles_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.real_start & (trans_in_cnt_12 == trans_out_cnt_12) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_count_layer2_cycles_U0_U.if_read);
    assign proc_10_TLF_FIFO_blk[3] = 1'b0;
    assign proc_10_input_sync_blk[3] = 1'b0;
    assign proc_10_output_sync_blk[3] = 1'b0 | (ap_done_reg_5 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_done);
    assign proc_dep_vld_vec_10[3] = dl_detect_out ? proc_dep_vld_vec_10_reg[3] : (proc_10_data_FIFO_blk[3] | proc_10_data_PIPO_blk[3] | proc_10_start_FIFO_blk[3] | proc_10_TLF_FIFO_blk[3] | proc_10_input_sync_blk[3] | proc_10_output_sync_blk[3]);
    assign proc_10_data_FIFO_blk[4] = 1'b0;
    assign proc_10_data_PIPO_blk[4] = 1'b0;
    assign proc_10_start_FIFO_blk[4] = 1'b0;
    assign proc_10_TLF_FIFO_blk[4] = 1'b0;
    assign proc_10_input_sync_blk[4] = 1'b0;
    assign proc_10_output_sync_blk[4] = 1'b0 | (ap_done_reg_5 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_done);
    assign proc_dep_vld_vec_10[4] = dl_detect_out ? proc_dep_vld_vec_10_reg[4] : (proc_10_data_FIFO_blk[4] | proc_10_data_PIPO_blk[4] | proc_10_start_FIFO_blk[4] | proc_10_TLF_FIFO_blk[4] | proc_10_input_sync_blk[4] | proc_10_output_sync_blk[4]);
    assign proc_10_data_FIFO_blk[5] = 1'b0;
    assign proc_10_data_PIPO_blk[5] = 1'b0;
    assign proc_10_start_FIFO_blk[5] = 1'b0;
    assign proc_10_TLF_FIFO_blk[5] = 1'b0;
    assign proc_10_input_sync_blk[5] = 1'b0;
    assign proc_10_output_sync_blk[5] = 1'b0 | (ap_done_reg_5 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_done);
    assign proc_dep_vld_vec_10[5] = dl_detect_out ? proc_dep_vld_vec_10_reg[5] : (proc_10_data_FIFO_blk[5] | proc_10_data_PIPO_blk[5] | proc_10_start_FIFO_blk[5] | proc_10_TLF_FIFO_blk[5] | proc_10_input_sync_blk[5] | proc_10_output_sync_blk[5]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_10_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_10_reg <= proc_dep_vld_vec_10;
        end
    end
    assign in_chan_dep_vld_vec_10[0] = dep_chan_vld_0_10;
    assign in_chan_dep_data_vec_10[34 : 0] = dep_chan_data_0_10;
    assign token_in_vec_10[0] = token_0_10;
    assign in_chan_dep_vld_vec_10[1] = dep_chan_vld_8_10;
    assign in_chan_dep_data_vec_10[69 : 35] = dep_chan_data_8_10;
    assign token_in_vec_10[1] = token_8_10;
    assign in_chan_dep_vld_vec_10[2] = dep_chan_vld_9_10;
    assign in_chan_dep_data_vec_10[104 : 70] = dep_chan_data_9_10;
    assign token_in_vec_10[2] = token_9_10;
    assign in_chan_dep_vld_vec_10[3] = dep_chan_vld_24_10;
    assign in_chan_dep_data_vec_10[139 : 105] = dep_chan_data_24_10;
    assign token_in_vec_10[3] = token_24_10;
    assign in_chan_dep_vld_vec_10[4] = dep_chan_vld_30_10;
    assign in_chan_dep_data_vec_10[174 : 140] = dep_chan_data_30_10;
    assign token_in_vec_10[4] = token_30_10;
    assign in_chan_dep_vld_vec_10[5] = dep_chan_vld_34_10;
    assign in_chan_dep_data_vec_10[209 : 175] = dep_chan_data_34_10;
    assign token_in_vec_10[5] = token_34_10;
    assign dep_chan_vld_10_9 = out_chan_dep_vld_vec_10[0];
    assign dep_chan_data_10_9 = out_chan_dep_data_10;
    assign token_10_9 = token_out_vec_10[0];
    assign dep_chan_vld_10_0 = out_chan_dep_vld_vec_10[1];
    assign dep_chan_data_10_0 = out_chan_dep_data_10;
    assign token_10_0 = token_out_vec_10[1];
    assign dep_chan_vld_10_8 = out_chan_dep_vld_vec_10[2];
    assign dep_chan_data_10_8 = out_chan_dep_data_10;
    assign token_10_8 = token_out_vec_10[2];
    assign dep_chan_vld_10_34 = out_chan_dep_vld_vec_10[3];
    assign dep_chan_data_10_34 = out_chan_dep_data_10;
    assign token_10_34 = token_out_vec_10[3];
    assign dep_chan_vld_10_24 = out_chan_dep_vld_vec_10[4];
    assign dep_chan_data_10_24 = out_chan_dep_data_10;
    assign token_10_24 = token_out_vec_10[4];
    assign dep_chan_vld_10_30 = out_chan_dep_vld_vec_10[5];
    assign dep_chan_data_10_30 = out_chan_dep_data_10;
    assign token_10_30 = token_out_vec_10[5];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 11, 9, 9) fastv2_layer2_hls_hls_deadlock_detect_unit_11 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_11),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_11),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_11),
        .token_in_vec(token_in_vec_11),
        .dl_detect_in(dl_detect_out),
        .origin(origin[11]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_11),
        .out_chan_dep_data(out_chan_dep_data_11),
        .token_out_vec(token_out_vec_11),
        .dl_detect_out(dl_in_vec[11]));

    assign proc_11_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_0_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_0_blk_n);
    assign proc_11_data_PIPO_blk[0] = 1'b0;
    assign proc_11_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_0_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_0_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[0] = 1'b0;
    assign proc_11_input_sync_blk[0] = 1'b0;
    assign proc_11_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_11[0] = dl_detect_out ? proc_dep_vld_vec_11_reg[0] : (proc_11_data_FIFO_blk[0] | proc_11_data_PIPO_blk[0] | proc_11_start_FIFO_blk[0] | proc_11_TLF_FIFO_blk[0] | proc_11_input_sync_blk[0] | proc_11_output_sync_blk[0]);
    assign proc_11_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_1_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_1_blk_n);
    assign proc_11_data_PIPO_blk[1] = 1'b0;
    assign proc_11_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_1_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_1_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[1] = 1'b0;
    assign proc_11_input_sync_blk[1] = 1'b0;
    assign proc_11_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_11[1] = dl_detect_out ? proc_dep_vld_vec_11_reg[1] : (proc_11_data_FIFO_blk[1] | proc_11_data_PIPO_blk[1] | proc_11_start_FIFO_blk[1] | proc_11_TLF_FIFO_blk[1] | proc_11_input_sync_blk[1] | proc_11_output_sync_blk[1]);
    assign proc_11_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_2_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_2_blk_n);
    assign proc_11_data_PIPO_blk[2] = 1'b0;
    assign proc_11_start_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_2_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_2_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[2] = 1'b0;
    assign proc_11_input_sync_blk[2] = 1'b0;
    assign proc_11_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_11[2] = dl_detect_out ? proc_dep_vld_vec_11_reg[2] : (proc_11_data_FIFO_blk[2] | proc_11_data_PIPO_blk[2] | proc_11_start_FIFO_blk[2] | proc_11_TLF_FIFO_blk[2] | proc_11_input_sync_blk[2] | proc_11_output_sync_blk[2]);
    assign proc_11_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_3_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_3_blk_n);
    assign proc_11_data_PIPO_blk[3] = 1'b0;
    assign proc_11_start_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_3_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_3_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[3] = 1'b0;
    assign proc_11_input_sync_blk[3] = 1'b0;
    assign proc_11_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_11[3] = dl_detect_out ? proc_dep_vld_vec_11_reg[3] : (proc_11_data_FIFO_blk[3] | proc_11_data_PIPO_blk[3] | proc_11_start_FIFO_blk[3] | proc_11_TLF_FIFO_blk[3] | proc_11_input_sync_blk[3] | proc_11_output_sync_blk[3]);
    assign proc_11_data_FIFO_blk[4] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_4_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_4_blk_n);
    assign proc_11_data_PIPO_blk[4] = 1'b0;
    assign proc_11_start_FIFO_blk[4] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_4_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_4_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[4] = 1'b0;
    assign proc_11_input_sync_blk[4] = 1'b0;
    assign proc_11_output_sync_blk[4] = 1'b0;
    assign proc_dep_vld_vec_11[4] = dl_detect_out ? proc_dep_vld_vec_11_reg[4] : (proc_11_data_FIFO_blk[4] | proc_11_data_PIPO_blk[4] | proc_11_start_FIFO_blk[4] | proc_11_TLF_FIFO_blk[4] | proc_11_input_sync_blk[4] | proc_11_output_sync_blk[4]);
    assign proc_11_data_FIFO_blk[5] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_5_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_5_blk_n);
    assign proc_11_data_PIPO_blk[5] = 1'b0;
    assign proc_11_start_FIFO_blk[5] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_5_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_5_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[5] = 1'b0;
    assign proc_11_input_sync_blk[5] = 1'b0;
    assign proc_11_output_sync_blk[5] = 1'b0;
    assign proc_dep_vld_vec_11[5] = dl_detect_out ? proc_dep_vld_vec_11_reg[5] : (proc_11_data_FIFO_blk[5] | proc_11_data_PIPO_blk[5] | proc_11_start_FIFO_blk[5] | proc_11_TLF_FIFO_blk[5] | proc_11_input_sync_blk[5] | proc_11_output_sync_blk[5]);
    assign proc_11_data_FIFO_blk[6] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_6_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_6_blk_n);
    assign proc_11_data_PIPO_blk[6] = 1'b0;
    assign proc_11_start_FIFO_blk[6] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_6_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_6_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[6] = 1'b0;
    assign proc_11_input_sync_blk[6] = 1'b0;
    assign proc_11_output_sync_blk[6] = 1'b0;
    assign proc_dep_vld_vec_11[6] = dl_detect_out ? proc_dep_vld_vec_11_reg[6] : (proc_11_data_FIFO_blk[6] | proc_11_data_PIPO_blk[6] | proc_11_start_FIFO_blk[6] | proc_11_TLF_FIFO_blk[6] | proc_11_input_sync_blk[6] | proc_11_output_sync_blk[6]);
    assign proc_11_data_FIFO_blk[7] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.banks_7_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.grp_p_anonymous_namespace_route_candidate_banks_Pipeline_RouteCandidateBanks_fu_115.banks_7_blk_n);
    assign proc_11_data_PIPO_blk[7] = 1'b0;
    assign proc_11_start_FIFO_blk[7] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_7_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_7_U0_U.if_read);
    assign proc_11_TLF_FIFO_blk[7] = 1'b0;
    assign proc_11_input_sync_blk[7] = 1'b0;
    assign proc_11_output_sync_blk[7] = 1'b0;
    assign proc_dep_vld_vec_11[7] = dl_detect_out ? proc_dep_vld_vec_11_reg[7] : (proc_11_data_FIFO_blk[7] | proc_11_data_PIPO_blk[7] | proc_11_start_FIFO_blk[7] | proc_11_TLF_FIFO_blk[7] | proc_11_input_sync_blk[7] | proc_11_output_sync_blk[7]);
    assign proc_11_data_FIFO_blk[8] = 1'b0;
    assign proc_11_data_PIPO_blk[8] = 1'b0;
    assign proc_11_start_FIFO_blk[8] = 1'b0;
    assign proc_11_TLF_FIFO_blk[8] = 1'b0;
    assign proc_11_input_sync_blk[8] = 1'b0;
    assign proc_11_output_sync_blk[8] = 1'b0 | (ap_done_reg_8 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.ap_done);
    assign proc_dep_vld_vec_11[8] = dl_detect_out ? proc_dep_vld_vec_11_reg[8] : (proc_11_data_FIFO_blk[8] | proc_11_data_PIPO_blk[8] | proc_11_start_FIFO_blk[8] | proc_11_TLF_FIFO_blk[8] | proc_11_input_sync_blk[8] | proc_11_output_sync_blk[8]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_11_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_11_reg <= proc_dep_vld_vec_11;
        end
    end
    assign in_chan_dep_vld_vec_11[0] = dep_chan_vld_12_11;
    assign in_chan_dep_data_vec_11[34 : 0] = dep_chan_data_12_11;
    assign token_in_vec_11[0] = token_12_11;
    assign in_chan_dep_vld_vec_11[1] = dep_chan_vld_13_11;
    assign in_chan_dep_data_vec_11[69 : 35] = dep_chan_data_13_11;
    assign token_in_vec_11[1] = token_13_11;
    assign in_chan_dep_vld_vec_11[2] = dep_chan_vld_14_11;
    assign in_chan_dep_data_vec_11[104 : 70] = dep_chan_data_14_11;
    assign token_in_vec_11[2] = token_14_11;
    assign in_chan_dep_vld_vec_11[3] = dep_chan_vld_15_11;
    assign in_chan_dep_data_vec_11[139 : 105] = dep_chan_data_15_11;
    assign token_in_vec_11[3] = token_15_11;
    assign in_chan_dep_vld_vec_11[4] = dep_chan_vld_16_11;
    assign in_chan_dep_data_vec_11[174 : 140] = dep_chan_data_16_11;
    assign token_in_vec_11[4] = token_16_11;
    assign in_chan_dep_vld_vec_11[5] = dep_chan_vld_17_11;
    assign in_chan_dep_data_vec_11[209 : 175] = dep_chan_data_17_11;
    assign token_in_vec_11[5] = token_17_11;
    assign in_chan_dep_vld_vec_11[6] = dep_chan_vld_18_11;
    assign in_chan_dep_data_vec_11[244 : 210] = dep_chan_data_18_11;
    assign token_in_vec_11[6] = token_18_11;
    assign in_chan_dep_vld_vec_11[7] = dep_chan_vld_19_11;
    assign in_chan_dep_data_vec_11[279 : 245] = dep_chan_data_19_11;
    assign token_in_vec_11[7] = token_19_11;
    assign in_chan_dep_vld_vec_11[8] = dep_chan_vld_20_11;
    assign in_chan_dep_data_vec_11[314 : 280] = dep_chan_data_20_11;
    assign token_in_vec_11[8] = token_20_11;
    assign dep_chan_vld_11_12 = out_chan_dep_vld_vec_11[0];
    assign dep_chan_data_11_12 = out_chan_dep_data_11;
    assign token_11_12 = token_out_vec_11[0];
    assign dep_chan_vld_11_13 = out_chan_dep_vld_vec_11[1];
    assign dep_chan_data_11_13 = out_chan_dep_data_11;
    assign token_11_13 = token_out_vec_11[1];
    assign dep_chan_vld_11_14 = out_chan_dep_vld_vec_11[2];
    assign dep_chan_data_11_14 = out_chan_dep_data_11;
    assign token_11_14 = token_out_vec_11[2];
    assign dep_chan_vld_11_15 = out_chan_dep_vld_vec_11[3];
    assign dep_chan_data_11_15 = out_chan_dep_data_11;
    assign token_11_15 = token_out_vec_11[3];
    assign dep_chan_vld_11_16 = out_chan_dep_vld_vec_11[4];
    assign dep_chan_data_11_16 = out_chan_dep_data_11;
    assign token_11_16 = token_out_vec_11[4];
    assign dep_chan_vld_11_17 = out_chan_dep_vld_vec_11[5];
    assign dep_chan_data_11_17 = out_chan_dep_data_11;
    assign token_11_17 = token_out_vec_11[5];
    assign dep_chan_vld_11_18 = out_chan_dep_vld_vec_11[6];
    assign dep_chan_data_11_18 = out_chan_dep_data_11;
    assign token_11_18 = token_out_vec_11[6];
    assign dep_chan_vld_11_19 = out_chan_dep_vld_vec_11[7];
    assign dep_chan_data_11_19 = out_chan_dep_data_11;
    assign token_11_19 = token_out_vec_11[7];
    assign dep_chan_vld_11_20 = out_chan_dep_vld_vec_11[8];
    assign dep_chan_data_11_20 = out_chan_dep_data_11;
    assign token_11_20 = token_out_vec_11[8];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 12, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_12 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_12),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_12),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_12),
        .token_in_vec(token_in_vec_12),
        .dl_detect_in(dl_detect_out),
        .origin(origin[12]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_12),
        .out_chan_dep_data(out_chan_dep_data_12),
        .token_out_vec(token_out_vec_12),
        .dl_detect_out(dl_in_vec[12]));

    assign proc_12_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.grp_p_anonymous_namespace_reduce_score_bank_0_Pipeline_ReduceCandidateTokens_fu_138.banks_0_blk_n);
    assign proc_12_data_PIPO_blk[0] = 1'b0;
    assign proc_12_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_0_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_0_U0_U.if_write);
    assign proc_12_TLF_FIFO_blk[0] = 1'b0;
    assign proc_12_input_sync_blk[0] = 1'b0;
    assign proc_12_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_12[0] = dl_detect_out ? proc_dep_vld_vec_12_reg[0] : (proc_12_data_FIFO_blk[0] | proc_12_data_PIPO_blk[0] | proc_12_start_FIFO_blk[0] | proc_12_TLF_FIFO_blk[0] | proc_12_input_sync_blk[0] | proc_12_output_sync_blk[0]);
    assign proc_12_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.grp_p_anonymous_namespace_reduce_score_bank_0_Pipeline_EmitBankWinners_fu_172.winners_0_blk_n);
    assign proc_12_data_PIPO_blk[1] = 1'b0;
    assign proc_12_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_collect_bank_winners_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_0_U0.real_start & (trans_in_cnt_6 == trans_out_cnt_6) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_collect_bank_winners_U0_U.if_read);
    assign proc_12_TLF_FIFO_blk[1] = 1'b0;
    assign proc_12_input_sync_blk[1] = 1'b0;
    assign proc_12_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_12[1] = dl_detect_out ? proc_dep_vld_vec_12_reg[1] : (proc_12_data_FIFO_blk[1] | proc_12_data_PIPO_blk[1] | proc_12_start_FIFO_blk[1] | proc_12_TLF_FIFO_blk[1] | proc_12_input_sync_blk[1] | proc_12_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_12_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_12_reg <= proc_dep_vld_vec_12;
        end
    end
    assign in_chan_dep_vld_vec_12[0] = dep_chan_vld_11_12;
    assign in_chan_dep_data_vec_12[34 : 0] = dep_chan_data_11_12;
    assign token_in_vec_12[0] = token_11_12;
    assign in_chan_dep_vld_vec_12[1] = dep_chan_vld_20_12;
    assign in_chan_dep_data_vec_12[69 : 35] = dep_chan_data_20_12;
    assign token_in_vec_12[1] = token_20_12;
    assign dep_chan_vld_12_11 = out_chan_dep_vld_vec_12[0];
    assign dep_chan_data_12_11 = out_chan_dep_data_12;
    assign token_12_11 = token_out_vec_12[0];
    assign dep_chan_vld_12_20 = out_chan_dep_vld_vec_12[1];
    assign dep_chan_data_12_20 = out_chan_dep_data_12;
    assign token_12_20 = token_out_vec_12[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_1_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 13, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_13 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_13),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_13),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_13),
        .token_in_vec(token_in_vec_13),
        .dl_detect_in(dl_detect_out),
        .origin(origin[13]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_13),
        .out_chan_dep_data(out_chan_dep_data_13),
        .token_out_vec(token_out_vec_13),
        .dl_detect_out(dl_in_vec[13]));

    assign proc_13_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_1_U0.grp_p_anonymous_namespace_reduce_score_bank_1_Pipeline_ReduceCandidateTokens_fu_138.banks_1_blk_n);
    assign proc_13_data_PIPO_blk[0] = 1'b0;
    assign proc_13_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_1_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_1_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_1_U0_U.if_write);
    assign proc_13_TLF_FIFO_blk[0] = 1'b0;
    assign proc_13_input_sync_blk[0] = 1'b0;
    assign proc_13_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_13[0] = dl_detect_out ? proc_dep_vld_vec_13_reg[0] : (proc_13_data_FIFO_blk[0] | proc_13_data_PIPO_blk[0] | proc_13_start_FIFO_blk[0] | proc_13_TLF_FIFO_blk[0] | proc_13_input_sync_blk[0] | proc_13_output_sync_blk[0]);
    assign proc_13_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_1_U0.grp_p_anonymous_namespace_reduce_score_bank_1_Pipeline_EmitBankWinners_fu_172.winners_1_blk_n);
    assign proc_13_data_PIPO_blk[1] = 1'b0;
    assign proc_13_start_FIFO_blk[1] = 1'b0;
    assign proc_13_TLF_FIFO_blk[1] = 1'b0;
    assign proc_13_input_sync_blk[1] = 1'b0;
    assign proc_13_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_13[1] = dl_detect_out ? proc_dep_vld_vec_13_reg[1] : (proc_13_data_FIFO_blk[1] | proc_13_data_PIPO_blk[1] | proc_13_start_FIFO_blk[1] | proc_13_TLF_FIFO_blk[1] | proc_13_input_sync_blk[1] | proc_13_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_13_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_13_reg <= proc_dep_vld_vec_13;
        end
    end
    assign in_chan_dep_vld_vec_13[0] = dep_chan_vld_11_13;
    assign in_chan_dep_data_vec_13[34 : 0] = dep_chan_data_11_13;
    assign token_in_vec_13[0] = token_11_13;
    assign in_chan_dep_vld_vec_13[1] = dep_chan_vld_20_13;
    assign in_chan_dep_data_vec_13[69 : 35] = dep_chan_data_20_13;
    assign token_in_vec_13[1] = token_20_13;
    assign dep_chan_vld_13_11 = out_chan_dep_vld_vec_13[0];
    assign dep_chan_data_13_11 = out_chan_dep_data_13;
    assign token_13_11 = token_out_vec_13[0];
    assign dep_chan_vld_13_20 = out_chan_dep_vld_vec_13[1];
    assign dep_chan_data_13_20 = out_chan_dep_data_13;
    assign token_13_20 = token_out_vec_13[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_2_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 14, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_14 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_14),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_14),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_14),
        .token_in_vec(token_in_vec_14),
        .dl_detect_in(dl_detect_out),
        .origin(origin[14]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_14),
        .out_chan_dep_data(out_chan_dep_data_14),
        .token_out_vec(token_out_vec_14),
        .dl_detect_out(dl_in_vec[14]));

    assign proc_14_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_2_U0.grp_p_anonymous_namespace_reduce_score_bank_2_Pipeline_ReduceCandidateTokens_fu_138.banks_2_blk_n);
    assign proc_14_data_PIPO_blk[0] = 1'b0;
    assign proc_14_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_2_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_2_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_2_U0_U.if_write);
    assign proc_14_TLF_FIFO_blk[0] = 1'b0;
    assign proc_14_input_sync_blk[0] = 1'b0;
    assign proc_14_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_14[0] = dl_detect_out ? proc_dep_vld_vec_14_reg[0] : (proc_14_data_FIFO_blk[0] | proc_14_data_PIPO_blk[0] | proc_14_start_FIFO_blk[0] | proc_14_TLF_FIFO_blk[0] | proc_14_input_sync_blk[0] | proc_14_output_sync_blk[0]);
    assign proc_14_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_2_U0.grp_p_anonymous_namespace_reduce_score_bank_2_Pipeline_EmitBankWinners_fu_172.winners_2_blk_n);
    assign proc_14_data_PIPO_blk[1] = 1'b0;
    assign proc_14_start_FIFO_blk[1] = 1'b0;
    assign proc_14_TLF_FIFO_blk[1] = 1'b0;
    assign proc_14_input_sync_blk[1] = 1'b0;
    assign proc_14_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_14[1] = dl_detect_out ? proc_dep_vld_vec_14_reg[1] : (proc_14_data_FIFO_blk[1] | proc_14_data_PIPO_blk[1] | proc_14_start_FIFO_blk[1] | proc_14_TLF_FIFO_blk[1] | proc_14_input_sync_blk[1] | proc_14_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_14_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_14_reg <= proc_dep_vld_vec_14;
        end
    end
    assign in_chan_dep_vld_vec_14[0] = dep_chan_vld_11_14;
    assign in_chan_dep_data_vec_14[34 : 0] = dep_chan_data_11_14;
    assign token_in_vec_14[0] = token_11_14;
    assign in_chan_dep_vld_vec_14[1] = dep_chan_vld_20_14;
    assign in_chan_dep_data_vec_14[69 : 35] = dep_chan_data_20_14;
    assign token_in_vec_14[1] = token_20_14;
    assign dep_chan_vld_14_11 = out_chan_dep_vld_vec_14[0];
    assign dep_chan_data_14_11 = out_chan_dep_data_14;
    assign token_14_11 = token_out_vec_14[0];
    assign dep_chan_vld_14_20 = out_chan_dep_vld_vec_14[1];
    assign dep_chan_data_14_20 = out_chan_dep_data_14;
    assign token_14_20 = token_out_vec_14[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_3_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 15, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_15 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_15),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_15),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_15),
        .token_in_vec(token_in_vec_15),
        .dl_detect_in(dl_detect_out),
        .origin(origin[15]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_15),
        .out_chan_dep_data(out_chan_dep_data_15),
        .token_out_vec(token_out_vec_15),
        .dl_detect_out(dl_in_vec[15]));

    assign proc_15_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_3_U0.grp_p_anonymous_namespace_reduce_score_bank_3_Pipeline_ReduceCandidateTokens_fu_138.banks_3_blk_n);
    assign proc_15_data_PIPO_blk[0] = 1'b0;
    assign proc_15_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_3_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_3_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_3_U0_U.if_write);
    assign proc_15_TLF_FIFO_blk[0] = 1'b0;
    assign proc_15_input_sync_blk[0] = 1'b0;
    assign proc_15_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_15[0] = dl_detect_out ? proc_dep_vld_vec_15_reg[0] : (proc_15_data_FIFO_blk[0] | proc_15_data_PIPO_blk[0] | proc_15_start_FIFO_blk[0] | proc_15_TLF_FIFO_blk[0] | proc_15_input_sync_blk[0] | proc_15_output_sync_blk[0]);
    assign proc_15_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_3_U0.grp_p_anonymous_namespace_reduce_score_bank_3_Pipeline_EmitBankWinners_fu_172.winners_3_blk_n);
    assign proc_15_data_PIPO_blk[1] = 1'b0;
    assign proc_15_start_FIFO_blk[1] = 1'b0;
    assign proc_15_TLF_FIFO_blk[1] = 1'b0;
    assign proc_15_input_sync_blk[1] = 1'b0;
    assign proc_15_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_15[1] = dl_detect_out ? proc_dep_vld_vec_15_reg[1] : (proc_15_data_FIFO_blk[1] | proc_15_data_PIPO_blk[1] | proc_15_start_FIFO_blk[1] | proc_15_TLF_FIFO_blk[1] | proc_15_input_sync_blk[1] | proc_15_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_15_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_15_reg <= proc_dep_vld_vec_15;
        end
    end
    assign in_chan_dep_vld_vec_15[0] = dep_chan_vld_11_15;
    assign in_chan_dep_data_vec_15[34 : 0] = dep_chan_data_11_15;
    assign token_in_vec_15[0] = token_11_15;
    assign in_chan_dep_vld_vec_15[1] = dep_chan_vld_20_15;
    assign in_chan_dep_data_vec_15[69 : 35] = dep_chan_data_20_15;
    assign token_in_vec_15[1] = token_20_15;
    assign dep_chan_vld_15_11 = out_chan_dep_vld_vec_15[0];
    assign dep_chan_data_15_11 = out_chan_dep_data_15;
    assign token_15_11 = token_out_vec_15[0];
    assign dep_chan_vld_15_20 = out_chan_dep_vld_vec_15[1];
    assign dep_chan_data_15_20 = out_chan_dep_data_15;
    assign token_15_20 = token_out_vec_15[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_4_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 16, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_16 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_16),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_16),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_16),
        .token_in_vec(token_in_vec_16),
        .dl_detect_in(dl_detect_out),
        .origin(origin[16]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_16),
        .out_chan_dep_data(out_chan_dep_data_16),
        .token_out_vec(token_out_vec_16),
        .dl_detect_out(dl_in_vec[16]));

    assign proc_16_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_4_U0.grp_p_anonymous_namespace_reduce_score_bank_4_Pipeline_ReduceCandidateTokens_fu_138.banks_4_blk_n);
    assign proc_16_data_PIPO_blk[0] = 1'b0;
    assign proc_16_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_4_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_4_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_4_U0_U.if_write);
    assign proc_16_TLF_FIFO_blk[0] = 1'b0;
    assign proc_16_input_sync_blk[0] = 1'b0;
    assign proc_16_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_16[0] = dl_detect_out ? proc_dep_vld_vec_16_reg[0] : (proc_16_data_FIFO_blk[0] | proc_16_data_PIPO_blk[0] | proc_16_start_FIFO_blk[0] | proc_16_TLF_FIFO_blk[0] | proc_16_input_sync_blk[0] | proc_16_output_sync_blk[0]);
    assign proc_16_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_4_U0.grp_p_anonymous_namespace_reduce_score_bank_4_Pipeline_EmitBankWinners_fu_172.winners_4_blk_n);
    assign proc_16_data_PIPO_blk[1] = 1'b0;
    assign proc_16_start_FIFO_blk[1] = 1'b0;
    assign proc_16_TLF_FIFO_blk[1] = 1'b0;
    assign proc_16_input_sync_blk[1] = 1'b0;
    assign proc_16_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_16[1] = dl_detect_out ? proc_dep_vld_vec_16_reg[1] : (proc_16_data_FIFO_blk[1] | proc_16_data_PIPO_blk[1] | proc_16_start_FIFO_blk[1] | proc_16_TLF_FIFO_blk[1] | proc_16_input_sync_blk[1] | proc_16_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_16_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_16_reg <= proc_dep_vld_vec_16;
        end
    end
    assign in_chan_dep_vld_vec_16[0] = dep_chan_vld_11_16;
    assign in_chan_dep_data_vec_16[34 : 0] = dep_chan_data_11_16;
    assign token_in_vec_16[0] = token_11_16;
    assign in_chan_dep_vld_vec_16[1] = dep_chan_vld_20_16;
    assign in_chan_dep_data_vec_16[69 : 35] = dep_chan_data_20_16;
    assign token_in_vec_16[1] = token_20_16;
    assign dep_chan_vld_16_11 = out_chan_dep_vld_vec_16[0];
    assign dep_chan_data_16_11 = out_chan_dep_data_16;
    assign token_16_11 = token_out_vec_16[0];
    assign dep_chan_vld_16_20 = out_chan_dep_vld_vec_16[1];
    assign dep_chan_data_16_20 = out_chan_dep_data_16;
    assign token_16_20 = token_out_vec_16[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_5_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 17, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_17 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_17),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_17),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_17),
        .token_in_vec(token_in_vec_17),
        .dl_detect_in(dl_detect_out),
        .origin(origin[17]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_17),
        .out_chan_dep_data(out_chan_dep_data_17),
        .token_out_vec(token_out_vec_17),
        .dl_detect_out(dl_in_vec[17]));

    assign proc_17_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_5_U0.grp_p_anonymous_namespace_reduce_score_bank_5_Pipeline_ReduceCandidateTokens_fu_138.banks_5_blk_n);
    assign proc_17_data_PIPO_blk[0] = 1'b0;
    assign proc_17_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_5_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_5_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_5_U0_U.if_write);
    assign proc_17_TLF_FIFO_blk[0] = 1'b0;
    assign proc_17_input_sync_blk[0] = 1'b0;
    assign proc_17_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_17[0] = dl_detect_out ? proc_dep_vld_vec_17_reg[0] : (proc_17_data_FIFO_blk[0] | proc_17_data_PIPO_blk[0] | proc_17_start_FIFO_blk[0] | proc_17_TLF_FIFO_blk[0] | proc_17_input_sync_blk[0] | proc_17_output_sync_blk[0]);
    assign proc_17_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_5_U0.grp_p_anonymous_namespace_reduce_score_bank_5_Pipeline_EmitBankWinners_fu_172.winners_5_blk_n);
    assign proc_17_data_PIPO_blk[1] = 1'b0;
    assign proc_17_start_FIFO_blk[1] = 1'b0;
    assign proc_17_TLF_FIFO_blk[1] = 1'b0;
    assign proc_17_input_sync_blk[1] = 1'b0;
    assign proc_17_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_17[1] = dl_detect_out ? proc_dep_vld_vec_17_reg[1] : (proc_17_data_FIFO_blk[1] | proc_17_data_PIPO_blk[1] | proc_17_start_FIFO_blk[1] | proc_17_TLF_FIFO_blk[1] | proc_17_input_sync_blk[1] | proc_17_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_17_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_17_reg <= proc_dep_vld_vec_17;
        end
    end
    assign in_chan_dep_vld_vec_17[0] = dep_chan_vld_11_17;
    assign in_chan_dep_data_vec_17[34 : 0] = dep_chan_data_11_17;
    assign token_in_vec_17[0] = token_11_17;
    assign in_chan_dep_vld_vec_17[1] = dep_chan_vld_20_17;
    assign in_chan_dep_data_vec_17[69 : 35] = dep_chan_data_20_17;
    assign token_in_vec_17[1] = token_20_17;
    assign dep_chan_vld_17_11 = out_chan_dep_vld_vec_17[0];
    assign dep_chan_data_17_11 = out_chan_dep_data_17;
    assign token_17_11 = token_out_vec_17[0];
    assign dep_chan_vld_17_20 = out_chan_dep_vld_vec_17[1];
    assign dep_chan_data_17_20 = out_chan_dep_data_17;
    assign token_17_20 = token_out_vec_17[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_6_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 18, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_18 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_18),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_18),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_18),
        .token_in_vec(token_in_vec_18),
        .dl_detect_in(dl_detect_out),
        .origin(origin[18]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_18),
        .out_chan_dep_data(out_chan_dep_data_18),
        .token_out_vec(token_out_vec_18),
        .dl_detect_out(dl_in_vec[18]));

    assign proc_18_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_6_U0.grp_p_anonymous_namespace_reduce_score_bank_6_Pipeline_ReduceCandidateTokens_fu_138.banks_6_blk_n);
    assign proc_18_data_PIPO_blk[0] = 1'b0;
    assign proc_18_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_6_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_6_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_6_U0_U.if_write);
    assign proc_18_TLF_FIFO_blk[0] = 1'b0;
    assign proc_18_input_sync_blk[0] = 1'b0;
    assign proc_18_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_18[0] = dl_detect_out ? proc_dep_vld_vec_18_reg[0] : (proc_18_data_FIFO_blk[0] | proc_18_data_PIPO_blk[0] | proc_18_start_FIFO_blk[0] | proc_18_TLF_FIFO_blk[0] | proc_18_input_sync_blk[0] | proc_18_output_sync_blk[0]);
    assign proc_18_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_6_U0.grp_p_anonymous_namespace_reduce_score_bank_6_Pipeline_EmitBankWinners_fu_172.winners_6_blk_n);
    assign proc_18_data_PIPO_blk[1] = 1'b0;
    assign proc_18_start_FIFO_blk[1] = 1'b0;
    assign proc_18_TLF_FIFO_blk[1] = 1'b0;
    assign proc_18_input_sync_blk[1] = 1'b0;
    assign proc_18_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_18[1] = dl_detect_out ? proc_dep_vld_vec_18_reg[1] : (proc_18_data_FIFO_blk[1] | proc_18_data_PIPO_blk[1] | proc_18_start_FIFO_blk[1] | proc_18_TLF_FIFO_blk[1] | proc_18_input_sync_blk[1] | proc_18_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_18_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_18_reg <= proc_dep_vld_vec_18;
        end
    end
    assign in_chan_dep_vld_vec_18[0] = dep_chan_vld_11_18;
    assign in_chan_dep_data_vec_18[34 : 0] = dep_chan_data_11_18;
    assign token_in_vec_18[0] = token_11_18;
    assign in_chan_dep_vld_vec_18[1] = dep_chan_vld_20_18;
    assign in_chan_dep_data_vec_18[69 : 35] = dep_chan_data_20_18;
    assign token_in_vec_18[1] = token_20_18;
    assign dep_chan_vld_18_11 = out_chan_dep_vld_vec_18[0];
    assign dep_chan_data_18_11 = out_chan_dep_data_18;
    assign token_18_11 = token_out_vec_18[0];
    assign dep_chan_vld_18_20 = out_chan_dep_vld_vec_18[1];
    assign dep_chan_data_18_20 = out_chan_dep_data_18;
    assign token_18_20 = token_out_vec_18[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_7_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 19, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_19 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_19),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_19),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_19),
        .token_in_vec(token_in_vec_19),
        .dl_detect_in(dl_detect_out),
        .origin(origin[19]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_19),
        .out_chan_dep_data(out_chan_dep_data_19),
        .token_out_vec(token_out_vec_19),
        .dl_detect_out(dl_in_vec[19]));

    assign proc_19_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_7_U0.grp_p_anonymous_namespace_reduce_score_bank_7_Pipeline_ReduceCandidateTokens_fu_138.banks_7_blk_n);
    assign proc_19_data_PIPO_blk[0] = 1'b0;
    assign proc_19_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_7_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_7_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_reduce_score_bank_7_U0_U.if_write);
    assign proc_19_TLF_FIFO_blk[0] = 1'b0;
    assign proc_19_input_sync_blk[0] = 1'b0;
    assign proc_19_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_19[0] = dl_detect_out ? proc_dep_vld_vec_19_reg[0] : (proc_19_data_FIFO_blk[0] | proc_19_data_PIPO_blk[0] | proc_19_start_FIFO_blk[0] | proc_19_TLF_FIFO_blk[0] | proc_19_input_sync_blk[0] | proc_19_output_sync_blk[0]);
    assign proc_19_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_reduce_score_bank_7_U0.grp_p_anonymous_namespace_reduce_score_bank_7_Pipeline_EmitBankWinners_fu_172.winners_7_blk_n);
    assign proc_19_data_PIPO_blk[1] = 1'b0;
    assign proc_19_start_FIFO_blk[1] = 1'b0;
    assign proc_19_TLF_FIFO_blk[1] = 1'b0;
    assign proc_19_input_sync_blk[1] = 1'b0;
    assign proc_19_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_19[1] = dl_detect_out ? proc_dep_vld_vec_19_reg[1] : (proc_19_data_FIFO_blk[1] | proc_19_data_PIPO_blk[1] | proc_19_start_FIFO_blk[1] | proc_19_TLF_FIFO_blk[1] | proc_19_input_sync_blk[1] | proc_19_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_19_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_19_reg <= proc_dep_vld_vec_19;
        end
    end
    assign in_chan_dep_vld_vec_19[0] = dep_chan_vld_11_19;
    assign in_chan_dep_data_vec_19[34 : 0] = dep_chan_data_11_19;
    assign token_in_vec_19[0] = token_11_19;
    assign in_chan_dep_vld_vec_19[1] = dep_chan_vld_20_19;
    assign in_chan_dep_data_vec_19[69 : 35] = dep_chan_data_20_19;
    assign token_in_vec_19[1] = token_20_19;
    assign dep_chan_vld_19_11 = out_chan_dep_vld_vec_19[0];
    assign dep_chan_data_19_11 = out_chan_dep_data_19;
    assign token_19_11 = token_out_vec_19[0];
    assign dep_chan_vld_19_20 = out_chan_dep_vld_vec_19[1];
    assign dep_chan_data_19_20 = out_chan_dep_data_19;
    assign token_19_20 = token_out_vec_19[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 20, 9, 9) fastv2_layer2_hls_hls_deadlock_detect_unit_20 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_20),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_20),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_20),
        .token_in_vec(token_in_vec_20),
        .dl_detect_in(dl_detect_out),
        .origin(origin[20]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_20),
        .out_chan_dep_data(out_chan_dep_data_20),
        .token_out_vec(token_out_vec_20),
        .dl_detect_out(dl_in_vec[20]));

    assign proc_20_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_0_blk_n);
    assign proc_20_data_PIPO_blk[0] = 1'b0;
    assign proc_20_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_collect_bank_winners_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.start_for_p_anonymous_namespace_collect_bank_winners_U0_U.if_write);
    assign proc_20_TLF_FIFO_blk[0] = 1'b0;
    assign proc_20_input_sync_blk[0] = 1'b0;
    assign proc_20_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_20[0] = dl_detect_out ? proc_dep_vld_vec_20_reg[0] : (proc_20_data_FIFO_blk[0] | proc_20_data_PIPO_blk[0] | proc_20_start_FIFO_blk[0] | proc_20_TLF_FIFO_blk[0] | proc_20_input_sync_blk[0] | proc_20_output_sync_blk[0]);
    assign proc_20_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_1_blk_n);
    assign proc_20_data_PIPO_blk[1] = 1'b0;
    assign proc_20_start_FIFO_blk[1] = 1'b0;
    assign proc_20_TLF_FIFO_blk[1] = 1'b0;
    assign proc_20_input_sync_blk[1] = 1'b0;
    assign proc_20_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_20[1] = dl_detect_out ? proc_dep_vld_vec_20_reg[1] : (proc_20_data_FIFO_blk[1] | proc_20_data_PIPO_blk[1] | proc_20_start_FIFO_blk[1] | proc_20_TLF_FIFO_blk[1] | proc_20_input_sync_blk[1] | proc_20_output_sync_blk[1]);
    assign proc_20_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_2_blk_n);
    assign proc_20_data_PIPO_blk[2] = 1'b0;
    assign proc_20_start_FIFO_blk[2] = 1'b0;
    assign proc_20_TLF_FIFO_blk[2] = 1'b0;
    assign proc_20_input_sync_blk[2] = 1'b0;
    assign proc_20_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_20[2] = dl_detect_out ? proc_dep_vld_vec_20_reg[2] : (proc_20_data_FIFO_blk[2] | proc_20_data_PIPO_blk[2] | proc_20_start_FIFO_blk[2] | proc_20_TLF_FIFO_blk[2] | proc_20_input_sync_blk[2] | proc_20_output_sync_blk[2]);
    assign proc_20_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_3_blk_n);
    assign proc_20_data_PIPO_blk[3] = 1'b0;
    assign proc_20_start_FIFO_blk[3] = 1'b0;
    assign proc_20_TLF_FIFO_blk[3] = 1'b0;
    assign proc_20_input_sync_blk[3] = 1'b0;
    assign proc_20_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_20[3] = dl_detect_out ? proc_dep_vld_vec_20_reg[3] : (proc_20_data_FIFO_blk[3] | proc_20_data_PIPO_blk[3] | proc_20_start_FIFO_blk[3] | proc_20_TLF_FIFO_blk[3] | proc_20_input_sync_blk[3] | proc_20_output_sync_blk[3]);
    assign proc_20_data_FIFO_blk[4] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_4_blk_n);
    assign proc_20_data_PIPO_blk[4] = 1'b0;
    assign proc_20_start_FIFO_blk[4] = 1'b0;
    assign proc_20_TLF_FIFO_blk[4] = 1'b0;
    assign proc_20_input_sync_blk[4] = 1'b0;
    assign proc_20_output_sync_blk[4] = 1'b0;
    assign proc_dep_vld_vec_20[4] = dl_detect_out ? proc_dep_vld_vec_20_reg[4] : (proc_20_data_FIFO_blk[4] | proc_20_data_PIPO_blk[4] | proc_20_start_FIFO_blk[4] | proc_20_TLF_FIFO_blk[4] | proc_20_input_sync_blk[4] | proc_20_output_sync_blk[4]);
    assign proc_20_data_FIFO_blk[5] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_5_blk_n);
    assign proc_20_data_PIPO_blk[5] = 1'b0;
    assign proc_20_start_FIFO_blk[5] = 1'b0;
    assign proc_20_TLF_FIFO_blk[5] = 1'b0;
    assign proc_20_input_sync_blk[5] = 1'b0;
    assign proc_20_output_sync_blk[5] = 1'b0;
    assign proc_dep_vld_vec_20[5] = dl_detect_out ? proc_dep_vld_vec_20_reg[5] : (proc_20_data_FIFO_blk[5] | proc_20_data_PIPO_blk[5] | proc_20_start_FIFO_blk[5] | proc_20_TLF_FIFO_blk[5] | proc_20_input_sync_blk[5] | proc_20_output_sync_blk[5]);
    assign proc_20_data_FIFO_blk[6] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_6_blk_n);
    assign proc_20_data_PIPO_blk[6] = 1'b0;
    assign proc_20_start_FIFO_blk[6] = 1'b0;
    assign proc_20_TLF_FIFO_blk[6] = 1'b0;
    assign proc_20_input_sync_blk[6] = 1'b0;
    assign proc_20_output_sync_blk[6] = 1'b0;
    assign proc_dep_vld_vec_20[6] = dl_detect_out ? proc_dep_vld_vec_20_reg[6] : (proc_20_data_FIFO_blk[6] | proc_20_data_PIPO_blk[6] | proc_20_start_FIFO_blk[6] | proc_20_TLF_FIFO_blk[6] | proc_20_input_sync_blk[6] | proc_20_output_sync_blk[6]);
    assign proc_20_data_FIFO_blk[7] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.winners_7_blk_n);
    assign proc_20_data_PIPO_blk[7] = 1'b0;
    assign proc_20_start_FIFO_blk[7] = 1'b0;
    assign proc_20_TLF_FIFO_blk[7] = 1'b0;
    assign proc_20_input_sync_blk[7] = 1'b0;
    assign proc_20_output_sync_blk[7] = 1'b0;
    assign proc_dep_vld_vec_20[7] = dl_detect_out ? proc_dep_vld_vec_20_reg[7] : (proc_20_data_FIFO_blk[7] | proc_20_data_PIPO_blk[7] | proc_20_start_FIFO_blk[7] | proc_20_TLF_FIFO_blk[7] | proc_20_input_sync_blk[7] | proc_20_output_sync_blk[7]);
    assign proc_20_data_FIFO_blk[8] = 1'b0;
    assign proc_20_data_PIPO_blk[8] = 1'b0;
    assign proc_20_start_FIFO_blk[8] = 1'b0;
    assign proc_20_TLF_FIFO_blk[8] = 1'b0;
    assign proc_20_input_sync_blk[8] = 1'b0;
    assign proc_20_output_sync_blk[8] = 1'b0 | (ap_done_reg_9 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_collect_bank_winners_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.grp_p_anonymous_namespace_reduce_banked_grid_fu_495.p_anonymous_namespace_route_candidate_banks_U0.ap_done);
    assign proc_dep_vld_vec_20[8] = dl_detect_out ? proc_dep_vld_vec_20_reg[8] : (proc_20_data_FIFO_blk[8] | proc_20_data_PIPO_blk[8] | proc_20_start_FIFO_blk[8] | proc_20_TLF_FIFO_blk[8] | proc_20_input_sync_blk[8] | proc_20_output_sync_blk[8]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_20_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_20_reg <= proc_dep_vld_vec_20;
        end
    end
    assign in_chan_dep_vld_vec_20[0] = dep_chan_vld_11_20;
    assign in_chan_dep_data_vec_20[34 : 0] = dep_chan_data_11_20;
    assign token_in_vec_20[0] = token_11_20;
    assign in_chan_dep_vld_vec_20[1] = dep_chan_vld_12_20;
    assign in_chan_dep_data_vec_20[69 : 35] = dep_chan_data_12_20;
    assign token_in_vec_20[1] = token_12_20;
    assign in_chan_dep_vld_vec_20[2] = dep_chan_vld_13_20;
    assign in_chan_dep_data_vec_20[104 : 70] = dep_chan_data_13_20;
    assign token_in_vec_20[2] = token_13_20;
    assign in_chan_dep_vld_vec_20[3] = dep_chan_vld_14_20;
    assign in_chan_dep_data_vec_20[139 : 105] = dep_chan_data_14_20;
    assign token_in_vec_20[3] = token_14_20;
    assign in_chan_dep_vld_vec_20[4] = dep_chan_vld_15_20;
    assign in_chan_dep_data_vec_20[174 : 140] = dep_chan_data_15_20;
    assign token_in_vec_20[4] = token_15_20;
    assign in_chan_dep_vld_vec_20[5] = dep_chan_vld_16_20;
    assign in_chan_dep_data_vec_20[209 : 175] = dep_chan_data_16_20;
    assign token_in_vec_20[5] = token_16_20;
    assign in_chan_dep_vld_vec_20[6] = dep_chan_vld_17_20;
    assign in_chan_dep_data_vec_20[244 : 210] = dep_chan_data_17_20;
    assign token_in_vec_20[6] = token_17_20;
    assign in_chan_dep_vld_vec_20[7] = dep_chan_vld_18_20;
    assign in_chan_dep_data_vec_20[279 : 245] = dep_chan_data_18_20;
    assign token_in_vec_20[7] = token_18_20;
    assign in_chan_dep_vld_vec_20[8] = dep_chan_vld_19_20;
    assign in_chan_dep_data_vec_20[314 : 280] = dep_chan_data_19_20;
    assign token_in_vec_20[8] = token_19_20;
    assign dep_chan_vld_20_12 = out_chan_dep_vld_vec_20[0];
    assign dep_chan_data_20_12 = out_chan_dep_data_20;
    assign token_20_12 = token_out_vec_20[0];
    assign dep_chan_vld_20_13 = out_chan_dep_vld_vec_20[1];
    assign dep_chan_data_20_13 = out_chan_dep_data_20;
    assign token_20_13 = token_out_vec_20[1];
    assign dep_chan_vld_20_14 = out_chan_dep_vld_vec_20[2];
    assign dep_chan_data_20_14 = out_chan_dep_data_20;
    assign token_20_14 = token_out_vec_20[2];
    assign dep_chan_vld_20_15 = out_chan_dep_vld_vec_20[3];
    assign dep_chan_data_20_15 = out_chan_dep_data_20;
    assign token_20_15 = token_out_vec_20[3];
    assign dep_chan_vld_20_16 = out_chan_dep_vld_vec_20[4];
    assign dep_chan_data_20_16 = out_chan_dep_data_20;
    assign token_20_16 = token_out_vec_20[4];
    assign dep_chan_vld_20_17 = out_chan_dep_vld_vec_20[5];
    assign dep_chan_data_20_17 = out_chan_dep_data_20;
    assign token_20_17 = token_out_vec_20[5];
    assign dep_chan_vld_20_18 = out_chan_dep_vld_vec_20[6];
    assign dep_chan_data_20_18 = out_chan_dep_data_20;
    assign token_20_18 = token_out_vec_20[6];
    assign dep_chan_vld_20_19 = out_chan_dep_vld_vec_20[7];
    assign dep_chan_data_20_19 = out_chan_dep_data_20;
    assign token_20_19 = token_out_vec_20[7];
    assign dep_chan_vld_20_11 = out_chan_dep_vld_vec_20[8];
    assign dep_chan_data_20_11 = out_chan_dep_data_20;
    assign token_20_11 = token_out_vec_20[8];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 21, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_21 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_21),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_21),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_21),
        .token_in_vec(token_in_vec_21),
        .dl_detect_in(dl_detect_out),
        .origin(origin[21]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_21),
        .out_chan_dep_data(out_chan_dep_data_21),
        .token_out_vec(token_out_vec_21),
        .dl_detect_out(dl_in_vec[21]));

    assign proc_21_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.grp_p_anonymous_namespace_gaussian4_horizontal_Pipeline_VITIS_LOOP_11_2_fu_178.gaussian_raw_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.width_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.height_blk_n);
    assign proc_21_data_PIPO_blk[0] = 1'b0;
    assign proc_21_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_horizontal_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_horizontal_U0_U.if_write);
    assign proc_21_TLF_FIFO_blk[0] = 1'b0;
    assign proc_21_input_sync_blk[0] = 1'b0;
    assign proc_21_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_21[0] = dl_detect_out ? proc_dep_vld_vec_21_reg[0] : (proc_21_data_FIFO_blk[0] | proc_21_data_PIPO_blk[0] | proc_21_start_FIFO_blk[0] | proc_21_TLF_FIFO_blk[0] | proc_21_input_sync_blk[0] | proc_21_output_sync_blk[0]);
    assign proc_21_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.grp_p_anonymous_namespace_gaussian4_horizontal_Pipeline_HorizontalGaussianQuads_fu_200.horizontal_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.p_width_val_c7_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.p_height_val_c13_blk_n);
    assign proc_21_data_PIPO_blk[1] = 1'b0;
    assign proc_21_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_vertical_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_horizontal_U0.real_start & (trans_in_cnt_8 == trans_out_cnt_8) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_vertical_U0_U.if_read);
    assign proc_21_TLF_FIFO_blk[1] = 1'b0;
    assign proc_21_input_sync_blk[1] = 1'b0;
    assign proc_21_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_21[1] = dl_detect_out ? proc_dep_vld_vec_21_reg[1] : (proc_21_data_FIFO_blk[1] | proc_21_data_PIPO_blk[1] | proc_21_start_FIFO_blk[1] | proc_21_TLF_FIFO_blk[1] | proc_21_input_sync_blk[1] | proc_21_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_21_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_21_reg <= proc_dep_vld_vec_21;
        end
    end
    assign in_chan_dep_vld_vec_21[0] = dep_chan_vld_7_21;
    assign in_chan_dep_data_vec_21[34 : 0] = dep_chan_data_7_21;
    assign token_in_vec_21[0] = token_7_21;
    assign in_chan_dep_vld_vec_21[1] = dep_chan_vld_22_21;
    assign in_chan_dep_data_vec_21[69 : 35] = dep_chan_data_22_21;
    assign token_in_vec_21[1] = token_22_21;
    assign dep_chan_vld_21_7 = out_chan_dep_vld_vec_21[0];
    assign dep_chan_data_21_7 = out_chan_dep_data_21;
    assign token_21_7 = token_out_vec_21[0];
    assign dep_chan_vld_21_22 = out_chan_dep_vld_vec_21[1];
    assign dep_chan_data_21_22 = out_chan_dep_data_21;
    assign token_21_22 = token_out_vec_21[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 22, 2, 2) fastv2_layer2_hls_hls_deadlock_detect_unit_22 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_22),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_22),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_22),
        .token_in_vec(token_in_vec_22),
        .dl_detect_in(dl_detect_out),
        .origin(origin[22]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_22),
        .out_chan_dep_data(out_chan_dep_data_22),
        .token_out_vec(token_out_vec_22),
        .dl_detect_out(dl_in_vec[22]));

    assign proc_22_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.grp_p_anonymous_namespace_gaussian4_vertical_Pipeline_VerticalGaussianQuads_fu_162.horizontal_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.width_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.height_blk_n);
    assign proc_22_data_PIPO_blk[0] = 1'b0;
    assign proc_22_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_vertical_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_gaussian4_vertical_U0_U.if_write);
    assign proc_22_TLF_FIFO_blk[0] = 1'b0;
    assign proc_22_input_sync_blk[0] = 1'b0;
    assign proc_22_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_22[0] = dl_detect_out ? proc_dep_vld_vec_22_reg[0] : (proc_22_data_FIFO_blk[0] | proc_22_data_PIPO_blk[0] | proc_22_start_FIFO_blk[0] | proc_22_TLF_FIFO_blk[0] | proc_22_input_sync_blk[0] | proc_22_output_sync_blk[0]);
    assign proc_22_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.grp_p_anonymous_namespace_gaussian4_vertical_Pipeline_VerticalGaussianQuads_fu_162.blur_quads_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.p_width_val_c6_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.p_height_val_c12_blk_n);
    assign proc_22_data_PIPO_blk[1] = 1'b0;
    assign proc_22_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_0_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_gaussian4_vertical_U0.real_start & (trans_in_cnt_9 == trans_out_cnt_9) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_0_U0_U.if_read);
    assign proc_22_TLF_FIFO_blk[1] = 1'b0;
    assign proc_22_input_sync_blk[1] = 1'b0;
    assign proc_22_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_22[1] = dl_detect_out ? proc_dep_vld_vec_22_reg[1] : (proc_22_data_FIFO_blk[1] | proc_22_data_PIPO_blk[1] | proc_22_start_FIFO_blk[1] | proc_22_TLF_FIFO_blk[1] | proc_22_input_sync_blk[1] | proc_22_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_22_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_22_reg <= proc_dep_vld_vec_22;
        end
    end
    assign in_chan_dep_vld_vec_22[0] = dep_chan_vld_21_22;
    assign in_chan_dep_data_vec_22[34 : 0] = dep_chan_data_21_22;
    assign token_in_vec_22[0] = token_21_22;
    assign in_chan_dep_vld_vec_22[1] = dep_chan_vld_23_22;
    assign in_chan_dep_data_vec_22[69 : 35] = dep_chan_data_23_22;
    assign token_in_vec_22[1] = token_23_22;
    assign dep_chan_vld_22_21 = out_chan_dep_vld_vec_22[0];
    assign dep_chan_data_22_21 = out_chan_dep_data_22;
    assign token_22_21 = token_out_vec_22[0];
    assign dep_chan_vld_22_23 = out_chan_dep_vld_vec_22[1];
    assign dep_chan_data_22_23 = out_chan_dep_data_22;
    assign token_22_23 = token_out_vec_22[1];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 23, 3, 3) fastv2_layer2_hls_hls_deadlock_detect_unit_23 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_23),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_23),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_23),
        .token_in_vec(token_in_vec_23),
        .dl_detect_in(dl_detect_out),
        .origin(origin[23]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_23),
        .out_chan_dep_data(out_chan_dep_data_23),
        .token_out_vec(token_out_vec_23),
        .dl_detect_out(dl_in_vec[23]));

    assign proc_23_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.grp_p_anonymous_namespace_layer_pack_quads_0_Pipeline_PackLayerQuads_fu_73.blur_quads_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.width_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.height_blk_n);
    assign proc_23_data_PIPO_blk[0] = 1'b0;
    assign proc_23_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_0_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_0_U0_U.if_write);
    assign proc_23_TLF_FIFO_blk[0] = 1'b0;
    assign proc_23_input_sync_blk[0] = 1'b0;
    assign proc_23_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_23[0] = dl_detect_out ? proc_dep_vld_vec_23_reg[0] : (proc_23_data_FIFO_blk[0] | proc_23_data_PIPO_blk[0] | proc_23_start_FIFO_blk[0] | proc_23_TLF_FIFO_blk[0] | proc_23_input_sync_blk[0] | proc_23_output_sync_blk[0]);
    assign proc_23_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.blur_words_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.grp_p_anonymous_namespace_layer_pack_quads_0_Pipeline_PackLayerQuads_fu_73.blur_words_blk_n);
    assign proc_23_data_PIPO_blk[1] = 1'b0;
    assign proc_23_start_FIFO_blk[1] = 1'b0;
    assign proc_23_TLF_FIFO_blk[1] = 1'b0;
    assign proc_23_input_sync_blk[1] = 1'b0;
    assign proc_23_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_23[1] = dl_detect_out ? proc_dep_vld_vec_23_reg[1] : (proc_23_data_FIFO_blk[1] | proc_23_data_PIPO_blk[1] | proc_23_start_FIFO_blk[1] | proc_23_TLF_FIFO_blk[1] | proc_23_input_sync_blk[1] | proc_23_output_sync_blk[1]);
    assign proc_23_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.blur_words_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_0_U0.grp_p_anonymous_namespace_layer_pack_quads_0_Pipeline_PackLayerQuads_fu_73.blur_words_blk_n);
    assign proc_23_data_PIPO_blk[2] = 1'b0;
    assign proc_23_start_FIFO_blk[2] = 1'b0;
    assign proc_23_TLF_FIFO_blk[2] = 1'b0;
    assign proc_23_input_sync_blk[2] = 1'b0;
    assign proc_23_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_23[2] = dl_detect_out ? proc_dep_vld_vec_23_reg[2] : (proc_23_data_FIFO_blk[2] | proc_23_data_PIPO_blk[2] | proc_23_start_FIFO_blk[2] | proc_23_TLF_FIFO_blk[2] | proc_23_input_sync_blk[2] | proc_23_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_23_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_23_reg <= proc_dep_vld_vec_23;
        end
    end
    assign in_chan_dep_vld_vec_23[0] = dep_chan_vld_22_23;
    assign in_chan_dep_data_vec_23[34 : 0] = dep_chan_data_22_23;
    assign token_in_vec_23[0] = token_22_23;
    assign in_chan_dep_vld_vec_23[1] = dep_chan_vld_24_23;
    assign in_chan_dep_data_vec_23[69 : 35] = dep_chan_data_24_23;
    assign token_in_vec_23[1] = token_24_23;
    assign in_chan_dep_vld_vec_23[2] = dep_chan_vld_26_23;
    assign in_chan_dep_data_vec_23[104 : 70] = dep_chan_data_26_23;
    assign token_in_vec_23[2] = token_26_23;
    assign dep_chan_vld_23_22 = out_chan_dep_vld_vec_23[0];
    assign dep_chan_data_23_22 = out_chan_dep_data_23;
    assign token_23_22 = token_out_vec_23[0];
    assign dep_chan_vld_23_24 = out_chan_dep_vld_vec_23[1];
    assign dep_chan_data_23_24 = out_chan_dep_data_23;
    assign token_23_24 = token_out_vec_23[1];
    assign dep_chan_vld_23_26 = out_chan_dep_vld_vec_23[2];
    assign dep_chan_data_23_26 = out_chan_dep_data_23;
    assign token_23_26 = token_out_vec_23[2];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 24, 7, 7) fastv2_layer2_hls_hls_deadlock_detect_unit_24 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_24),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_24),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_24),
        .token_in_vec(token_in_vec_24),
        .dl_detect_in(dl_detect_out),
        .origin(origin[24]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_24),
        .out_chan_dep_data(out_chan_dep_data_24),
        .token_out_vec(token_out_vec_24),
        .dl_detect_out(dl_in_vec[24]));

    assign proc_24_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.grp_p_anonymous_namespace_collect_layer_blocks_0_Pipeline_CollectLayerBlocks_fu_118.blur_words_blk_n);
    assign proc_24_data_PIPO_blk[0] = 1'b0;
    assign proc_24_start_FIFO_blk[0] = 1'b0;
    assign proc_24_TLF_FIFO_blk[0] = 1'b0;
    assign proc_24_input_sync_blk[0] = 1'b0;
    assign proc_24_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_24[0] = dl_detect_out ? proc_dep_vld_vec_24_reg[0] : (proc_24_data_FIFO_blk[0] | proc_24_data_PIPO_blk[0] | proc_24_start_FIFO_blk[0] | proc_24_TLF_FIFO_blk[0] | proc_24_input_sync_blk[0] | proc_24_output_sync_blk[0]);
    assign proc_24_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.blurred_blk_n);
    assign proc_24_data_PIPO_blk[1] = 1'b0;
    assign proc_24_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer4_write_dataflow_0_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer4_write_dataflow_0_U0_U.if_write);
    assign proc_24_TLF_FIFO_blk[1] = 1'b0;
    assign proc_24_input_sync_blk[1] = 1'b0;
    assign proc_24_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_24[1] = dl_detect_out ? proc_dep_vld_vec_24_reg[1] : (proc_24_data_FIFO_blk[1] | proc_24_data_PIPO_blk[1] | proc_24_start_FIFO_blk[1] | proc_24_TLF_FIFO_blk[1] | proc_24_input_sync_blk[1] | proc_24_output_sync_blk[1]);
    assign proc_24_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.mul_loc_blk_n);
    assign proc_24_data_PIPO_blk[2] = 1'b0;
    assign proc_24_start_FIFO_blk[2] = 1'b0;
    assign proc_24_TLF_FIFO_blk[2] = 1'b0;
    assign proc_24_input_sync_blk[2] = 1'b0;
    assign proc_24_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_24[2] = dl_detect_out ? proc_dep_vld_vec_24_reg[2] : (proc_24_data_FIFO_blk[2] | proc_24_data_PIPO_blk[2] | proc_24_start_FIFO_blk[2] | proc_24_TLF_FIFO_blk[2] | proc_24_input_sync_blk[2] | proc_24_output_sync_blk[2]);
    assign proc_24_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.mul_loc_blk_n);
    assign proc_24_data_PIPO_blk[3] = 1'b0;
    assign proc_24_start_FIFO_blk[3] = 1'b0;
    assign proc_24_TLF_FIFO_blk[3] = 1'b0;
    assign proc_24_input_sync_blk[3] = 1'b0;
    assign proc_24_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_24[3] = dl_detect_out ? proc_dep_vld_vec_24_reg[3] : (proc_24_data_FIFO_blk[3] | proc_24_data_PIPO_blk[3] | proc_24_start_FIFO_blk[3] | proc_24_TLF_FIFO_blk[3] | proc_24_input_sync_blk[3] | proc_24_output_sync_blk[3]);
    assign proc_24_data_FIFO_blk[4] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_flush_layer_blocks_0_U0.blur_done_blk_n);
    assign proc_24_data_PIPO_blk[4] = 1'b0;
    assign proc_24_start_FIFO_blk[4] = 1'b0;
    assign proc_24_TLF_FIFO_blk[4] = 1'b0;
    assign proc_24_input_sync_blk[4] = 1'b0;
    assign proc_24_output_sync_blk[4] = 1'b0 | (ap_done_reg_6 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_done);
    assign proc_dep_vld_vec_24[4] = dl_detect_out ? proc_dep_vld_vec_24_reg[4] : (proc_24_data_FIFO_blk[4] | proc_24_data_PIPO_blk[4] | proc_24_start_FIFO_blk[4] | proc_24_TLF_FIFO_blk[4] | proc_24_input_sync_blk[4] | proc_24_output_sync_blk[4]);
    assign proc_24_data_FIFO_blk[5] = 1'b0;
    assign proc_24_data_PIPO_blk[5] = 1'b0;
    assign proc_24_start_FIFO_blk[5] = 1'b0;
    assign proc_24_TLF_FIFO_blk[5] = 1'b0;
    assign proc_24_input_sync_blk[5] = 1'b0;
    assign proc_24_output_sync_blk[5] = 1'b0 | (ap_done_reg_6 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done);
    assign proc_dep_vld_vec_24[5] = dl_detect_out ? proc_dep_vld_vec_24_reg[5] : (proc_24_data_FIFO_blk[5] | proc_24_data_PIPO_blk[5] | proc_24_start_FIFO_blk[5] | proc_24_TLF_FIFO_blk[5] | proc_24_input_sync_blk[5] | proc_24_output_sync_blk[5]);
    assign proc_24_data_FIFO_blk[6] = 1'b0;
    assign proc_24_data_PIPO_blk[6] = 1'b0;
    assign proc_24_start_FIFO_blk[6] = 1'b0;
    assign proc_24_TLF_FIFO_blk[6] = 1'b0;
    assign proc_24_input_sync_blk[6] = 1'b0;
    assign proc_24_output_sync_blk[6] = 1'b0 | (ap_done_reg_6 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_done);
    assign proc_dep_vld_vec_24[6] = dl_detect_out ? proc_dep_vld_vec_24_reg[6] : (proc_24_data_FIFO_blk[6] | proc_24_data_PIPO_blk[6] | proc_24_start_FIFO_blk[6] | proc_24_TLF_FIFO_blk[6] | proc_24_input_sync_blk[6] | proc_24_output_sync_blk[6]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_24_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_24_reg <= proc_dep_vld_vec_24;
        end
    end
    assign in_chan_dep_vld_vec_24[0] = dep_chan_vld_0_24;
    assign in_chan_dep_data_vec_24[34 : 0] = dep_chan_data_0_24;
    assign token_in_vec_24[0] = token_0_24;
    assign in_chan_dep_vld_vec_24[1] = dep_chan_vld_2_24;
    assign in_chan_dep_data_vec_24[69 : 35] = dep_chan_data_2_24;
    assign token_in_vec_24[1] = token_2_24;
    assign in_chan_dep_vld_vec_24[2] = dep_chan_vld_3_24;
    assign in_chan_dep_data_vec_24[104 : 70] = dep_chan_data_3_24;
    assign token_in_vec_24[2] = token_3_24;
    assign in_chan_dep_vld_vec_24[3] = dep_chan_vld_10_24;
    assign in_chan_dep_data_vec_24[139 : 105] = dep_chan_data_10_24;
    assign token_in_vec_24[3] = token_10_24;
    assign in_chan_dep_vld_vec_24[4] = dep_chan_vld_23_24;
    assign in_chan_dep_data_vec_24[174 : 140] = dep_chan_data_23_24;
    assign token_in_vec_24[4] = token_23_24;
    assign in_chan_dep_vld_vec_24[5] = dep_chan_vld_30_24;
    assign in_chan_dep_data_vec_24[209 : 175] = dep_chan_data_30_24;
    assign token_in_vec_24[5] = token_30_24;
    assign in_chan_dep_vld_vec_24[6] = dep_chan_vld_34_24;
    assign in_chan_dep_data_vec_24[244 : 210] = dep_chan_data_34_24;
    assign token_in_vec_24[6] = token_34_24;
    assign dep_chan_vld_24_23 = out_chan_dep_vld_vec_24[0];
    assign dep_chan_data_24_23 = out_chan_dep_data_24;
    assign token_24_23 = token_out_vec_24[0];
    assign dep_chan_vld_24_0 = out_chan_dep_vld_vec_24[1];
    assign dep_chan_data_24_0 = out_chan_dep_data_24;
    assign token_24_0 = token_out_vec_24[1];
    assign dep_chan_vld_24_2 = out_chan_dep_vld_vec_24[2];
    assign dep_chan_data_24_2 = out_chan_dep_data_24;
    assign token_24_2 = token_out_vec_24[2];
    assign dep_chan_vld_24_3 = out_chan_dep_vld_vec_24[3];
    assign dep_chan_data_24_3 = out_chan_dep_data_24;
    assign token_24_3 = token_out_vec_24[3];
    assign dep_chan_vld_24_34 = out_chan_dep_vld_vec_24[4];
    assign dep_chan_data_24_34 = out_chan_dep_data_24;
    assign token_24_34 = token_out_vec_24[4];
    assign dep_chan_vld_24_10 = out_chan_dep_vld_vec_24[5];
    assign dep_chan_data_24_10 = out_chan_dep_data_24;
    assign token_24_10 = token_out_vec_24[5];
    assign dep_chan_vld_24_30 = out_chan_dep_vld_vec_24[6];
    assign dep_chan_data_24_30 = out_chan_dep_data_24;
    assign token_24_30 = token_out_vec_24[6];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 25, 3, 3) fastv2_layer2_hls_hls_deadlock_detect_unit_25 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_25),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_25),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_25),
        .token_in_vec(token_in_vec_25),
        .dl_detect_in(dl_detect_out),
        .origin(origin[25]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_25),
        .out_chan_dep_data(out_chan_dep_data_25),
        .token_out_vec(token_out_vec_25),
        .dl_detect_out(dl_in_vec[25]));

    assign proc_25_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.blurred_blk_n);
    assign proc_25_data_PIPO_blk[0] = 1'b0;
    assign proc_25_start_FIFO_blk[0] = 1'b0;
    assign proc_25_TLF_FIFO_blk[0] = 1'b0;
    assign proc_25_input_sync_blk[0] = 1'b0;
    assign proc_25_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_25[0] = dl_detect_out ? proc_dep_vld_vec_25_reg[0] : (proc_25_data_FIFO_blk[0] | proc_25_data_PIPO_blk[0] | proc_25_start_FIFO_blk[0] | proc_25_TLF_FIFO_blk[0] | proc_25_input_sync_blk[0] | proc_25_output_sync_blk[0]);
    assign proc_25_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.blurred_c_blk_n);
    assign proc_25_data_PIPO_blk[1] = 1'b0;
    assign proc_25_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.start_for_p_anonymous_namespace_flush_layer_blocks_0_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.real_start & (trans_in_cnt_10 == trans_out_cnt_10) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.start_for_p_anonymous_namespace_flush_layer_blocks_0_U0_U.if_read);
    assign proc_25_TLF_FIFO_blk[1] = 1'b0;
    assign proc_25_input_sync_blk[1] = 1'b0;
    assign proc_25_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_25[1] = dl_detect_out ? proc_dep_vld_vec_25_reg[1] : (proc_25_data_FIFO_blk[1] | proc_25_data_PIPO_blk[1] | proc_25_start_FIFO_blk[1] | proc_25_TLF_FIFO_blk[1] | proc_25_input_sync_blk[1] | proc_25_output_sync_blk[1]);
    assign proc_25_data_FIFO_blk[2] = 1'b0;
    assign proc_25_data_PIPO_blk[2] = 1'b0;
    assign proc_25_start_FIFO_blk[2] = 1'b0;
    assign proc_25_TLF_FIFO_blk[2] = 1'b0;
    assign proc_25_input_sync_blk[2] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_sync_entry_proc26_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.entry_proc26_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_sync_p_anonymous_namespace_collect_layer_blocks_0_U0_ap_ready);
    assign proc_25_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_25[2] = dl_detect_out ? proc_dep_vld_vec_25_reg[2] : (proc_25_data_FIFO_blk[2] | proc_25_data_PIPO_blk[2] | proc_25_start_FIFO_blk[2] | proc_25_TLF_FIFO_blk[2] | proc_25_input_sync_blk[2] | proc_25_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_25_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_25_reg <= proc_dep_vld_vec_25;
        end
    end
    assign in_chan_dep_vld_vec_25[0] = dep_chan_vld_0_25;
    assign in_chan_dep_data_vec_25[34 : 0] = dep_chan_data_0_25;
    assign token_in_vec_25[0] = token_0_25;
    assign in_chan_dep_vld_vec_25[1] = dep_chan_vld_26_25;
    assign in_chan_dep_data_vec_25[69 : 35] = dep_chan_data_26_25;
    assign token_in_vec_25[1] = token_26_25;
    assign in_chan_dep_vld_vec_25[2] = dep_chan_vld_27_25;
    assign in_chan_dep_data_vec_25[104 : 70] = dep_chan_data_27_25;
    assign token_in_vec_25[2] = token_27_25;
    assign dep_chan_vld_25_0 = out_chan_dep_vld_vec_25[0];
    assign dep_chan_data_25_0 = out_chan_dep_data_25;
    assign token_25_0 = token_out_vec_25[0];
    assign dep_chan_vld_25_27 = out_chan_dep_vld_vec_25[1];
    assign dep_chan_data_25_27 = out_chan_dep_data_25;
    assign token_25_27 = token_out_vec_25[1];
    assign dep_chan_vld_25_26 = out_chan_dep_vld_vec_25[2];
    assign dep_chan_data_25_26 = out_chan_dep_data_25;
    assign token_25_26 = token_out_vec_25[2];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 26, 5, 5) fastv2_layer2_hls_hls_deadlock_detect_unit_26 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_26),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_26),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_26),
        .token_in_vec(token_in_vec_26),
        .dl_detect_in(dl_detect_out),
        .origin(origin[26]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_26),
        .out_chan_dep_data(out_chan_dep_data_26),
        .token_out_vec(token_out_vec_26),
        .dl_detect_out(dl_in_vec[26]));

    assign proc_26_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.grp_p_anonymous_namespace_collect_layer_blocks_0_Pipeline_CollectLayerBlocks_fu_118.blur_words_blk_n);
    assign proc_26_data_PIPO_blk[0] = 1'b0;
    assign proc_26_start_FIFO_blk[0] = 1'b0;
    assign proc_26_TLF_FIFO_blk[0] = 1'b0;
    assign proc_26_input_sync_blk[0] = 1'b0;
    assign proc_26_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_26[0] = dl_detect_out ? proc_dep_vld_vec_26_reg[0] : (proc_26_data_FIFO_blk[0] | proc_26_data_PIPO_blk[0] | proc_26_start_FIFO_blk[0] | proc_26_TLF_FIFO_blk[0] | proc_26_input_sync_blk[0] | proc_26_output_sync_blk[0]);
    assign proc_26_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.blocks_i_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.mul_loc_c_blk_n);
    assign proc_26_data_PIPO_blk[1] = 1'b0;
    assign proc_26_start_FIFO_blk[1] = 1'b0;
    assign proc_26_TLF_FIFO_blk[1] = 1'b0;
    assign proc_26_input_sync_blk[1] = 1'b0;
    assign proc_26_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_26[1] = dl_detect_out ? proc_dep_vld_vec_26_reg[1] : (proc_26_data_FIFO_blk[1] | proc_26_data_PIPO_blk[1] | proc_26_start_FIFO_blk[1] | proc_26_TLF_FIFO_blk[1] | proc_26_input_sync_blk[1] | proc_26_output_sync_blk[1]);
    assign proc_26_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.mul_loc_blk_n);
    assign proc_26_data_PIPO_blk[2] = 1'b0;
    assign proc_26_start_FIFO_blk[2] = 1'b0;
    assign proc_26_TLF_FIFO_blk[2] = 1'b0;
    assign proc_26_input_sync_blk[2] = 1'b0;
    assign proc_26_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_26[2] = dl_detect_out ? proc_dep_vld_vec_26_reg[2] : (proc_26_data_FIFO_blk[2] | proc_26_data_PIPO_blk[2] | proc_26_start_FIFO_blk[2] | proc_26_TLF_FIFO_blk[2] | proc_26_input_sync_blk[2] | proc_26_output_sync_blk[2]);
    assign proc_26_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.mul_loc_blk_n);
    assign proc_26_data_PIPO_blk[3] = 1'b0;
    assign proc_26_start_FIFO_blk[3] = 1'b0;
    assign proc_26_TLF_FIFO_blk[3] = 1'b0;
    assign proc_26_input_sync_blk[3] = 1'b0;
    assign proc_26_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_26[3] = dl_detect_out ? proc_dep_vld_vec_26_reg[3] : (proc_26_data_FIFO_blk[3] | proc_26_data_PIPO_blk[3] | proc_26_start_FIFO_blk[3] | proc_26_TLF_FIFO_blk[3] | proc_26_input_sync_blk[3] | proc_26_output_sync_blk[3]);
    assign proc_26_data_FIFO_blk[4] = 1'b0;
    assign proc_26_data_PIPO_blk[4] = 1'b0;
    assign proc_26_start_FIFO_blk[4] = 1'b0;
    assign proc_26_TLF_FIFO_blk[4] = 1'b0;
    assign proc_26_input_sync_blk[4] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_sync_p_anonymous_namespace_collect_layer_blocks_0_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_collect_layer_blocks_0_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_sync_entry_proc26_U0_ap_ready);
    assign proc_26_output_sync_blk[4] = 1'b0;
    assign proc_dep_vld_vec_26[4] = dl_detect_out ? proc_dep_vld_vec_26_reg[4] : (proc_26_data_FIFO_blk[4] | proc_26_data_PIPO_blk[4] | proc_26_start_FIFO_blk[4] | proc_26_TLF_FIFO_blk[4] | proc_26_input_sync_blk[4] | proc_26_output_sync_blk[4]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_26_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_26_reg <= proc_dep_vld_vec_26;
        end
    end
    assign in_chan_dep_vld_vec_26[0] = dep_chan_vld_2_26;
    assign in_chan_dep_data_vec_26[34 : 0] = dep_chan_data_2_26;
    assign token_in_vec_26[0] = token_2_26;
    assign in_chan_dep_vld_vec_26[1] = dep_chan_vld_3_26;
    assign in_chan_dep_data_vec_26[69 : 35] = dep_chan_data_3_26;
    assign token_in_vec_26[1] = token_3_26;
    assign in_chan_dep_vld_vec_26[2] = dep_chan_vld_23_26;
    assign in_chan_dep_data_vec_26[104 : 70] = dep_chan_data_23_26;
    assign token_in_vec_26[2] = token_23_26;
    assign in_chan_dep_vld_vec_26[3] = dep_chan_vld_25_26;
    assign in_chan_dep_data_vec_26[139 : 105] = dep_chan_data_25_26;
    assign token_in_vec_26[3] = token_25_26;
    assign in_chan_dep_vld_vec_26[4] = dep_chan_vld_27_26;
    assign in_chan_dep_data_vec_26[174 : 140] = dep_chan_data_27_26;
    assign token_in_vec_26[4] = token_27_26;
    assign dep_chan_vld_26_23 = out_chan_dep_vld_vec_26[0];
    assign dep_chan_data_26_23 = out_chan_dep_data_26;
    assign token_26_23 = token_out_vec_26[0];
    assign dep_chan_vld_26_27 = out_chan_dep_vld_vec_26[1];
    assign dep_chan_data_26_27 = out_chan_dep_data_26;
    assign token_26_27 = token_out_vec_26[1];
    assign dep_chan_vld_26_2 = out_chan_dep_vld_vec_26[2];
    assign dep_chan_data_26_2 = out_chan_dep_data_26;
    assign token_26_2 = token_out_vec_26[2];
    assign dep_chan_vld_26_3 = out_chan_dep_vld_vec_26[3];
    assign dep_chan_data_26_3 = out_chan_dep_data_26;
    assign token_26_3 = token_out_vec_26[3];
    assign dep_chan_vld_26_25 = out_chan_dep_vld_vec_26[4];
    assign dep_chan_data_26_25 = out_chan_dep_data_26;
    assign token_26_25 = token_out_vec_26[4];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_flush_layer_blocks_0_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 27, 2, 3) fastv2_layer2_hls_hls_deadlock_detect_unit_27 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_27),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_27),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_27),
        .token_in_vec(token_in_vec_27),
        .dl_detect_in(dl_detect_out),
        .origin(origin[27]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_27),
        .out_chan_dep_data(out_chan_dep_data_27),
        .token_out_vec(token_out_vec_27),
        .dl_detect_out(dl_in_vec[27]));

    assign proc_27_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_flush_layer_blocks_0_U0.blocks_i_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_flush_layer_blocks_0_U0.mul_loc_blk_n);
    assign proc_27_data_PIPO_blk[0] = 1'b0;
    assign proc_27_start_FIFO_blk[0] = 1'b0;
    assign proc_27_TLF_FIFO_blk[0] = 1'b0;
    assign proc_27_input_sync_blk[0] = 1'b0;
    assign proc_27_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_27[0] = dl_detect_out ? proc_dep_vld_vec_27_reg[0] : (proc_27_data_FIFO_blk[0] | proc_27_data_PIPO_blk[0] | proc_27_start_FIFO_blk[0] | proc_27_TLF_FIFO_blk[0] | proc_27_input_sync_blk[0] | proc_27_output_sync_blk[0]);
    assign proc_27_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_flush_layer_blocks_0_U0.blurred_blk_n);
    assign proc_27_data_PIPO_blk[1] = 1'b0;
    assign proc_27_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.start_for_p_anonymous_namespace_flush_layer_blocks_0_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_flush_layer_blocks_0_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.start_for_p_anonymous_namespace_flush_layer_blocks_0_U0_U.if_write);
    assign proc_27_TLF_FIFO_blk[1] = 1'b0;
    assign proc_27_input_sync_blk[1] = 1'b0;
    assign proc_27_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_27[1] = dl_detect_out ? proc_dep_vld_vec_27_reg[1] : (proc_27_data_FIFO_blk[1] | proc_27_data_PIPO_blk[1] | proc_27_start_FIFO_blk[1] | proc_27_TLF_FIFO_blk[1] | proc_27_input_sync_blk[1] | proc_27_output_sync_blk[1]);
    assign proc_27_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.p_anonymous_namespace_flush_layer_blocks_0_U0.blur_done_blk_n);
    assign proc_27_data_PIPO_blk[2] = 1'b0;
    assign proc_27_start_FIFO_blk[2] = 1'b0;
    assign proc_27_TLF_FIFO_blk[2] = 1'b0;
    assign proc_27_input_sync_blk[2] = 1'b0;
    assign proc_27_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_27[2] = dl_detect_out ? proc_dep_vld_vec_27_reg[2] : (proc_27_data_FIFO_blk[2] | proc_27_data_PIPO_blk[2] | proc_27_start_FIFO_blk[2] | proc_27_TLF_FIFO_blk[2] | proc_27_input_sync_blk[2] | proc_27_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_27_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_27_reg <= proc_dep_vld_vec_27;
        end
    end
    assign in_chan_dep_vld_vec_27[0] = dep_chan_vld_25_27;
    assign in_chan_dep_data_vec_27[34 : 0] = dep_chan_data_25_27;
    assign token_in_vec_27[0] = token_25_27;
    assign in_chan_dep_vld_vec_27[1] = dep_chan_vld_26_27;
    assign in_chan_dep_data_vec_27[69 : 35] = dep_chan_data_26_27;
    assign token_in_vec_27[1] = token_26_27;
    assign dep_chan_vld_27_26 = out_chan_dep_vld_vec_27[0];
    assign dep_chan_data_27_26 = out_chan_dep_data_27;
    assign token_27_26 = token_out_vec_27[0];
    assign dep_chan_vld_27_25 = out_chan_dep_vld_vec_27[1];
    assign dep_chan_data_27_25 = out_chan_dep_data_27;
    assign token_27_25 = token_out_vec_27[1];
    assign dep_chan_vld_27_34 = out_chan_dep_vld_vec_27[2];
    assign dep_chan_data_27_34 = out_chan_dep_data_27;
    assign token_27_34 = token_out_vec_27[2];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 28, 4, 4) fastv2_layer2_hls_hls_deadlock_detect_unit_28 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_28),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_28),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_28),
        .token_in_vec(token_in_vec_28),
        .dl_detect_in(dl_detect_out),
        .origin(origin[28]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_28),
        .out_chan_dep_data(out_chan_dep_data_28),
        .token_out_vec(token_out_vec_28),
        .dl_detect_out(dl_in_vec[28]));

    assign proc_28_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.grp_p_anonymous_namespace_resize4_quads_Pipeline_ResizeSourceQuads_fu_179.resize_raw_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.width_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.height_blk_n);
    assign proc_28_data_PIPO_blk[0] = 1'b0;
    assign proc_28_start_FIFO_blk[0] = 1'b0;
    assign proc_28_TLF_FIFO_blk[0] = 1'b0;
    assign proc_28_input_sync_blk[0] = 1'b0;
    assign proc_28_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_28[0] = dl_detect_out ? proc_dep_vld_vec_28_reg[0] : (proc_28_data_FIFO_blk[0] | proc_28_data_PIPO_blk[0] | proc_28_start_FIFO_blk[0] | proc_28_TLF_FIFO_blk[0] | proc_28_input_sync_blk[0] | proc_28_output_sync_blk[0]);
    assign proc_28_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.grp_p_anonymous_namespace_resize4_quads_Pipeline_ResizeSourceQuads_fu_179.resize_quads_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.dh_c_blk_n);
    assign proc_28_data_PIPO_blk[1] = 1'b0;
    assign proc_28_start_FIFO_blk[1] = 1'b0;
    assign proc_28_TLF_FIFO_blk[1] = 1'b0;
    assign proc_28_input_sync_blk[1] = 1'b0;
    assign proc_28_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_28[1] = dl_detect_out ? proc_dep_vld_vec_28_reg[1] : (proc_28_data_FIFO_blk[1] | proc_28_data_PIPO_blk[1] | proc_28_start_FIFO_blk[1] | proc_28_TLF_FIFO_blk[1] | proc_28_input_sync_blk[1] | proc_28_output_sync_blk[1]);
    assign proc_28_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.level_blk_n);
    assign proc_28_data_PIPO_blk[2] = 1'b0;
    assign proc_28_start_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_resize4_quads_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_resize4_quads_U0_U.if_write);
    assign proc_28_TLF_FIFO_blk[2] = 1'b0;
    assign proc_28_input_sync_blk[2] = 1'b0;
    assign proc_28_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_28[2] = dl_detect_out ? proc_dep_vld_vec_28_reg[2] : (proc_28_data_FIFO_blk[2] | proc_28_data_PIPO_blk[2] | proc_28_start_FIFO_blk[2] | proc_28_TLF_FIFO_blk[2] | proc_28_input_sync_blk[2] | proc_28_output_sync_blk[2]);
    assign proc_28_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_resize4_quads_U0.destination_height_blk_n);
    assign proc_28_data_PIPO_blk[3] = 1'b0;
    assign proc_28_start_FIFO_blk[3] = 1'b0;
    assign proc_28_TLF_FIFO_blk[3] = 1'b0;
    assign proc_28_input_sync_blk[3] = 1'b0;
    assign proc_28_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_28[3] = dl_detect_out ? proc_dep_vld_vec_28_reg[3] : (proc_28_data_FIFO_blk[3] | proc_28_data_PIPO_blk[3] | proc_28_start_FIFO_blk[3] | proc_28_TLF_FIFO_blk[3] | proc_28_input_sync_blk[3] | proc_28_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_28_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_28_reg <= proc_dep_vld_vec_28;
        end
    end
    assign in_chan_dep_vld_vec_28[0] = dep_chan_vld_0_28;
    assign in_chan_dep_data_vec_28[34 : 0] = dep_chan_data_0_28;
    assign token_in_vec_28[0] = token_0_28;
    assign in_chan_dep_vld_vec_28[1] = dep_chan_vld_1_28;
    assign in_chan_dep_data_vec_28[69 : 35] = dep_chan_data_1_28;
    assign token_in_vec_28[1] = token_1_28;
    assign in_chan_dep_vld_vec_28[2] = dep_chan_vld_7_28;
    assign in_chan_dep_data_vec_28[104 : 70] = dep_chan_data_7_28;
    assign token_in_vec_28[2] = token_7_28;
    assign in_chan_dep_vld_vec_28[3] = dep_chan_vld_29_28;
    assign in_chan_dep_data_vec_28[139 : 105] = dep_chan_data_29_28;
    assign token_in_vec_28[3] = token_29_28;
    assign dep_chan_vld_28_7 = out_chan_dep_vld_vec_28[0];
    assign dep_chan_data_28_7 = out_chan_dep_data_28;
    assign token_28_7 = token_out_vec_28[0];
    assign dep_chan_vld_28_29 = out_chan_dep_vld_vec_28[1];
    assign dep_chan_data_28_29 = out_chan_dep_data_28;
    assign token_28_29 = token_out_vec_28[1];
    assign dep_chan_vld_28_0 = out_chan_dep_vld_vec_28[2];
    assign dep_chan_data_28_0 = out_chan_dep_data_28;
    assign token_28_0 = token_out_vec_28[2];
    assign dep_chan_vld_28_1 = out_chan_dep_vld_vec_28[3];
    assign dep_chan_data_28_1 = out_chan_dep_data_28;
    assign token_28_1 = token_out_vec_28[3];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 29, 4, 4) fastv2_layer2_hls_hls_deadlock_detect_unit_29 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_29),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_29),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_29),
        .token_in_vec(token_in_vec_29),
        .dl_detect_in(dl_detect_out),
        .origin(origin[29]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_29),
        .out_chan_dep_data(out_chan_dep_data_29),
        .token_out_vec(token_out_vec_29),
        .dl_detect_out(dl_in_vec[29]));

    assign proc_29_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.grp_p_anonymous_namespace_layer_pack_quads_1_Pipeline_PackLayerQuads_fu_73.resize_quads_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.height_blk_n);
    assign proc_29_data_PIPO_blk[0] = 1'b0;
    assign proc_29_start_FIFO_blk[0] = 1'b0;
    assign proc_29_TLF_FIFO_blk[0] = 1'b0;
    assign proc_29_input_sync_blk[0] = 1'b0;
    assign proc_29_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_29[0] = dl_detect_out ? proc_dep_vld_vec_29_reg[0] : (proc_29_data_FIFO_blk[0] | proc_29_data_PIPO_blk[0] | proc_29_start_FIFO_blk[0] | proc_29_TLF_FIFO_blk[0] | proc_29_input_sync_blk[0] | proc_29_output_sync_blk[0]);
    assign proc_29_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.resize_words_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.grp_p_anonymous_namespace_layer_pack_quads_1_Pipeline_PackLayerQuads_fu_73.resize_words_blk_n);
    assign proc_29_data_PIPO_blk[1] = 1'b0;
    assign proc_29_start_FIFO_blk[1] = 1'b0;
    assign proc_29_TLF_FIFO_blk[1] = 1'b0;
    assign proc_29_input_sync_blk[1] = 1'b0;
    assign proc_29_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_29[1] = dl_detect_out ? proc_dep_vld_vec_29_reg[1] : (proc_29_data_FIFO_blk[1] | proc_29_data_PIPO_blk[1] | proc_29_start_FIFO_blk[1] | proc_29_TLF_FIFO_blk[1] | proc_29_input_sync_blk[1] | proc_29_output_sync_blk[1]);
    assign proc_29_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.resize_words_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.grp_p_anonymous_namespace_layer_pack_quads_1_Pipeline_PackLayerQuads_fu_73.resize_words_blk_n);
    assign proc_29_data_PIPO_blk[2] = 1'b0;
    assign proc_29_start_FIFO_blk[2] = 1'b0;
    assign proc_29_TLF_FIFO_blk[2] = 1'b0;
    assign proc_29_input_sync_blk[2] = 1'b0;
    assign proc_29_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_29[2] = dl_detect_out ? proc_dep_vld_vec_29_reg[2] : (proc_29_data_FIFO_blk[2] | proc_29_data_PIPO_blk[2] | proc_29_start_FIFO_blk[2] | proc_29_TLF_FIFO_blk[2] | proc_29_input_sync_blk[2] | proc_29_output_sync_blk[2]);
    assign proc_29_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.width_blk_n);
    assign proc_29_data_PIPO_blk[3] = 1'b0;
    assign proc_29_start_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_1_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer_pack_quads_1_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_layer_pack_quads_1_U0_U.if_write);
    assign proc_29_TLF_FIFO_blk[3] = 1'b0;
    assign proc_29_input_sync_blk[3] = 1'b0;
    assign proc_29_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_29[3] = dl_detect_out ? proc_dep_vld_vec_29_reg[3] : (proc_29_data_FIFO_blk[3] | proc_29_data_PIPO_blk[3] | proc_29_start_FIFO_blk[3] | proc_29_TLF_FIFO_blk[3] | proc_29_input_sync_blk[3] | proc_29_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_29_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_29_reg <= proc_dep_vld_vec_29;
        end
    end
    assign in_chan_dep_vld_vec_29[0] = dep_chan_vld_1_29;
    assign in_chan_dep_data_vec_29[34 : 0] = dep_chan_data_1_29;
    assign token_in_vec_29[0] = token_1_29;
    assign in_chan_dep_vld_vec_29[1] = dep_chan_vld_28_29;
    assign in_chan_dep_data_vec_29[69 : 35] = dep_chan_data_28_29;
    assign token_in_vec_29[1] = token_28_29;
    assign in_chan_dep_vld_vec_29[2] = dep_chan_vld_30_29;
    assign in_chan_dep_data_vec_29[104 : 70] = dep_chan_data_30_29;
    assign token_in_vec_29[2] = token_30_29;
    assign in_chan_dep_vld_vec_29[3] = dep_chan_vld_32_29;
    assign in_chan_dep_data_vec_29[139 : 105] = dep_chan_data_32_29;
    assign token_in_vec_29[3] = token_32_29;
    assign dep_chan_vld_29_28 = out_chan_dep_vld_vec_29[0];
    assign dep_chan_data_29_28 = out_chan_dep_data_29;
    assign token_29_28 = token_out_vec_29[0];
    assign dep_chan_vld_29_30 = out_chan_dep_vld_vec_29[1];
    assign dep_chan_data_29_30 = out_chan_dep_data_29;
    assign token_29_30 = token_out_vec_29[1];
    assign dep_chan_vld_29_32 = out_chan_dep_vld_vec_29[2];
    assign dep_chan_data_29_32 = out_chan_dep_data_29;
    assign token_29_32 = token_out_vec_29[2];
    assign dep_chan_vld_29_1 = out_chan_dep_vld_vec_29[3];
    assign dep_chan_data_29_1 = out_chan_dep_data_29;
    assign token_29_1 = token_out_vec_29[3];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 30, 5, 6) fastv2_layer2_hls_hls_deadlock_detect_unit_30 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_30),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_30),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_30),
        .token_in_vec(token_in_vec_30),
        .dl_detect_in(dl_detect_out),
        .origin(origin[30]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_30),
        .out_chan_dep_data(out_chan_dep_data_30),
        .token_out_vec(token_out_vec_30),
        .dl_detect_out(dl_in_vec[30]));

    assign proc_30_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.grp_p_anonymous_namespace_collect_layer_blocks_1_Pipeline_CollectLayerBlocks_fu_118.resize_words_blk_n);
    assign proc_30_data_PIPO_blk[0] = 1'b0;
    assign proc_30_start_FIFO_blk[0] = 1'b0;
    assign proc_30_TLF_FIFO_blk[0] = 1'b0;
    assign proc_30_input_sync_blk[0] = 1'b0;
    assign proc_30_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_30[0] = dl_detect_out ? proc_dep_vld_vec_30_reg[0] : (proc_30_data_FIFO_blk[0] | proc_30_data_PIPO_blk[0] | proc_30_start_FIFO_blk[0] | proc_30_TLF_FIFO_blk[0] | proc_30_input_sync_blk[0] | proc_30_output_sync_blk[0]);
    assign proc_30_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.resized_blk_n);
    assign proc_30_data_PIPO_blk[1] = 1'b0;
    assign proc_30_start_FIFO_blk[1] = 1'b0;
    assign proc_30_TLF_FIFO_blk[1] = 1'b0;
    assign proc_30_input_sync_blk[1] = 1'b0;
    assign proc_30_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_30[1] = dl_detect_out ? proc_dep_vld_vec_30_reg[1] : (proc_30_data_FIFO_blk[1] | proc_30_data_PIPO_blk[1] | proc_30_start_FIFO_blk[1] | proc_30_TLF_FIFO_blk[1] | proc_30_input_sync_blk[1] | proc_30_output_sync_blk[1]);
    assign proc_30_data_FIFO_blk[2] = 1'b0;
    assign proc_30_data_PIPO_blk[2] = 1'b0;
    assign proc_30_start_FIFO_blk[2] = 1'b0;
    assign proc_30_TLF_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul16_loc_channel_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul16_loc_channel_U.if_write);
    assign proc_30_input_sync_blk[2] = 1'b0;
    assign proc_30_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_30[2] = dl_detect_out ? proc_dep_vld_vec_30_reg[2] : (proc_30_data_FIFO_blk[2] | proc_30_data_PIPO_blk[2] | proc_30_start_FIFO_blk[2] | proc_30_TLF_FIFO_blk[2] | proc_30_input_sync_blk[2] | proc_30_output_sync_blk[2]);
    assign proc_30_data_FIFO_blk[3] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_flush_layer_blocks_1_U0.resize_done_blk_n);
    assign proc_30_data_PIPO_blk[3] = 1'b0;
    assign proc_30_start_FIFO_blk[3] = 1'b0;
    assign proc_30_TLF_FIFO_blk[3] = 1'b0;
    assign proc_30_input_sync_blk[3] = 1'b0;
    assign proc_30_output_sync_blk[3] = 1'b0 | (ap_done_reg_3 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_done);
    assign proc_dep_vld_vec_30[3] = dl_detect_out ? proc_dep_vld_vec_30_reg[3] : (proc_30_data_FIFO_blk[3] | proc_30_data_PIPO_blk[3] | proc_30_start_FIFO_blk[3] | proc_30_TLF_FIFO_blk[3] | proc_30_input_sync_blk[3] | proc_30_output_sync_blk[3]);
    assign proc_30_data_FIFO_blk[4] = 1'b0;
    assign proc_30_data_PIPO_blk[4] = 1'b0;
    assign proc_30_start_FIFO_blk[4] = 1'b0;
    assign proc_30_TLF_FIFO_blk[4] = 1'b0;
    assign proc_30_input_sync_blk[4] = 1'b0;
    assign proc_30_output_sync_blk[4] = 1'b0 | (ap_done_reg_3 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done);
    assign proc_dep_vld_vec_30[4] = dl_detect_out ? proc_dep_vld_vec_30_reg[4] : (proc_30_data_FIFO_blk[4] | proc_30_data_PIPO_blk[4] | proc_30_start_FIFO_blk[4] | proc_30_TLF_FIFO_blk[4] | proc_30_input_sync_blk[4] | proc_30_output_sync_blk[4]);
    assign proc_30_data_FIFO_blk[5] = 1'b0;
    assign proc_30_data_PIPO_blk[5] = 1'b0;
    assign proc_30_start_FIFO_blk[5] = 1'b0;
    assign proc_30_TLF_FIFO_blk[5] = 1'b0;
    assign proc_30_input_sync_blk[5] = 1'b0;
    assign proc_30_output_sync_blk[5] = 1'b0 | (ap_done_reg_3 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_done);
    assign proc_dep_vld_vec_30[5] = dl_detect_out ? proc_dep_vld_vec_30_reg[5] : (proc_30_data_FIFO_blk[5] | proc_30_data_PIPO_blk[5] | proc_30_start_FIFO_blk[5] | proc_30_TLF_FIFO_blk[5] | proc_30_input_sync_blk[5] | proc_30_output_sync_blk[5]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_30_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_30_reg <= proc_dep_vld_vec_30;
        end
    end
    assign in_chan_dep_vld_vec_30[0] = dep_chan_vld_0_30;
    assign in_chan_dep_data_vec_30[34 : 0] = dep_chan_data_0_30;
    assign token_in_vec_30[0] = token_0_30;
    assign in_chan_dep_vld_vec_30[1] = dep_chan_vld_10_30;
    assign in_chan_dep_data_vec_30[69 : 35] = dep_chan_data_10_30;
    assign token_in_vec_30[1] = token_10_30;
    assign in_chan_dep_vld_vec_30[2] = dep_chan_vld_24_30;
    assign in_chan_dep_data_vec_30[104 : 70] = dep_chan_data_24_30;
    assign token_in_vec_30[2] = token_24_30;
    assign in_chan_dep_vld_vec_30[3] = dep_chan_vld_29_30;
    assign in_chan_dep_data_vec_30[139 : 105] = dep_chan_data_29_30;
    assign token_in_vec_30[3] = token_29_30;
    assign in_chan_dep_vld_vec_30[4] = dep_chan_vld_34_30;
    assign in_chan_dep_data_vec_30[174 : 140] = dep_chan_data_34_30;
    assign token_in_vec_30[4] = token_34_30;
    assign dep_chan_vld_30_29 = out_chan_dep_vld_vec_30[0];
    assign dep_chan_data_30_29 = out_chan_dep_data_30;
    assign token_30_29 = token_out_vec_30[0];
    assign dep_chan_vld_30_0 = out_chan_dep_vld_vec_30[1];
    assign dep_chan_data_30_0 = out_chan_dep_data_30;
    assign token_30_0 = token_out_vec_30[1];
    assign dep_chan_vld_30_1 = out_chan_dep_vld_vec_30[2];
    assign dep_chan_data_30_1 = out_chan_dep_data_30;
    assign token_30_1 = token_out_vec_30[2];
    assign dep_chan_vld_30_34 = out_chan_dep_vld_vec_30[3];
    assign dep_chan_data_30_34 = out_chan_dep_data_30;
    assign token_30_34 = token_out_vec_30[3];
    assign dep_chan_vld_30_10 = out_chan_dep_vld_vec_30[4];
    assign dep_chan_data_30_10 = out_chan_dep_data_30;
    assign token_30_10 = token_out_vec_30[4];
    assign dep_chan_vld_30_24 = out_chan_dep_vld_vec_30[5];
    assign dep_chan_data_30_24 = out_chan_dep_data_30;
    assign token_30_24 = token_out_vec_30[5];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 31, 3, 3) fastv2_layer2_hls_hls_deadlock_detect_unit_31 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_31),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_31),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_31),
        .token_in_vec(token_in_vec_31),
        .dl_detect_in(dl_detect_out),
        .origin(origin[31]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_31),
        .out_chan_dep_data(out_chan_dep_data_31),
        .token_out_vec(token_out_vec_31),
        .dl_detect_out(dl_in_vec[31]));

    assign proc_31_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.resized_blk_n);
    assign proc_31_data_PIPO_blk[0] = 1'b0;
    assign proc_31_start_FIFO_blk[0] = 1'b0;
    assign proc_31_TLF_FIFO_blk[0] = 1'b0;
    assign proc_31_input_sync_blk[0] = 1'b0;
    assign proc_31_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_31[0] = dl_detect_out ? proc_dep_vld_vec_31_reg[0] : (proc_31_data_FIFO_blk[0] | proc_31_data_PIPO_blk[0] | proc_31_start_FIFO_blk[0] | proc_31_TLF_FIFO_blk[0] | proc_31_input_sync_blk[0] | proc_31_output_sync_blk[0]);
    assign proc_31_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.resized_c_blk_n);
    assign proc_31_data_PIPO_blk[1] = 1'b0;
    assign proc_31_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.start_for_p_anonymous_namespace_flush_layer_blocks_1_U0_U.if_full_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.ap_start & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.real_start & (trans_in_cnt_11 == trans_out_cnt_11) & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.start_for_p_anonymous_namespace_flush_layer_blocks_1_U0_U.if_read);
    assign proc_31_TLF_FIFO_blk[1] = 1'b0;
    assign proc_31_input_sync_blk[1] = 1'b0;
    assign proc_31_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_31[1] = dl_detect_out ? proc_dep_vld_vec_31_reg[1] : (proc_31_data_FIFO_blk[1] | proc_31_data_PIPO_blk[1] | proc_31_start_FIFO_blk[1] | proc_31_TLF_FIFO_blk[1] | proc_31_input_sync_blk[1] | proc_31_output_sync_blk[1]);
    assign proc_31_data_FIFO_blk[2] = 1'b0;
    assign proc_31_data_PIPO_blk[2] = 1'b0;
    assign proc_31_start_FIFO_blk[2] = 1'b0;
    assign proc_31_TLF_FIFO_blk[2] = 1'b0;
    assign proc_31_input_sync_blk[2] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_sync_entry_proc_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.entry_proc_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_sync_p_anonymous_namespace_collect_layer_blocks_1_U0_ap_ready);
    assign proc_31_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_31[2] = dl_detect_out ? proc_dep_vld_vec_31_reg[2] : (proc_31_data_FIFO_blk[2] | proc_31_data_PIPO_blk[2] | proc_31_start_FIFO_blk[2] | proc_31_TLF_FIFO_blk[2] | proc_31_input_sync_blk[2] | proc_31_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_31_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_31_reg <= proc_dep_vld_vec_31;
        end
    end
    assign in_chan_dep_vld_vec_31[0] = dep_chan_vld_0_31;
    assign in_chan_dep_data_vec_31[34 : 0] = dep_chan_data_0_31;
    assign token_in_vec_31[0] = token_0_31;
    assign in_chan_dep_vld_vec_31[1] = dep_chan_vld_32_31;
    assign in_chan_dep_data_vec_31[69 : 35] = dep_chan_data_32_31;
    assign token_in_vec_31[1] = token_32_31;
    assign in_chan_dep_vld_vec_31[2] = dep_chan_vld_33_31;
    assign in_chan_dep_data_vec_31[104 : 70] = dep_chan_data_33_31;
    assign token_in_vec_31[2] = token_33_31;
    assign dep_chan_vld_31_0 = out_chan_dep_vld_vec_31[0];
    assign dep_chan_data_31_0 = out_chan_dep_data_31;
    assign token_31_0 = token_out_vec_31[0];
    assign dep_chan_vld_31_33 = out_chan_dep_vld_vec_31[1];
    assign dep_chan_data_31_33 = out_chan_dep_data_31;
    assign token_31_33 = token_out_vec_31[1];
    assign dep_chan_vld_31_32 = out_chan_dep_vld_vec_31[2];
    assign dep_chan_data_31_32 = out_chan_dep_data_31;
    assign token_31_32 = token_out_vec_31[2];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 32, 3, 4) fastv2_layer2_hls_hls_deadlock_detect_unit_32 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_32),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_32),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_32),
        .token_in_vec(token_in_vec_32),
        .dl_detect_in(dl_detect_out),
        .origin(origin[32]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_32),
        .out_chan_dep_data(out_chan_dep_data_32),
        .token_out_vec(token_out_vec_32),
        .dl_detect_out(dl_in_vec[32]));

    assign proc_32_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.grp_p_anonymous_namespace_collect_layer_blocks_1_Pipeline_CollectLayerBlocks_fu_118.resize_words_blk_n);
    assign proc_32_data_PIPO_blk[0] = 1'b0;
    assign proc_32_start_FIFO_blk[0] = 1'b0;
    assign proc_32_TLF_FIFO_blk[0] = 1'b0;
    assign proc_32_input_sync_blk[0] = 1'b0;
    assign proc_32_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_32[0] = dl_detect_out ? proc_dep_vld_vec_32_reg[0] : (proc_32_data_FIFO_blk[0] | proc_32_data_PIPO_blk[0] | proc_32_start_FIFO_blk[0] | proc_32_TLF_FIFO_blk[0] | proc_32_input_sync_blk[0] | proc_32_output_sync_blk[0]);
    assign proc_32_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.blocks_i_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.mul16_loc_c_blk_n);
    assign proc_32_data_PIPO_blk[1] = 1'b0;
    assign proc_32_start_FIFO_blk[1] = 1'b0;
    assign proc_32_TLF_FIFO_blk[1] = 1'b0;
    assign proc_32_input_sync_blk[1] = 1'b0;
    assign proc_32_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_32[1] = dl_detect_out ? proc_dep_vld_vec_32_reg[1] : (proc_32_data_FIFO_blk[1] | proc_32_data_PIPO_blk[1] | proc_32_start_FIFO_blk[1] | proc_32_TLF_FIFO_blk[1] | proc_32_input_sync_blk[1] | proc_32_output_sync_blk[1]);
    assign proc_32_data_FIFO_blk[2] = 1'b0;
    assign proc_32_data_PIPO_blk[2] = 1'b0;
    assign proc_32_start_FIFO_blk[2] = 1'b0;
    assign proc_32_TLF_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul16_loc_channel_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.mul16_loc_channel_U.if_write);
    assign proc_32_input_sync_blk[2] = 1'b0;
    assign proc_32_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_32[2] = dl_detect_out ? proc_dep_vld_vec_32_reg[2] : (proc_32_data_FIFO_blk[2] | proc_32_data_PIPO_blk[2] | proc_32_start_FIFO_blk[2] | proc_32_TLF_FIFO_blk[2] | proc_32_input_sync_blk[2] | proc_32_output_sync_blk[2]);
    assign proc_32_data_FIFO_blk[3] = 1'b0;
    assign proc_32_data_PIPO_blk[3] = 1'b0;
    assign proc_32_start_FIFO_blk[3] = 1'b0;
    assign proc_32_TLF_FIFO_blk[3] = 1'b0;
    assign proc_32_input_sync_blk[3] = 1'b0 | (grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_sync_p_anonymous_namespace_collect_layer_blocks_1_U0_ap_ready & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_collect_layer_blocks_1_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_sync_entry_proc_U0_ap_ready);
    assign proc_32_output_sync_blk[3] = 1'b0;
    assign proc_dep_vld_vec_32[3] = dl_detect_out ? proc_dep_vld_vec_32_reg[3] : (proc_32_data_FIFO_blk[3] | proc_32_data_PIPO_blk[3] | proc_32_start_FIFO_blk[3] | proc_32_TLF_FIFO_blk[3] | proc_32_input_sync_blk[3] | proc_32_output_sync_blk[3]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_32_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_32_reg <= proc_dep_vld_vec_32;
        end
    end
    assign in_chan_dep_vld_vec_32[0] = dep_chan_vld_29_32;
    assign in_chan_dep_data_vec_32[34 : 0] = dep_chan_data_29_32;
    assign token_in_vec_32[0] = token_29_32;
    assign in_chan_dep_vld_vec_32[1] = dep_chan_vld_31_32;
    assign in_chan_dep_data_vec_32[69 : 35] = dep_chan_data_31_32;
    assign token_in_vec_32[1] = token_31_32;
    assign in_chan_dep_vld_vec_32[2] = dep_chan_vld_33_32;
    assign in_chan_dep_data_vec_32[104 : 70] = dep_chan_data_33_32;
    assign token_in_vec_32[2] = token_33_32;
    assign dep_chan_vld_32_29 = out_chan_dep_vld_vec_32[0];
    assign dep_chan_data_32_29 = out_chan_dep_data_32;
    assign token_32_29 = token_out_vec_32[0];
    assign dep_chan_vld_32_33 = out_chan_dep_vld_vec_32[1];
    assign dep_chan_data_32_33 = out_chan_dep_data_32;
    assign token_32_33 = token_out_vec_32[1];
    assign dep_chan_vld_32_1 = out_chan_dep_vld_vec_32[2];
    assign dep_chan_data_32_1 = out_chan_dep_data_32;
    assign token_32_1 = token_out_vec_32[2];
    assign dep_chan_vld_32_31 = out_chan_dep_vld_vec_32[3];
    assign dep_chan_data_32_31 = out_chan_dep_data_32;
    assign token_32_31 = token_out_vec_32[3];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_flush_layer_blocks_1_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 33, 2, 3) fastv2_layer2_hls_hls_deadlock_detect_unit_33 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_33),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_33),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_33),
        .token_in_vec(token_in_vec_33),
        .dl_detect_in(dl_detect_out),
        .origin(origin[33]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_33),
        .out_chan_dep_data(out_chan_dep_data_33),
        .token_out_vec(token_out_vec_33),
        .dl_detect_out(dl_in_vec[33]));

    assign proc_33_data_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_flush_layer_blocks_1_U0.blocks_i_blk_n) | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_flush_layer_blocks_1_U0.mul16_loc_blk_n);
    assign proc_33_data_PIPO_blk[0] = 1'b0;
    assign proc_33_start_FIFO_blk[0] = 1'b0;
    assign proc_33_TLF_FIFO_blk[0] = 1'b0;
    assign proc_33_input_sync_blk[0] = 1'b0;
    assign proc_33_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_33[0] = dl_detect_out ? proc_dep_vld_vec_33_reg[0] : (proc_33_data_FIFO_blk[0] | proc_33_data_PIPO_blk[0] | proc_33_start_FIFO_blk[0] | proc_33_TLF_FIFO_blk[0] | proc_33_input_sync_blk[0] | proc_33_output_sync_blk[0]);
    assign proc_33_data_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_flush_layer_blocks_1_U0.resized_blk_n);
    assign proc_33_data_PIPO_blk[1] = 1'b0;
    assign proc_33_start_FIFO_blk[1] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.start_for_p_anonymous_namespace_flush_layer_blocks_1_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_flush_layer_blocks_1_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.start_for_p_anonymous_namespace_flush_layer_blocks_1_U0_U.if_write);
    assign proc_33_TLF_FIFO_blk[1] = 1'b0;
    assign proc_33_input_sync_blk[1] = 1'b0;
    assign proc_33_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_33[1] = dl_detect_out ? proc_dep_vld_vec_33_reg[1] : (proc_33_data_FIFO_blk[1] | proc_33_data_PIPO_blk[1] | proc_33_start_FIFO_blk[1] | proc_33_TLF_FIFO_blk[1] | proc_33_input_sync_blk[1] | proc_33_output_sync_blk[1]);
    assign proc_33_data_FIFO_blk[2] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.p_anonymous_namespace_flush_layer_blocks_1_U0.resize_done_blk_n);
    assign proc_33_data_PIPO_blk[2] = 1'b0;
    assign proc_33_start_FIFO_blk[2] = 1'b0;
    assign proc_33_TLF_FIFO_blk[2] = 1'b0;
    assign proc_33_input_sync_blk[2] = 1'b0;
    assign proc_33_output_sync_blk[2] = 1'b0;
    assign proc_dep_vld_vec_33[2] = dl_detect_out ? proc_dep_vld_vec_33_reg[2] : (proc_33_data_FIFO_blk[2] | proc_33_data_PIPO_blk[2] | proc_33_start_FIFO_blk[2] | proc_33_TLF_FIFO_blk[2] | proc_33_input_sync_blk[2] | proc_33_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_33_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_33_reg <= proc_dep_vld_vec_33;
        end
    end
    assign in_chan_dep_vld_vec_33[0] = dep_chan_vld_31_33;
    assign in_chan_dep_data_vec_33[34 : 0] = dep_chan_data_31_33;
    assign token_in_vec_33[0] = token_31_33;
    assign in_chan_dep_vld_vec_33[1] = dep_chan_vld_32_33;
    assign in_chan_dep_data_vec_33[69 : 35] = dep_chan_data_32_33;
    assign token_in_vec_33[1] = token_32_33;
    assign dep_chan_vld_33_32 = out_chan_dep_vld_vec_33[0];
    assign dep_chan_data_33_32 = out_chan_dep_data_33;
    assign token_33_32 = token_out_vec_33[0];
    assign dep_chan_vld_33_31 = out_chan_dep_vld_vec_33[1];
    assign dep_chan_data_33_31 = out_chan_dep_data_33;
    assign token_33_31 = token_out_vec_33[1];
    assign dep_chan_vld_33_34 = out_chan_dep_vld_vec_33[2];
    assign dep_chan_data_33_34 = out_chan_dep_data_33;
    assign token_33_34 = token_out_vec_33[2];

    // Process: grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0
    fastv2_layer2_hls_hls_deadlock_detect_unit #(35, 34, 5, 3) fastv2_layer2_hls_hls_deadlock_detect_unit_34 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_34),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_34),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_34),
        .token_in_vec(token_in_vec_34),
        .dl_detect_in(dl_detect_out),
        .origin(origin[34]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_34),
        .out_chan_dep_data(out_chan_dep_data_34),
        .token_out_vec(token_out_vec_34),
        .dl_detect_out(dl_in_vec[34]));

    assign proc_34_data_FIFO_blk[0] = 1'b0;
    assign proc_34_data_PIPO_blk[0] = 1'b0;
    assign proc_34_start_FIFO_blk[0] = 1'b0 | (~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_count_layer2_cycles_U0_U.if_empty_n & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_idle & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.start_for_p_anonymous_namespace_count_layer2_cycles_U0_U.if_write);
    assign proc_34_TLF_FIFO_blk[0] = 1'b0;
    assign proc_34_input_sync_blk[0] = 1'b0;
    assign proc_34_output_sync_blk[0] = 1'b0 | (ap_done_reg_7 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_consume_and_select_U0.ap_done);
    assign proc_dep_vld_vec_34[0] = dl_detect_out ? proc_dep_vld_vec_34_reg[0] : (proc_34_data_FIFO_blk[0] | proc_34_data_PIPO_blk[0] | proc_34_start_FIFO_blk[0] | proc_34_TLF_FIFO_blk[0] | proc_34_input_sync_blk[0] | proc_34_output_sync_blk[0]);
    assign proc_34_data_FIFO_blk[1] = 1'b0;
    assign proc_34_data_PIPO_blk[1] = 1'b0;
    assign proc_34_start_FIFO_blk[1] = 1'b0;
    assign proc_34_TLF_FIFO_blk[1] = 1'b0;
    assign proc_34_input_sync_blk[1] = 1'b0;
    assign proc_34_output_sync_blk[1] = 1'b0 | (ap_done_reg_7 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_0_U0.ap_done);
    assign proc_dep_vld_vec_34[1] = dl_detect_out ? proc_dep_vld_vec_34_reg[1] : (proc_34_data_FIFO_blk[1] | proc_34_data_PIPO_blk[1] | proc_34_start_FIFO_blk[1] | proc_34_TLF_FIFO_blk[1] | proc_34_input_sync_blk[1] | proc_34_output_sync_blk[1]);
    assign proc_34_data_FIFO_blk[2] = 1'b0;
    assign proc_34_data_PIPO_blk[2] = 1'b0;
    assign proc_34_start_FIFO_blk[2] = 1'b0;
    assign proc_34_TLF_FIFO_blk[2] = 1'b0;
    assign proc_34_input_sync_blk[2] = 1'b0;
    assign proc_34_output_sync_blk[2] = 1'b0 | (ap_done_reg_7 & grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_count_layer2_cycles_U0.ap_done & ~grp_p_anonymous_namespace_layer4_dataflow_fu_715.p_anonymous_namespace_layer4_write_dataflow_1_U0.ap_done);
    assign proc_dep_vld_vec_34[2] = dl_detect_out ? proc_dep_vld_vec_34_reg[2] : (proc_34_data_FIFO_blk[2] | proc_34_data_PIPO_blk[2] | proc_34_start_FIFO_blk[2] | proc_34_TLF_FIFO_blk[2] | proc_34_input_sync_blk[2] | proc_34_output_sync_blk[2]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_34_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_34_reg <= proc_dep_vld_vec_34;
        end
    end
    assign in_chan_dep_vld_vec_34[0] = dep_chan_vld_10_34;
    assign in_chan_dep_data_vec_34[34 : 0] = dep_chan_data_10_34;
    assign token_in_vec_34[0] = token_10_34;
    assign in_chan_dep_vld_vec_34[1] = dep_chan_vld_24_34;
    assign in_chan_dep_data_vec_34[69 : 35] = dep_chan_data_24_34;
    assign token_in_vec_34[1] = token_24_34;
    assign in_chan_dep_vld_vec_34[2] = dep_chan_vld_27_34;
    assign in_chan_dep_data_vec_34[104 : 70] = dep_chan_data_27_34;
    assign token_in_vec_34[2] = token_27_34;
    assign in_chan_dep_vld_vec_34[3] = dep_chan_vld_30_34;
    assign in_chan_dep_data_vec_34[139 : 105] = dep_chan_data_30_34;
    assign token_in_vec_34[3] = token_30_34;
    assign in_chan_dep_vld_vec_34[4] = dep_chan_vld_33_34;
    assign in_chan_dep_data_vec_34[174 : 140] = dep_chan_data_33_34;
    assign token_in_vec_34[4] = token_33_34;
    assign dep_chan_vld_34_10 = out_chan_dep_vld_vec_34[0];
    assign dep_chan_data_34_10 = out_chan_dep_data_34;
    assign token_34_10 = token_out_vec_34[0];
    assign dep_chan_vld_34_24 = out_chan_dep_vld_vec_34[1];
    assign dep_chan_data_34_24 = out_chan_dep_data_34;
    assign token_34_24 = token_out_vec_34[1];
    assign dep_chan_vld_34_30 = out_chan_dep_vld_vec_34[2];
    assign dep_chan_data_34_30 = out_chan_dep_data_34;
    assign token_34_30 = token_out_vec_34[2];


`include "fastv2_layer2_hls_hls_deadlock_report_unit.vh"
